--
-- PostgreSQL database dump
--

\restrict EoLEopjuAcvQeXLdJRreNCiM8H4DacTZFMMSQ1408JIZiSYq7mAAsL5kQnVeVYg

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS pgrst_drop_watch;
DROP EVENT TRIGGER IF EXISTS pgrst_ddl_watch;
DROP EVENT TRIGGER IF EXISTS issue_pg_net_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_graphql_access;
DROP EVENT TRIGGER IF EXISTS issue_pg_cron_access;
DROP EVENT TRIGGER IF EXISTS issue_graphql_placeholder;
DROP PUBLICATION IF EXISTS supabase_realtime;
DROP POLICY IF EXISTS p_full_access_usuarios ON public.usuarios;
DROP POLICY IF EXISTS p_full_access_treinos_template_exercicios ON public.treinos_template_exercicios;
DROP POLICY IF EXISTS p_full_access_treinos_template ON public.treinos_template;
DROP POLICY IF EXISTS p_full_access_planos ON public.planos;
DROP POLICY IF EXISTS p_full_access_pagamentos ON public.pagamentos;
DROP POLICY IF EXISTS p_full_access_notificacoes ON public.notificacoes;
DROP POLICY IF EXISTS p_full_access_membros ON public.membros;
DROP POLICY IF EXISTS p_full_access_horarios_disponiveis ON public.horarios_disponiveis;
DROP POLICY IF EXISTS p_full_access_fichas_treino ON public.fichas_treino;
DROP POLICY IF EXISTS p_full_access_exercicios ON public.exercicios;
DROP POLICY IF EXISTS p_full_access_configuracoes ON public.configuracoes;
DROP POLICY IF EXISTS p_full_access_anamneses ON public.anamneses;
DROP POLICY IF EXISTS p_full_access_agendamentos ON public.agendamentos;
DROP POLICY IF EXISTS p_full_access__prisma_migrations ON public._prisma_migrations;
ALTER TABLE IF EXISTS ONLY public.treinos_template_exercicios DROP CONSTRAINT IF EXISTS treinos_template_exercicios_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pagamentos DROP CONSTRAINT IF EXISTS pagamentos_plano_id_fkey;
ALTER TABLE IF EXISTS ONLY public.pagamentos DROP CONSTRAINT IF EXISTS pagamentos_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notificacoes DROP CONSTRAINT IF EXISTS notificacoes_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.membros DROP CONSTRAINT IF EXISTS membros_usuario_id_fkey;
ALTER TABLE IF EXISTS ONLY public.membros DROP CONSTRAINT IF EXISTS membros_plano_id_fkey;
ALTER TABLE IF EXISTS ONLY public.horarios_fixos DROP CONSTRAINT IF EXISTS horarios_fixos_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.fichas_treino DROP CONSTRAINT IF EXISTS fichas_treino_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.exercicios DROP CONSTRAINT IF EXISTS exercicios_ficha_id_fkey;
ALTER TABLE IF EXISTS ONLY public.anamneses DROP CONSTRAINT IF EXISTS anamneses_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agendamentos DROP CONSTRAINT IF EXISTS agendamentos_membro_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agendamentos DROP CONSTRAINT IF EXISTS agendamentos_horario_id_fkey;
DROP INDEX IF EXISTS public.usuarios_token_verificacao_key;
DROP INDEX IF EXISTS public.usuarios_token_reset_key;
DROP INDEX IF EXISTS public.usuarios_email_key;
DROP INDEX IF EXISTS public.membros_usuario_id_key;
DROP INDEX IF EXISTS public.membros_cpf_key;
DROP INDEX IF EXISTS public.membros_anamnese_token_key;
DROP INDEX IF EXISTS public.horarios_fixos_membro_id_dia_semana_hora_key;
DROP INDEX IF EXISTS public.configuracoes_chave_key;
DROP INDEX IF EXISTS public.anamneses_membro_id_key;
DROP INDEX IF EXISTS public.agendamentos_membro_id_horario_id_data_key;
ALTER TABLE IF EXISTS ONLY public.usuarios DROP CONSTRAINT IF EXISTS usuarios_pkey;
ALTER TABLE IF EXISTS ONLY public.treinos_template DROP CONSTRAINT IF EXISTS treinos_template_pkey;
ALTER TABLE IF EXISTS ONLY public.treinos_template_exercicios DROP CONSTRAINT IF EXISTS treinos_template_exercicios_pkey;
ALTER TABLE IF EXISTS ONLY public.planos DROP CONSTRAINT IF EXISTS planos_pkey;
ALTER TABLE IF EXISTS ONLY public.pagamentos DROP CONSTRAINT IF EXISTS pagamentos_pkey;
ALTER TABLE IF EXISTS ONLY public.notificacoes DROP CONSTRAINT IF EXISTS notificacoes_pkey;
ALTER TABLE IF EXISTS ONLY public.membros DROP CONSTRAINT IF EXISTS membros_pkey;
ALTER TABLE IF EXISTS ONLY public.horarios_fixos DROP CONSTRAINT IF EXISTS horarios_fixos_pkey;
ALTER TABLE IF EXISTS ONLY public.horarios_disponiveis DROP CONSTRAINT IF EXISTS horarios_disponiveis_pkey;
ALTER TABLE IF EXISTS ONLY public.fichas_treino DROP CONSTRAINT IF EXISTS fichas_treino_pkey;
ALTER TABLE IF EXISTS ONLY public.exercicios DROP CONSTRAINT IF EXISTS exercicios_pkey;
ALTER TABLE IF EXISTS ONLY public.configuracoes DROP CONSTRAINT IF EXISTS configuracoes_pkey;
ALTER TABLE IF EXISTS ONLY public.anamneses DROP CONSTRAINT IF EXISTS anamneses_pkey;
ALTER TABLE IF EXISTS ONLY public.agendamentos DROP CONSTRAINT IF EXISTS agendamentos_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
DROP TABLE IF EXISTS public.usuarios;
DROP TABLE IF EXISTS public.treinos_template_exercicios;
DROP TABLE IF EXISTS public.treinos_template;
DROP TABLE IF EXISTS public.planos;
DROP TABLE IF EXISTS public.pagamentos;
DROP TABLE IF EXISTS public.notificacoes;
DROP TABLE IF EXISTS public.membros;
DROP TABLE IF EXISTS public.horarios_fixos;
DROP TABLE IF EXISTS public.horarios_disponiveis;
DROP TABLE IF EXISTS public.fichas_treino;
DROP TABLE IF EXISTS public.exercicios;
DROP TABLE IF EXISTS public.configuracoes;
DROP TABLE IF EXISTS public.anamneses;
DROP TABLE IF EXISTS public.agendamentos;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP FUNCTION IF EXISTS pgbouncer.get_auth(p_usename text);
DROP TYPE IF EXISTS public."TipoNotificacao";
DROP TYPE IF EXISTS public."StatusPagamento";
DROP TYPE IF EXISTS public."StatusMembro";
DROP TYPE IF EXISTS public."Sexo";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."DiaSemana";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS supabase_vault;
DROP EXTENSION IF EXISTS pgcrypto;
DROP EXTENSION IF EXISTS pg_stat_statements;
DROP EXTENSION IF EXISTS pg_graphql;
DROP SCHEMA IF EXISTS pgbouncer;
--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: DiaSemana; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DiaSemana" AS ENUM (
    'SEGUNDA',
    'TERCA',
    'QUARTA',
    'QUINTA',
    'SEXTA',
    'SABADO',
    'DOMINGO'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'MEMBRO'
);


--
-- Name: Sexo; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Sexo" AS ENUM (
    'MASCULINO',
    'FEMININO'
);


--
-- Name: StatusMembro; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusMembro" AS ENUM (
    'ATIVO',
    'INATIVO',
    'PENDENTE'
);


--
-- Name: StatusPagamento; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."StatusPagamento" AS ENUM (
    'PENDENTE',
    'PAGO',
    'ATRASADO',
    'CANCELADO'
);


--
-- Name: TipoNotificacao; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TipoNotificacao" AS ENUM (
    'LEMBRETE_AULA',
    'COBRANCA',
    'ANIVERSARIO',
    'AVISO_GERAL'
);


--
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: agendamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agendamentos (
    id text NOT NULL,
    membro_id text NOT NULL,
    horario_id text NOT NULL,
    data date NOT NULL,
    presente boolean,
    observacao text,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: anamneses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.anamneses (
    id text NOT NULL,
    membro_id text NOT NULL,
    altura text,
    peso_atual text,
    objetivo text,
    pratica_atividade text,
    pratica_atividade_qual text,
    tempo_sedentario text,
    condicao_medica text,
    condicao_medica_qual text,
    lesao text,
    lesao_qual text,
    restricao_movimento text,
    restricao_movimento_qual text,
    desconforto_movimento text,
    desconforto_movimento_qual text,
    problemas_ortopedicos text,
    problemas_ortopedicos_qual text,
    medicamento_controlado text,
    medicamento_controlado_qual text,
    obeso_sobrepeso text,
    colesterol_elevado text,
    taquicardia text,
    doencas_cardiacas text,
    diabetes text,
    dificuldade_exercicio text,
    ciclo_menstrual text,
    experiencia_musculacao text,
    onde_conheceu text,
    expectativas text,
    parq1 text,
    parq2 text,
    parq3 text,
    parq4 text,
    parq5 text,
    parq6 text,
    parq7 text,
    nextfit_avaliacao_id text,
    sincronizado_em timestamp(3) without time zone,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: configuracoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.configuracoes (
    id text NOT NULL,
    chave text NOT NULL,
    valor text NOT NULL,
    descricao text,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: exercicios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exercicios (
    id text NOT NULL,
    ficha_id text NOT NULL,
    nome text NOT NULL,
    grupo_muscular text,
    series text NOT NULL,
    repeticoes text NOT NULL,
    descanso text,
    observacoes text,
    ordem integer DEFAULT 0 NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL,
    sessao text DEFAULT 'A'::text NOT NULL
);


--
-- Name: fichas_treino; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fichas_treino (
    id text NOT NULL,
    membro_id text NOT NULL,
    nome text NOT NULL,
    objetivo text,
    observacoes text,
    ativo boolean DEFAULT true NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL,
    data text
);


--
-- Name: horarios_disponiveis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.horarios_disponiveis (
    id text NOT NULL,
    dia_semana public."DiaSemana" NOT NULL,
    hora_inicio text NOT NULL,
    hora_fim text NOT NULL,
    vagas_total integer NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: horarios_fixos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.horarios_fixos (
    id text NOT NULL,
    membro_id text NOT NULL,
    dia_semana public."DiaSemana" NOT NULL,
    hora text NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: membros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.membros (
    id text NOT NULL,
    usuario_id text NOT NULL,
    cpf text,
    telefone text,
    data_nascimento timestamp(3) without time zone,
    observacoes text,
    status public."StatusMembro" DEFAULT 'PENDENTE'::public."StatusMembro" NOT NULL,
    foto_url text,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL,
    plano_id text,
    rg text,
    preco_customizado numeric(10,2),
    sexo public."Sexo",
    anamnese_token text,
    anamnese_token_expira timestamp(3) without time zone
);


--
-- Name: notificacoes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notificacoes (
    id text NOT NULL,
    membro_id text,
    tipo public."TipoNotificacao" NOT NULL,
    titulo text NOT NULL,
    mensagem text NOT NULL,
    enviada boolean DEFAULT false NOT NULL,
    enviada_em timestamp(3) without time zone,
    agendada_para timestamp(3) without time zone,
    canal_whatsapp boolean DEFAULT false NOT NULL,
    canal_email boolean DEFAULT false NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: pagamentos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pagamentos (
    id text NOT NULL,
    membro_id text NOT NULL,
    plano_id text NOT NULL,
    valor numeric(10,2) NOT NULL,
    data_vencimento date NOT NULL,
    data_pagamento timestamp(3) without time zone,
    status public."StatusPagamento" DEFAULT 'PENDENTE'::public."StatusPagamento" NOT NULL,
    forma_pagamento text,
    comprovante text,
    observacao text,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: planos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planos (
    id text NOT NULL,
    nome text NOT NULL,
    descricao text,
    valor numeric(10,2) NOT NULL,
    duracao_dias integer NOT NULL,
    aulas_semanais integer NOT NULL,
    ativo boolean DEFAULT true NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: treinos_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treinos_template (
    id text NOT NULL,
    nome text NOT NULL,
    objetivo text,
    observacoes text,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: treinos_template_exercicios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.treinos_template_exercicios (
    id text NOT NULL,
    template_id text NOT NULL,
    sessao text DEFAULT 'A'::text NOT NULL,
    nome text NOT NULL,
    grupo_muscular text,
    series text NOT NULL,
    repeticoes text NOT NULL,
    descanso text,
    observacoes text,
    ordem integer DEFAULT 0 NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL
);


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuarios (
    id text NOT NULL,
    email text NOT NULL,
    senha text NOT NULL,
    nome text,
    role public."Role" DEFAULT 'MEMBRO'::public."Role" NOT NULL,
    criado_em timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    atualizado_em timestamp(3) without time zone NOT NULL,
    email_verificado timestamp(3) without time zone,
    etapa_onboarding integer DEFAULT 1 NOT NULL,
    onboarding_completo boolean DEFAULT false NOT NULL,
    token_reset text,
    token_reset_expira timestamp(3) without time zone,
    token_verificacao text,
    token_verificacao_expira timestamp(3) without time zone,
    senha_definida boolean DEFAULT false NOT NULL
);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4fbcb913-d8c6-48ec-979d-16c618cadede	73f7b6f18e80883bff3d3c26b3d7d2046b21ca7dcfbf4feb1006b805e776c8a0	2026-01-14 13:27:05.189906+00	20250114000000_add_sexo_enum_and_field	\N	\N	2026-01-14 13:27:04.356398+00	1
251e5935-b4a1-4b1e-9c82-0c859da76dbd	1f75c5b818e0c9443997e44ed5879c94561b8b8f5cec1d2461237a18ec9e55d9	\N	20250309120000_init	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250309120000_init\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "Role" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"Role\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1177), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250309120000_init"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250309120000_init"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-01-23 13:35:09.763535+00	2026-01-23 13:17:43.411716+00	0
31212d7d-f011-471f-a47d-4cff6c66da14	7a7bfc7a49664d3c6c59005962d6b057067fed8c91f44c5918186e1ecaf6ce15	2026-01-28 13:04:43.56505+00	20260128130000_add_horarios_fixos	\N	\N	2026-01-28 13:04:42.868789+00	1
58daf659-ec8b-417b-8a24-43497c4317a7	9e0d1b2e6c6442baeaa1de19e6331a7073d2c4a4c303d1e0bea943a070f9ecd8	2026-01-23 13:35:14.713894+00	20250309123000_add_senha_definida	\N	\N	2026-01-23 13:35:14.044681+00	1
9f0b3809-bc62-4c32-8f35-cac541fad1c3	754f36dba790ce92327b19655437fa6d9c923cee0b76773adbcf255018ff4262	2026-01-23 13:52:50.46116+00	20250309124500_add_anamnese_token_columns	\N	\N	2026-01-23 13:52:49.786785+00	1
d56c729c-14b3-40e9-9629-2f4478ea17d8	7267308f915b02e34dece7416765f547816293e90fd613b9a04c7325ff4ef814	2026-01-27 11:21:05.508498+00	20260127120000_enable_rls_public	\N	\N	2026-01-27 11:21:04.854891+00	1
38dab0c4-561c-4617-a80d-88d7cd610d82	acf99a2076a2584a0898b550b21edae8727340449f8f5227f6bb6cf0fb847ebb	\N	20250309120000_init	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20250309120000_init\n\nDatabase error code: 42710\n\nDatabase error:\nERROR: type "Role" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42710), message: "type \\"Role\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("typecmds.c"), line: Some(1177), routine: Some("DefineEnum") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20250309120000_init"\n             at schema-engine/connectors/sql-schema-connector/src/apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20250309120000_init"\n             at schema-engine/commands/src/commands/apply_migrations.rs:95\n   2: schema_core::state::ApplyMigrations\n             at schema-engine/core/src/state.rs:260	2026-01-27 11:54:10.001706+00	2026-01-27 11:52:32.021329+00	0
4f3329b1-793a-4b97-b65f-09ff2d857d2c	acf99a2076a2584a0898b550b21edae8727340449f8f5227f6bb6cf0fb847ebb	2026-01-27 11:54:10.234548+00	20250309120000_init		\N	2026-01-27 11:54:10.234548+00	0
\.


--
-- Data for Name: agendamentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agendamentos (id, membro_id, horario_id, data, presente, observacao, criado_em, atualizado_em) FROM stdin;
cmkb73q7q00032mrmzp11p0bo	cmk1998zo00682mi0mjhxpnpw	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:25:16.022	2026-01-12 13:25:16.022
cmkb73qm000052mrmm60wvxyv	cmk1998zo00682mi0mjhxpnpw	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:25:16.537	2026-01-12 13:25:16.537
cmkb73r0g00072mrm8ycqkpe2	cmk1998zo00682mi0mjhxpnpw	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:25:17.056	2026-01-12 13:25:17.056
cmkb73re900092mrmk8nwqfva	cmk1998zo00682mi0mjhxpnpw	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:25:17.554	2026-01-12 13:25:17.554
cmkb73rs2000b2mrm9kow7pze	cmk1998zo00682mi0mjhxpnpw	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:25:18.05	2026-01-12 13:25:18.05
cmkb73s6k000d2mrm22pgjs9x	cmk1998zo00682mi0mjhxpnpw	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:25:18.572	2026-01-12 13:25:18.572
cmkb73skf000f2mrmy9kzsk9n	cmk1998zo00682mi0mjhxpnpw	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:25:19.072	2026-01-12 13:25:19.072
cmkb73syz000h2mrm1my1lrz3	cmk1998zo00682mi0mjhxpnpw	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:25:19.596	2026-01-12 13:25:19.596
cmkb73tdk000j2mrmnhskdvqn	cmk1998zo00682mi0mjhxpnpw	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:25:20.12	2026-01-12 13:25:20.12
cmkb73ts4000l2mrm7vn8d6ta	cmk1998zo00682mi0mjhxpnpw	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:25:20.644	2026-01-12 13:25:20.644
cmkb73u6o000n2mrm1dni95h1	cmk1998zo00682mi0mjhxpnpw	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:25:21.169	2026-01-12 13:25:21.169
cmkb73ul8000p2mrmjsqabnvh	cmk1998zo00682mi0mjhxpnpw	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:25:21.692	2026-01-12 13:25:21.692
cmkb73uzt000r2mrm42ld1g1z	cmk1998zo00682mi0mjhxpnpw	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:25:22.217	2026-01-12 13:25:22.217
cmkb73ved000t2mrmrb5ezmby	cmk1998zo00682mi0mjhxpnpw	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:25:22.741	2026-01-12 13:25:22.741
cmkb73vsw000v2mrmzwbf9uol	cmk1998zo00682mi0mjhxpnpw	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:25:23.265	2026-01-12 13:25:23.265
cmkb73w7k000x2mrmpxxrflrb	cmk1998zo00682mi0mjhxpnpw	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:25:23.792	2026-01-12 13:25:23.792
cmkb73wvl000z2mrmthkx6l73	cmk199jf8009h2mi0i5rphoxr	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:24.657	2026-01-12 13:25:24.657
cmkb73x9p00112mrmdijwavn7	cmk199jf8009h2mi0i5rphoxr	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:25.165	2026-01-12 13:25:25.165
cmkb73xoe00132mrmt2uehr0x	cmk199jf8009h2mi0i5rphoxr	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:25.694	2026-01-12 13:25:25.694
cmkb73y2m00152mrmf8c93p8w	cmk199jf8009h2mi0i5rphoxr	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:26.207	2026-01-12 13:25:26.207
cmkb73yh900172mrmb9bbtcr1	cmk199jf8009h2mi0i5rphoxr	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:25:26.733	2026-01-12 13:25:26.733
cmkb73yvs00192mrmkqawt7jf	cmk199jf8009h2mi0i5rphoxr	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:25:27.257	2026-01-12 13:25:27.257
cmkb73zaf001b2mrmgsu79mfk	cmk199jf8009h2mi0i5rphoxr	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:25:27.784	2026-01-12 13:25:27.784
cmkb73zp3001d2mrmze2384qq	cmk199jf8009h2mi0i5rphoxr	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:25:28.312	2026-01-12 13:25:28.312
cmkb740a1001g2mrmrty47xaq	cmk199jf8009h2mi0i5rphoxr	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:25:29.066	2026-01-12 13:25:29.066
cmkb740pa001i2mrmgi7611ex	cmk199jf8009h2mi0i5rphoxr	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:25:29.585	2026-01-12 13:25:29.585
cmkb7413s001k2mrmzfglpts0	cmk199jf8009h2mi0i5rphoxr	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:25:30.136	2026-01-12 13:25:30.136
cmkb741ib001m2mrmb62h5q3b	cmk199jf8009h2mi0i5rphoxr	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:25:30.659	2026-01-12 13:25:30.659
cmkb741wy001o2mrm8bi9k8kk	cmk199jf8009h2mi0i5rphoxr	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:25:31.187	2026-01-12 13:25:31.187
cmkb742la001q2mrmkuhmd1up	cmk198rzq000w2mi0zho10guw	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:25:32.062	2026-01-12 13:25:32.062
cmkb742zp001s2mrmeiwk1gsx	cmk198rzq000w2mi0zho10guw	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:25:32.581	2026-01-12 13:25:32.581
cmkb743dl001u2mrm654vb4g1	cmk198rzq000w2mi0zho10guw	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:25:33.081	2026-01-12 13:25:33.081
cmkb743s4001w2mrmpm0aynw7	cmk198rzq000w2mi0zho10guw	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:25:33.605	2026-01-12 13:25:33.605
cmkb744ip001y2mrm7nekhm2n	cmk2kqlpu01582msauiozwpwr	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:34.561	2026-01-12 13:25:34.561
cmkb744x800202mrmjtmproer	cmk2kqlpu01582msauiozwpwr	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:35.085	2026-01-12 13:25:35.085
cmkb745b200222mrmn20mxos1	cmk2kqlpu01582msauiozwpwr	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:35.582	2026-01-12 13:25:35.582
cmkb745ph00242mrmw8l0nad3	cmk2kqlpu01582msauiozwpwr	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:36.101	2026-01-12 13:25:36.101
cmkb747ja00262mrmtbvn27mp	cmk198rzq000w2mi0zho10guw	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:38.47	2026-01-12 13:25:38.47
cmkb747xu00282mrmo0ldd7s5	cmk198rzq000w2mi0zho10guw	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:38.994	2026-01-12 13:25:38.994
cmkb748cf002a2mrmn371jasc	cmk198rzq000w2mi0zho10guw	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:39.519	2026-01-12 13:25:39.519
cmkb748r1002c2mrmcrdd6b0p	cmk198rzq000w2mi0zho10guw	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:40.045	2026-01-12 13:25:40.045
cmkb7495h002e2mrmpj0aufa1	cmk198rzq000w2mi0zho10guw	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:40.566	2026-01-12 13:25:40.566
cmkb749k3002g2mrm6xa2f6kl	cmk198rzq000w2mi0zho10guw	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:41.091	2026-01-12 13:25:41.091
cmkb749yp002i2mrmuknv05u9	cmk198rzq000w2mi0zho10guw	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:41.617	2026-01-12 13:25:41.617
cmkb74ad8002k2mrmqa35cf9w	cmk198rzq000w2mi0zho10guw	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:42.14	2026-01-12 13:25:42.14
cmkb74ars002m2mrmj5eyuqph	cmk198rzq000w2mi0zho10guw	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:25:42.664	2026-01-12 13:25:42.664
cmkxwm9s60001jp045ytucacp	cmkwo4i8f0002la04saafdb2c	QUARTA-08:00	2026-01-28	\N	\N	2026-01-28 10:50:27.462	2026-01-28 10:50:27.462
cmkyi0d830001l104x5n3c72r	cmkwo4i8f0002la04saafdb2c	cmk2kq93j004t2msa1hcg8y08	2026-02-05	\N	\N	2026-01-28 20:49:17.044	2026-01-28 20:49:17.044
cmkb74fug00392mrm8hlzfuuo	cmk2kqh2t00va2msayml7p5hq	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:25:49.24	2026-01-12 13:25:49.24
cmkb74g8e003b2mrm9nw6sa1k	cmk2kqh2t00va2msayml7p5hq	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:25:49.743	2026-01-12 13:25:49.743
cmkb74gmy003d2mrmudc3appo	cmk2kqh2t00va2msayml7p5hq	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:25:50.267	2026-01-12 13:25:50.267
cmkb74h17003f2mrm8fcjglbr	cmk2kqh2t00va2msayml7p5hq	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:25:50.78	2026-01-12 13:25:50.78
cmkb74hf5003h2mrmde0lrdbm	cmk2kqh2t00va2msayml7p5hq	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:25:51.282	2026-01-12 13:25:51.282
cmkb74htm003j2mrmyrypg0mt	cmk2kqh2t00va2msayml7p5hq	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:25:51.802	2026-01-12 13:25:51.802
cmkb74i7j003l2mrmb3ph1qrf	cmk2kqh2t00va2msayml7p5hq	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:25:52.303	2026-01-12 13:25:52.303
cmkb74ilv003n2mrm7s2gkx27	cmk2kqh2t00va2msayml7p5hq	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:25:52.82	2026-01-12 13:25:52.82
cmkb74sbe004x2mrmmbvdre5m	cmk199k7z009q2mi0aihokjw4	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:26:05.403	2026-01-12 13:26:05.403
cmkb74spa004z2mrm2oz1exh3	cmk199k7z009q2mi0aihokjw4	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:26:05.902	2026-01-12 13:26:05.902
cmkb74t3a00512mrmgzxhe270	cmk199k7z009q2mi0aihokjw4	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:26:06.406	2026-01-12 13:26:06.406
cmkb74thp00532mrmu94ml65j	cmk199k7z009q2mi0aihokjw4	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:26:06.925	2026-01-12 13:26:06.925
cmkb74tw200552mrmyypcp1gq	cmk199k7z009q2mi0aihokjw4	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:26:07.443	2026-01-12 13:26:07.443
cmkb74uam00572mrmt6npdtuh	cmk199k7z009q2mi0aihokjw4	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:26:07.966	2026-01-12 13:26:07.966
cmkb74upc00592mrm8633ym9r	cmk199k7z009q2mi0aihokjw4	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:26:08.496	2026-01-12 13:26:08.496
cmkb74v3u005b2mrmyafclszd	cmk199k7z009q2mi0aihokjw4	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:26:09.019	2026-01-12 13:26:09.019
cmkb74vhn005d2mrm9babjn04	cmk199k7z009q2mi0aihokjw4	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:26:09.516	2026-01-12 13:26:09.516
cmkb74vvg005f2mrmhq55fzn5	cmk199k7z009q2mi0aihokjw4	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:26:10.012	2026-01-12 13:26:10.012
cmkb74wa2005h2mrmqhrr2qsm	cmk199k7z009q2mi0aihokjw4	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:26:10.538	2026-01-12 13:26:10.538
cmkb74woj005j2mrmz3qd3gj3	cmk199k7z009q2mi0aihokjw4	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:26:11.059	2026-01-12 13:26:11.059
cmkb74x38005l2mrmh46renda	cmk199k7z009q2mi0aihokjw4	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:26:11.588	2026-01-12 13:26:11.588
cmkb74xr6005n2mrm8m9lhm4w	cmk199han008t2mi0gavokllh	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:12.45	2026-01-12 13:26:12.45
cmkb74y53005p2mrmewksmn2s	cmk199han008t2mi0gavokllh	cmk2i2sqh00002mcj8khig5hz	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:12.951	2026-01-12 13:26:12.951
cmkb74yjn005r2mrmo8abppg5	cmk199han008t2mi0gavokllh	cmk2i2sqh00002mcj8khig5hz	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:13.476	2026-01-12 13:26:13.476
cmkb74yy6005t2mrmtdolrrjh	cmk199han008t2mi0gavokllh	cmk2i2sqh00002mcj8khig5hz	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:13.998	2026-01-12 13:26:13.998
cmkb74zcq005v2mrmg4lc4xpx	cmk199han008t2mi0gavokllh	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:14.522	2026-01-12 13:26:14.522
cmkb74zrd005x2mrm2zhhslz9	cmk199han008t2mi0gavokllh	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:15.049	2026-01-12 13:26:15.049
cmkb7c8dc010i2mrmqdwdim7r	cmk198xtz002q2mi0oynknikc	cmk2kq8l0002k2msasi6djwph	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:52.8	2026-01-12 13:31:52.8
cmkb7c8rw010k2mrmcuup5hkr	cmk198xtz002q2mi0oynknikc	cmk2kq8l0002k2msasi6djwph	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:53.323	2026-01-12 13:31:53.323
cmkb7c96g010m2mrmqwsbu929	cmk198xtz002q2mi0oynknikc	cmk2kq8l0002k2msasi6djwph	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:53.848	2026-01-12 13:31:53.848
cmkb75099005z2mrmwdoeckrk	cmk199han008t2mi0gavokllh	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:15.693	2026-01-12 13:26:15.693
cmkb750lg00612mrmj5t9efpa	cmk199han008t2mi0gavokllh	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:16.133	2026-01-12 13:26:16.133
cmkb750zy00632mrm1jvfr2qs	cmk199han008t2mi0gavokllh	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:16.654	2026-01-12 13:26:16.654
cmkyjkgs40001l404i9mzfou2	cmk198plh00052mi0vd9sq0ac	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:32:54.389	2026-01-28 21:32:54.389
cmkyjlp580001k5045ul2v3fg	cmk198s9b000z2mi0oqitra0w	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:33:51.885	2026-01-28 21:33:51.885
cmkyjn1ia0003k5044lzrf8tw	cmk199k7z009q2mi0aihokjw4	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:34:54.562	2026-01-28 21:34:54.562
cmkyjnhxt0005k5049iit7usc	cmk199jf8009h2mi0i5rphoxr	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:35:15.858	2026-01-28 21:35:15.858
cmkb754av006g2mrme64z6vbl	cmk198qxe000k2mi0yrn7b1l5	SEGUNDA-06:00	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:20.936	2026-01-12 13:26:20.936
cmkb754mr006i2mrmkqbe28or	cmk198qxe000k2mi0yrn7b1l5	SEGUNDA-06:00	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:21.364	2026-01-12 13:26:21.364
cmkb75510006k2mrmmrbvrxb0	cmk198qxe000k2mi0yrn7b1l5	SEGUNDA-06:00	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:21.877	2026-01-12 13:26:21.877
cmkb755fd006m2mrm44g5ynkc	cmk198qxe000k2mi0yrn7b1l5	SEGUNDA-06:00	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:22.394	2026-01-12 13:26:22.394
cmkb755u5006o2mrmvjgiqrzo	cmk198qxe000k2mi0yrn7b1l5	QUARTA-06:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:22.925	2026-01-12 13:26:22.925
cmkb7568a006q2mrmos47n9gi	cmk198qxe000k2mi0yrn7b1l5	QUARTA-06:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:23.435	2026-01-12 13:26:23.435
cmkb756m3006s2mrmyj6pozix	cmk198qxe000k2mi0yrn7b1l5	QUARTA-06:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:23.931	2026-01-12 13:26:23.931
cmkb7570i006u2mrm87rwwjsg	cmk198qxe000k2mi0yrn7b1l5	QUARTA-06:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:24.45	2026-01-12 13:26:24.45
cmkb757ee006w2mrmi23wn1fv	cmk198qxe000k2mi0yrn7b1l5	SEXTA-06:00	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:24.95	2026-01-12 13:26:24.95
cmkb757sd006y2mrme0mpmqk9	cmk198qxe000k2mi0yrn7b1l5	SEXTA-06:00	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:25.454	2026-01-12 13:26:25.454
cmkb7587200702mrmflf0yodf	cmk198qxe000k2mi0yrn7b1l5	SEXTA-06:00	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:25.983	2026-01-12 13:26:25.983
cmkb758lf00722mrmu6z4vn9h	cmk198qxe000k2mi0yrn7b1l5	SEXTA-06:00	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:26.499	2026-01-12 13:26:26.499
cmkb758zx00742mrm7nctu7b2	cmk198qxe000k2mi0yrn7b1l5	SEXTA-06:00	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:26:27.021	2026-01-12 13:26:27.021
cmkb759qg00762mrmp1rlsewr	cmk1998q400652mi0j3oh8k8f	SEGUNDA-06:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:26:27.976	2026-01-12 13:26:27.976
cmkb75a4i00782mrmwzr0spra	cmk1998q400652mi0j3oh8k8f	SEGUNDA-06:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:26:28.483	2026-01-12 13:26:28.483
cmkb75aiv007a2mrmi0rr6sx6	cmk1998q400652mi0j3oh8k8f	SEGUNDA-06:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:26:29	2026-01-12 13:26:29
cmkb75axe007c2mrm3wkliejq	cmk1998q400652mi0j3oh8k8f	SEGUNDA-06:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:26:29.522	2026-01-12 13:26:29.522
cmkb75bbb007e2mrmprc13uph	cmk1998q400652mi0j3oh8k8f	QUARTA-06:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:26:30.023	2026-01-12 13:26:30.023
cmkyjo2p40007k504uj6liim5	cmk1998zo00682mi0mjhxpnpw	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:35:42.76	2026-01-28 21:35:42.76
cmkb75c4j007i2mrmhmknrnib	cmk1998q400652mi0j3oh8k8f	QUARTA-06:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:26:31.076	2026-01-12 13:26:31.076
cmkb75ciw007k2mrm0e2vvvjs	cmk1998q400652mi0j3oh8k8f	QUARTA-06:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:26:31.592	2026-01-12 13:26:31.592
cmkb75cxl007m2mrmo6cw667b	cmk1998q400652mi0j3oh8k8f	SEXTA-06:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:26:32.122	2026-01-12 13:26:32.122
cmkb75dc2007o2mrmy6x37zrs	cmk1998q400652mi0j3oh8k8f	SEXTA-06:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:26:32.643	2026-01-12 13:26:32.643
cmkb75dqk007q2mrmydxrdqeg	cmk1998q400652mi0j3oh8k8f	SEXTA-06:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:26:33.164	2026-01-12 13:26:33.164
cmkb75e5b007s2mrm6un88cy2	cmk1998q400652mi0j3oh8k8f	SEXTA-06:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:26:33.696	2026-01-12 13:26:33.696
cmkb75ejs007u2mrmhehxscjm	cmk1998q400652mi0j3oh8k8f	SEXTA-06:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:26:34.216	2026-01-12 13:26:34.216
cmkyjpbuw000bk504r2eesl7x	cmk199i3b00922mi0b9qug5km	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:36:41.288	2026-01-28 21:36:41.288
cmkyjpq8m000dk5043oydkn28	cmk199han008t2mi0gavokllh	cmk2i2sqh00002mcj8khig5hz	2026-02-02	\N	\N	2026-01-28 21:36:59.926	2026-01-28 21:36:59.926
cmkyjr4w5000hk5048tz49zqk	cmk198qxe000k2mi0yrn7b1l5	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:38:05.573	2026-01-28 21:38:05.573
cmkyjrh69000jk504knad70y3	cmk198qnv000h2mi03o0z9uz1	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:38:21.489	2026-01-28 21:38:21.489
cmkyjrq0v000lk504buv61rjz	cmk198tbj001b2mi0x13vbcvr	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:38:32.959	2026-01-28 21:38:32.959
cmkyjs2mj000nk5048yro0ggm	cmk198wrz002e2mi0yuwdflbl	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:38:49.292	2026-01-28 21:38:49.292
cmkyjt4to000pk504ubsmb3b8	cmk198z5n00352mi0n28kj1ab	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:39:38.797	2026-01-28 21:39:38.797
cmkyju1pw000rk5042tii95gj	cmk1994hf004t2mi0x3r67zy4	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:40:21.429	2026-01-28 21:40:21.429
cmkyjucmh000tk504gagoc4l3	cmk1998gm00622mi0co8yuy4y	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 21:40:35.562	2026-01-28 21:40:35.562
cmkyjvo4q000vk50405yezy4w	cmk199khj009t2mi0wi1jutmy	SEGUNDA-07:00	2026-02-02	\N	\N	2026-01-28 21:41:37.131	2026-01-28 21:41:37.131
cmkyjw5gn000xk504vkyexxt7	cmk199sb700c82mi0f6kviwjw	SEGUNDA-07:00	2026-02-02	\N	\N	2026-01-28 21:41:59.591	2026-01-28 21:41:59.591
cmkyjwbeq000zk5040ke04gy4	cmk199twf00cq2mi0vlqg5i7z	SEGUNDA-07:00	2026-02-02	\N	\N	2026-01-28 21:42:07.299	2026-01-28 21:42:07.299
cmkyjx9j90011k504173j3v9s	cmk198wig002b2mi06vqg92nm	SEGUNDA-07:00	2026-02-02	\N	\N	2026-01-28 21:42:51.525	2026-01-28 21:42:51.525
cmkyjxopv0013k504efd0p24b	cmk199bz100752mi0l1otqgsk	SEGUNDA-08:00	2026-02-02	\N	\N	2026-01-28 21:43:11.203	2026-01-28 21:43:11.203
cmkb760tk00ap2mrm1eopc01p	cmk198wig002b2mi06vqg92nm	SEGUNDA-06:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:27:03.081	2026-01-12 13:27:03.081
cmkb7618700ar2mrm7ynrs94e	cmk198wig002b2mi06vqg92nm	SEGUNDA-06:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:27:03.608	2026-01-12 13:27:03.608
cmkb761mo00at2mrmxha7ig91	cmk198wig002b2mi06vqg92nm	SEGUNDA-06:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:27:04.128	2026-01-12 13:27:04.128
cmkb7621a00av2mrm79bst2r2	cmk198wig002b2mi06vqg92nm	SEGUNDA-06:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:27:04.654	2026-01-12 13:27:04.654
cmkb762fx00ax2mrmzcikddbd	cmk198wig002b2mi06vqg92nm	QUARTA-06:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:05.181	2026-01-12 13:27:05.181
cmkb762u700az2mrmlqapk8lm	cmk198wig002b2mi06vqg92nm	QUARTA-06:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:05.696	2026-01-12 13:27:05.696
cmkb7638v00b12mrm3engmk59	cmk198wig002b2mi06vqg92nm	QUARTA-06:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:06.223	2026-01-12 13:27:06.223
cmkb763mn00b32mrm7yxdm3mw	cmk198wig002b2mi06vqg92nm	QUARTA-06:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:06.72	2026-01-12 13:27:06.72
cmkb7641h00b52mrmrrzuq6fm	cmk198wig002b2mi06vqg92nm	QUINTA-06:00	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:07.254	2026-01-12 13:27:07.254
cmkb764g000b72mrmomy0jdjq	cmk198wig002b2mi06vqg92nm	QUINTA-06:00	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:07.776	2026-01-12 13:27:07.776
cmkb764uc00b92mrmqd4k22ke	cmk198wig002b2mi06vqg92nm	QUINTA-06:00	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:08.292	2026-01-12 13:27:08.292
cmkb7658u00bb2mrmjoi99ho1	cmk198wig002b2mi06vqg92nm	QUINTA-06:00	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:08.814	2026-01-12 13:27:08.814
cmkb765nm00bd2mrmmtqd5hls	cmk198wig002b2mi06vqg92nm	QUINTA-06:00	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:09.347	2026-01-12 13:27:09.347
cmkyk2xsn0019k50446pjehha	cmk198v6k001w2mi02ivlhs3x	cmkb77yb500ju2mrmh718oogt	2026-02-02	\N	\N	2026-01-28 21:47:16.248	2026-01-28 21:47:16.248
cmkyk20qc0017k50484q8yfav	cmk199nff00aq2mi0vb28mgm9	cmkb77mzd00ic2mrmagrtkapf	2026-02-02	\N	\N	2026-01-28 21:46:33.396	2026-01-28 21:47:23.714
cmkyk167x0015k5048fqh2qzk	cmk199fpg008b2mi0xsa8dufo	cmkb77mzd00ic2mrmagrtkapf	2026-02-02	\N	\N	2026-01-28 21:45:53.854	2026-01-28 21:47:26.733
cmkb7c9kz010o2mrmz9qu3x17	cmk198xtz002q2mi0oynknikc	cmk2kq8l0002k2msasi6djwph	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:54.372	2026-01-12 13:31:54.372
cmkb7c9zl010q2mrm0w9agzge	cmk198xtz002q2mi0oynknikc	cmk2kq8lc002t2msag1rmi700	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:54.897	2026-01-12 13:31:54.897
cmkb7caeb010s2mrml87gz16c	cmk198xtz002q2mi0oynknikc	cmk2kq8lc002t2msag1rmi700	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:55.427	2026-01-12 13:31:55.427
cmkb7casp010u2mrmaaugo50l	cmk198xtz002q2mi0oynknikc	cmk2kq8lc002t2msag1rmi700	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:55.945	2026-01-12 13:31:55.945
cmkb7cb79010w2mrm8rvthp4a	cmk198xtz002q2mi0oynknikc	cmk2kq8lc002t2msag1rmi700	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:56.469	2026-01-12 13:31:56.469
cmkb7cblt010y2mrm5ztv1qlp	cmk198xtz002q2mi0oynknikc	cmk2kq8lm00322msas3daxefo	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:56.994	2026-01-12 13:31:56.994
cmkb7cc0c01102mrm4z99uw99	cmk198xtz002q2mi0oynknikc	cmk2kq8lm00322msas3daxefo	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:57.516	2026-01-12 13:31:57.516
cmkb7ccey01122mrmqkqtrzoz	cmk198xtz002q2mi0oynknikc	cmk2kq8lm00322msas3daxefo	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:58.042	2026-01-12 13:31:58.042
cmkb7cctk01142mrmkapuryft	cmk198xtz002q2mi0oynknikc	cmk2kq8lm00322msas3daxefo	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:58.568	2026-01-12 13:31:58.568
cmkb7cd8701162mrm08zxz6dg	cmk198xtz002q2mi0oynknikc	cmk2kq8lm00322msas3daxefo	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:59.096	2026-01-12 13:31:59.096
cmkb7cdmn01182mrmonh60ahv	cmk198xtz002q2mi0oynknikc	cmk2kq8lx003d2msaicgiovas	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:59.615	2026-01-12 13:31:59.615
cmkb7ce18011a2mrmoe0mownj	cmk198xtz002q2mi0oynknikc	cmk2kq8lx003d2msaicgiovas	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:00.14	2026-01-12 13:32:00.14
cmkb7cefr011c2mrmxiehsp4c	cmk198xtz002q2mi0oynknikc	cmk2kq8lx003d2msaicgiovas	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:00.663	2026-01-12 13:32:00.663
cmkb7ceuz011e2mrmnj4q82qy	cmk198xtz002q2mi0oynknikc	cmk2kq8lx003d2msaicgiovas	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:01.098	2026-01-12 13:32:01.098
cmkb7cf9k011g2mrm04qx0cx0	cmk198xtz002q2mi0oynknikc	cmk2kq8lx003d2msaicgiovas	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:01.736	2026-01-12 13:32:01.736
cmkylr9lv0003kt04kyuzprga	cmk199ljv00a52mi0kszrm603	cmkb78ptg00ln2mrmanq23795	2026-02-02	\N	\N	2026-01-28 22:34:10.915	2026-01-28 22:34:10.915
cmkylroi00005kt04phrimcly	cmk1990qt003n2mi0hdys30el	cmkb53kmy0000ju04fwqn5jq9	2026-02-02	\N	\N	2026-01-28 22:34:30.217	2026-01-28 22:34:30.217
cmkb76c7p00c82mrmz3b7lq6f	cmk2kqne101ae2msa676t786e	SEGUNDA-07:00	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:17.845	2026-01-12 13:27:17.845
cmkb76cma00ca2mrm8md4hiko	cmk2kqne101ae2msa676t786e	SEGUNDA-07:00	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:18.37	2026-01-12 13:27:18.37
cmkb76d0s00cc2mrmaipmutoi	cmk2kqne101ae2msa676t786e	SEGUNDA-07:00	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:18.892	2026-01-12 13:27:18.892
cmkb76dey00ce2mrm1ugpdq49	cmk2kqne101ae2msa676t786e	SEGUNDA-07:00	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:19.402	2026-01-12 13:27:19.402
cmkb76dt400cg2mrmdfmeukh8	cmk2kqne101ae2msa676t786e	SEXTA-07:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:27:19.913	2026-01-12 13:27:19.913
cmkb76e7z00ci2mrmid1zd8xz	cmk2kqne101ae2msa676t786e	SEXTA-07:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:27:20.448	2026-01-12 13:27:20.448
cmkb76emd00ck2mrmp506fgpd	cmk2kqne101ae2msa676t786e	SEXTA-07:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:27:20.966	2026-01-12 13:27:20.966
cmkb76f1000cm2mrmpn8insgi	cmk2kqne101ae2msa676t786e	SEXTA-07:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:27:21.492	2026-01-12 13:27:21.492
cmkb76fff00co2mrmle206xe6	cmk2kqne101ae2msa676t786e	SEXTA-07:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:27:22.012	2026-01-12 13:27:22.012
cmkb76g6600cq2mrmx7c8hvo6	cmk199khj009t2mi0wi1jutmy	SEGUNDA-07:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:27:22.974	2026-01-12 13:27:22.974
cmkb76gkm00cs2mrmgbvvtngb	cmk199khj009t2mi0wi1jutmy	SEGUNDA-07:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:27:23.494	2026-01-12 13:27:23.494
cmkb76gzf00cu2mrmkn723v39	cmk199khj009t2mi0wi1jutmy	SEGUNDA-07:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:27:24.027	2026-01-12 13:27:24.027
cmkb76he300cw2mrmw4zietdw	cmk199khj009t2mi0wi1jutmy	SEGUNDA-07:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:27:24.555	2026-01-12 13:27:24.555
cmkb76hsg00cy2mrmbkw5dg7y	cmk199khj009t2mi0wi1jutmy	QUARTA-07:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:27:25.072	2026-01-12 13:27:25.072
cmkb76i6w00d02mrmmo8xkykb	cmk199khj009t2mi0wi1jutmy	QUARTA-07:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:27:25.592	2026-01-12 13:27:25.592
cmkb76ikt00d22mrmktu1yrdc	cmk199khj009t2mi0wi1jutmy	QUARTA-07:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:27:26.093	2026-01-12 13:27:26.093
cmkb76izd00d42mrmq7nwitru	cmk199khj009t2mi0wi1jutmy	QUARTA-07:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:27:26.617	2026-01-12 13:27:26.617
cmkb76jpu00d62mrmvk4egjuz	cmk199rqf00c22mi09zthn3to	SEGUNDA-07:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:27:27.57	2026-01-12 13:27:27.57
cmkb76k4j00d82mrmbwzmb7w9	cmk199rqf00c22mi09zthn3to	SEGUNDA-07:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:27:28.1	2026-01-12 13:27:28.1
cmkb76knk00da2mrm5o2f9pmg	cmk199rqf00c22mi09zthn3to	SEGUNDA-07:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:27:28.784	2026-01-12 13:27:28.784
cmkb76l1r00dc2mrmcfidggb9	cmk199rqf00c22mi09zthn3to	SEGUNDA-07:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:27:29.295	2026-01-12 13:27:29.295
cmkb76lg800de2mrmw0ra2nzb	cmk199rqf00c22mi09zthn3to	TERCA-07:00	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:29.816	2026-01-12 13:27:29.816
cmkb76lv700dg2mrmj13r06bx	cmk199rqf00c22mi09zthn3to	TERCA-07:00	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:30.356	2026-01-12 13:27:30.356
cmkb76maa00di2mrmmvxop9wt	cmk199rqf00c22mi09zthn3to	TERCA-07:00	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:30.899	2026-01-12 13:27:30.899
cmkb76mon00dk2mrm62kjkrv1	cmk199rqf00c22mi09zthn3to	TERCA-07:00	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:31.416	2026-01-12 13:27:31.416
cmkb76n2e00dm2mrmrkcsqgpd	cmk199rqf00c22mi09zthn3to	QUARTA-07:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:31.911	2026-01-12 13:27:31.911
cmkb76ng900do2mrmyehpuexk	cmk199rqf00c22mi09zthn3to	QUARTA-07:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:32.41	2026-01-12 13:27:32.41
cmkb76nuw00dq2mrm13agu0xd	cmk199rqf00c22mi09zthn3to	QUARTA-07:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:32.936	2026-01-12 13:27:32.936
cmkb76o9g00ds2mrmkd2xavm4	cmk199rqf00c22mi09zthn3to	QUARTA-07:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:27:33.46	2026-01-12 13:27:33.46
cmkb76onv00du2mrmb08r2ex7	cmk199rqf00c22mi09zthn3to	QUINTA-07:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:27:33.98	2026-01-12 13:27:33.98
cmkb76p1s00dw2mrmnrkdv0f6	cmk199rqf00c22mi09zthn3to	QUINTA-07:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:27:34.48	2026-01-12 13:27:34.48
cmkb76pg400dy2mrmgnort0as	cmk199rqf00c22mi09zthn3to	QUINTA-07:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:27:34.996	2026-01-12 13:27:34.996
cmkb76pu100e02mrmtj3m7hk9	cmk199rqf00c22mi09zthn3to	QUINTA-07:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:27:35.497	2026-01-12 13:27:35.497
cmkb76q8p00e22mrmj9pjag8e	cmk199rqf00c22mi09zthn3to	QUINTA-07:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:27:36.025	2026-01-12 13:27:36.025
cmkb76qn300e42mrmhvx2vpu0	cmk199rqf00c22mi09zthn3to	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:27:36.543	2026-01-12 13:27:36.543
cmkb76r1q00e62mrmhwzmsp44	cmk199rqf00c22mi09zthn3to	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:27:37.071	2026-01-12 13:27:37.071
cmkb76rg800e82mrmk552aqg7	cmk199rqf00c22mi09zthn3to	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:27:37.592	2026-01-12 13:27:37.592
cmkb76ru100ea2mrmebcz2k0p	cmk199rqf00c22mi09zthn3to	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:27:38.089	2026-01-12 13:27:38.089
cmkb76s8k00ec2mrmll6hz0a8	cmk199rqf00c22mi09zthn3to	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:27:38.613	2026-01-12 13:27:38.613
cmkb76swr00ee2mrmqgaxqwba	cmk199twf00cq2mi0vlqg5i7z	SEGUNDA-07:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:27:39.483	2026-01-12 13:27:39.483
cmkb76tba00eg2mrm1jshstp9	cmk199twf00cq2mi0vlqg5i7z	SEGUNDA-07:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:27:40.007	2026-01-12 13:27:40.007
cmkb76tp000ei2mrm6nywacvy	cmk199twf00cq2mi0vlqg5i7z	SEGUNDA-07:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:27:40.501	2026-01-12 13:27:40.501
cmkb76u3v00ek2mrmknhyf7kf	cmk199twf00cq2mi0vlqg5i7z	SEGUNDA-07:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:27:41.035	2026-01-12 13:27:41.035
cmkb76uih00em2mrmi0pli584	cmk199twf00cq2mi0vlqg5i7z	QUINTA-07:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:27:41.561	2026-01-12 13:27:41.561
cmkb76uws00eo2mrmlpn3ma33	cmk199twf00cq2mi0vlqg5i7z	QUINTA-07:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:27:42.076	2026-01-12 13:27:42.076
cmkb76vb900eq2mrm1kaqu3az	cmk199twf00cq2mi0vlqg5i7z	QUINTA-07:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:27:42.597	2026-01-12 13:27:42.597
cmkb76vp400es2mrmpxd98ntn	cmk199twf00cq2mi0vlqg5i7z	QUINTA-07:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:27:43.096	2026-01-12 13:27:43.096
cmkb76w3j00eu2mrmsi41ctrt	cmk199twf00cq2mi0vlqg5i7z	QUINTA-07:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:27:43.616	2026-01-12 13:27:43.616
cmkylqze40001kt041aqj1w56	cmk199c8o00782mi0i58xo9to	SEGUNDA-18:00	2026-02-02	\N	\N	2026-01-28 22:33:57.677	2026-01-28 22:47:36.317
cmkym96g60001jo04jbur3zt4	cmk1997o3005t2mi09sqsxelz	cmk2kq93w00542msamf8b9l44	2026-02-02	\N	\N	2026-01-28 22:48:06.631	2026-01-28 22:48:06.631
cmkyma9zs0003jo04ckw7hjh3	cmk199rqf00c22mi09zthn3to	cmk2kq8j5000y2msarfpfpk7o	2026-02-02	\N	\N	2026-01-28 22:48:57.881	2026-01-28 22:48:57.881
cmkymankk0005jo041m7m267j	cmk199bpg00722mi0h2liupqd	cmk2kq8j5000y2msarfpfpk7o	2026-02-02	\N	\N	2026-01-28 22:49:15.477	2026-01-28 22:49:15.477
cmkymb9n10007jo04gnjldgoz	cmk1998q400652mi0j3oh8k8f	SEGUNDA-06:00	2026-02-02	\N	\N	2026-01-28 22:49:44.077	2026-01-28 22:49:44.077
cmkymbzux0009jo04li197jr1	cmk199fyx008e2mi0fp972yif	cmk2kq8j5000y2msarfpfpk7o	2026-02-02	\N	\N	2026-01-28 22:50:18.058	2026-01-28 22:50:18.058
cmkymhjcz000bjo04uu580lzp	cmk199cic007b2mi0qtp5mco9	cmk2kq8j5000y2msarfpfpk7o	2026-02-02	\N	\N	2026-01-28 22:54:36.612	2026-01-28 22:54:36.612
cmkymk505000djo04xe9leka8	cmk199s0g00c52mi0i8p0t7p0	cmk2kq8j5000y2msarfpfpk7o	2026-02-02	\N	\N	2026-01-28 22:56:37.973	2026-01-28 22:56:37.973
cmkb775xe00g42mrmedhke16n	cmk198wig002b2mi06vqg92nm	SEGUNDA-07:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:27:56.355	2026-01-12 13:27:56.355
cmkb776bw00g62mrm2sn04d0m	cmk198wig002b2mi06vqg92nm	SEGUNDA-07:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:27:56.877	2026-01-12 13:27:56.877
cmkb776qm00g82mrmwdry93fv	cmk198wig002b2mi06vqg92nm	SEGUNDA-07:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:27:57.406	2026-01-12 13:27:57.406
cmkb7772h00ga2mrmcmraa6k9	cmk198wig002b2mi06vqg92nm	SEGUNDA-07:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:27:57.834	2026-01-12 13:27:57.834
cmkb777h200gc2mrm5kcnsepp	cmk198wig002b2mi06vqg92nm	QUINTA-07:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:27:58.358	2026-01-12 13:27:58.358
cmkb777y400ge2mrm3e1a2sot	cmk198wig002b2mi06vqg92nm	QUINTA-07:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:27:58.973	2026-01-12 13:27:58.973
cmkb778cp00gg2mrm3at15bdj	cmk198wig002b2mi06vqg92nm	QUINTA-07:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:27:59.498	2026-01-12 13:27:59.498
cmkb778r900gi2mrmrshuw5fj	cmk198wig002b2mi06vqg92nm	QUINTA-07:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:28:00.021	2026-01-12 13:28:00.021
cmkb7795v00gk2mrmgm9tszbv	cmk198wig002b2mi06vqg92nm	QUINTA-07:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:28:00.547	2026-01-12 13:28:00.547
cmkb77hiq00hn2mrmbny4azwf	cmk199bz100752mi0l1otqgsk	SEGUNDA-08:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:28:11.378	2026-01-12 13:28:11.378
cmkb77hwi00hp2mrmnjs8qc8s	cmk199bz100752mi0l1otqgsk	SEGUNDA-08:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:28:11.874	2026-01-12 13:28:11.874
cmkb77ib000hr2mrmie1ydpny	cmk199bz100752mi0l1otqgsk	SEGUNDA-08:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:28:12.396	2026-01-12 13:28:12.396
cmkb77ip800ht2mrmhy3xirul	cmk199bz100752mi0l1otqgsk	SEGUNDA-08:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:28:12.909	2026-01-12 13:28:12.909
cmkb77j3j00hv2mrmpipoe2tu	cmk199bz100752mi0l1otqgsk	QUARTA-08:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:28:13.424	2026-01-12 13:28:13.424
cmkb77jim00hx2mrmocq5r0a0	cmk199bz100752mi0l1otqgsk	QUARTA-08:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:28:13.967	2026-01-12 13:28:13.967
cmkb77jwx00hz2mrmt3bm53u4	cmk199bz100752mi0l1otqgsk	QUARTA-08:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:28:14.481	2026-01-12 13:28:14.481
cmkb77kb500i12mrmqcxydfvx	cmk199bz100752mi0l1otqgsk	QUARTA-08:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:28:14.993	2026-01-12 13:28:14.993
cmkb77kpv00i32mrm050hegbq	cmk199bz100752mi0l1otqgsk	SEXTA-08:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:28:15.524	2026-01-12 13:28:15.524
cmkb77l4800i52mrm3rcu78d6	cmk199bz100752mi0l1otqgsk	SEXTA-08:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:28:16.04	2026-01-12 13:28:16.04
cmkb77ljs00i72mrmj75rhi0d	cmk199bz100752mi0l1otqgsk	SEXTA-08:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:28:16.6	2026-01-12 13:28:16.6
cmkb77ly800i92mrm8pvp9s2i	cmk199bz100752mi0l1otqgsk	SEXTA-08:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:28:17.12	2026-01-12 13:28:17.12
cmkb77mcx00ib2mrmg93ga7bp	cmk199bz100752mi0l1otqgsk	SEXTA-08:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:28:17.649	2026-01-12 13:28:17.649
cmkb77n7j00ie2mrmcqy3yzj2	cmk199m3600ab2mi079i4s20x	cmkb77mzd00ic2mrmagrtkapf	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:28:18.751	2026-01-12 13:28:18.751
cmkb77nm700ig2mrmeoy6kjza	cmk199m3600ab2mi079i4s20x	cmkb77mzd00ic2mrmagrtkapf	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:28:19.28	2026-01-12 13:28:19.28
cmkb77o0n00ii2mrmrmtyi0kg	cmk199m3600ab2mi079i4s20x	cmkb77mzd00ic2mrmagrtkapf	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:28:19.799	2026-01-12 13:28:19.799
cmkb77of500ik2mrmuyol69rr	cmk199m3600ab2mi079i4s20x	cmkb77mzd00ic2mrmagrtkapf	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:28:20.322	2026-01-12 13:28:20.322
cmkb77otn00im2mrmum8ji9av	cmk199m3600ab2mi079i4s20x	cmk2kq8u3003r2msahxegmrk3	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:20.843	2026-01-12 13:28:20.843
cmkb77p7s00io2mrma1gaeulp	cmk199m3600ab2mi079i4s20x	cmk2kq8u3003r2msahxegmrk3	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:21.353	2026-01-12 13:28:21.353
cmkb77pm600iq2mrm2h59rprp	cmk199m3600ab2mi079i4s20x	cmk2kq8u3003r2msahxegmrk3	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:21.871	2026-01-12 13:28:21.871
cmkb77q0q00is2mrmic3n7kx8	cmk199m3600ab2mi079i4s20x	cmk2kq8u3003r2msahxegmrk3	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:22.395	2026-01-12 13:28:22.395
cmkb77qll00iv2mrmvf9875wn	cmk199m3600ab2mi079i4s20x	cmkb77qbc00it2mrm48myv7cm	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:23.146	2026-01-12 13:28:23.146
cmkb77r0300ix2mrm6k9ialnb	cmk199m3600ab2mi079i4s20x	cmkb77qbc00it2mrm48myv7cm	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:23.668	2026-01-12 13:28:23.668
cmkb77re400iz2mrmr6leq1c6	cmk199m3600ab2mi079i4s20x	cmkb77qbc00it2mrm48myv7cm	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:24.173	2026-01-12 13:28:24.173
cmkb77rsn00j12mrmksvbd3gs	cmk199m3600ab2mi079i4s20x	cmkb77qbc00it2mrm48myv7cm	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:24.695	2026-01-12 13:28:24.695
cmkb77s7400j32mrm5uxyrh2l	cmk199m3600ab2mi079i4s20x	cmkb77qbc00it2mrm48myv7cm	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:25.216	2026-01-12 13:28:25.216
cmkb77sva00j52mrmg6wjuk73	cmk199fpg008b2mi0xsa8dufo	cmkb77mzd00ic2mrmagrtkapf	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:28:26.086	2026-01-12 13:28:26.086
cmkb77t9400j72mrmqn3z85to	cmk199fpg008b2mi0xsa8dufo	cmkb77mzd00ic2mrmagrtkapf	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:28:26.584	2026-01-12 13:28:26.584
cmkb77tnq00j92mrm9w8sotjc	cmk199fpg008b2mi0xsa8dufo	cmkb77mzd00ic2mrmagrtkapf	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:28:27.111	2026-01-12 13:28:27.111
cmkb77u2f00jb2mrmoj9nozjo	cmk199fpg008b2mi0xsa8dufo	cmkb77mzd00ic2mrmagrtkapf	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:28:27.64	2026-01-12 13:28:27.64
cmkb77ugp00jd2mrm4hhu45ao	cmk199fpg008b2mi0xsa8dufo	cmk2kq8u3003r2msahxegmrk3	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:28.154	2026-01-12 13:28:28.154
cmkb77uv900jf2mrmj3fkpbur	cmk199fpg008b2mi0xsa8dufo	cmk2kq8u3003r2msahxegmrk3	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:28.677	2026-01-12 13:28:28.677
cmkb77va400jh2mrm1cb3u074	cmk199fpg008b2mi0xsa8dufo	cmk2kq8u3003r2msahxegmrk3	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:29.213	2026-01-12 13:28:29.213
cmkb77voe00jj2mrm65zy59q5	cmk199fpg008b2mi0xsa8dufo	cmk2kq8u3003r2msahxegmrk3	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:29.726	2026-01-12 13:28:29.726
cmkb77w2e00jl2mrmv3h0penx	cmk199fpg008b2mi0xsa8dufo	cmkb77qbc00it2mrm48myv7cm	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:30.23	2026-01-12 13:28:30.23
cmkb77wgv00jn2mrmb97hwjtc	cmk199fpg008b2mi0xsa8dufo	cmkb77qbc00it2mrm48myv7cm	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:30.752	2026-01-12 13:28:30.752
cmkb77wvg00jp2mrm00ttu58n	cmk199fpg008b2mi0xsa8dufo	cmkb77qbc00it2mrm48myv7cm	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:31.276	2026-01-12 13:28:31.276
cmkb77xav00jr2mrm5fr4oe62	cmk199fpg008b2mi0xsa8dufo	cmkb77qbc00it2mrm48myv7cm	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:31.831	2026-01-12 13:28:31.831
cmkb77xp600jt2mrm6x8154cf	cmk199fpg008b2mi0xsa8dufo	cmkb77qbc00it2mrm48myv7cm	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:32.347	2026-01-12 13:28:32.347
cmkb77yj400jw2mrmn1w7k9zc	cmk198v6k001w2mi02ivlhs3x	cmkb77yb500ju2mrmh718oogt	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:28:33.424	2026-01-12 13:28:33.424
cmkb77yx400jy2mrmn34lr97g	cmk198v6k001w2mi02ivlhs3x	cmkb77yb500ju2mrmh718oogt	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:28:33.929	2026-01-12 13:28:33.929
cmkb77zbi00k02mrmv306y59c	cmk198v6k001w2mi02ivlhs3x	cmkb77yb500ju2mrmh718oogt	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:28:34.446	2026-01-12 13:28:34.446
cmkb77zq200k22mrmsumdx5jm	cmk198v6k001w2mi02ivlhs3x	cmkb77yb500ju2mrmh718oogt	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:28:34.97	2026-01-12 13:28:34.97
cmkb784dk00k42mrmyn17ski8	cmk198v6k001w2mi02ivlhs3x	cmk2kqdht00kg2msa6bprjwd1	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:28:41	2026-01-12 13:28:41
cmkb784s400k62mrmg16eqo3t	cmk198v6k001w2mi02ivlhs3x	cmk2kqdht00kg2msa6bprjwd1	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:28:41.525	2026-01-12 13:28:41.525
cmkb7855v00k82mrm9vzlwdk5	cmk198v6k001w2mi02ivlhs3x	cmk2kqdht00kg2msa6bprjwd1	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:28:42.019	2026-01-12 13:28:42.019
cmkb785jo00ka2mrmtxvh88hg	cmk198v6k001w2mi02ivlhs3x	cmk2kqdht00kg2msa6bprjwd1	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:28:42.516	2026-01-12 13:28:42.516
cmkb78aek00kd2mrmujo0c4o5	cmk198v6k001w2mi02ivlhs3x	cmkb78a3u00kb2mrmtcyty4sp	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:28:48.812	2026-01-12 13:28:48.812
cmkb78at100kf2mrmxeaz3qqx	cmk198v6k001w2mi02ivlhs3x	cmkb78a3u00kb2mrmtcyty4sp	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:28:49.333	2026-01-12 13:28:49.333
cmkb78b7o00kh2mrm08xxiw9t	cmk198v6k001w2mi02ivlhs3x	cmkb78a3u00kb2mrmtcyty4sp	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:28:49.86	2026-01-12 13:28:49.86
cmkb78bm500kj2mrmsnq30oio	cmk198v6k001w2mi02ivlhs3x	cmkb78a3u00kb2mrmtcyty4sp	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:28:50.381	2026-01-12 13:28:50.381
cmkb78c0o00kl2mrmotgwm2iw	cmk198v6k001w2mi02ivlhs3x	cmkb78a3u00kb2mrmtcyty4sp	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:28:50.905	2026-01-12 13:28:50.905
cmkb78hzu00kn2mrm2z1asa4b	cmk199e3m007t2mi0ixoer361	cmkb77yb500ju2mrmh718oogt	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:58.65	2026-01-12 13:28:58.65
cmkb78iee00kp2mrm3rcpx6in	cmk199e3m007t2mi0ixoer361	cmkb77yb500ju2mrmh718oogt	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:59.175	2026-01-12 13:28:59.175
cmkb78isw00kr2mrmym0t3l7n	cmk199e3m007t2mi0ixoer361	cmkb77yb500ju2mrmh718oogt	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:28:59.696	2026-01-12 13:28:59.696
cmkb78j6u00kt2mrmnvmq4fci	cmk199e3m007t2mi0ixoer361	cmkb77yb500ju2mrmh718oogt	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:00.199	2026-01-12 13:29:00.199
cmkb78jla00kv2mrmre1w39yk	cmk199e3m007t2mi0ixoer361	cmk2kqdht00kg2msa6bprjwd1	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:00.719	2026-01-12 13:29:00.719
cmkb78jzu00kx2mrmnl623wn8	cmk199e3m007t2mi0ixoer361	cmk2kqdht00kg2msa6bprjwd1	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:01.242	2026-01-12 13:29:01.242
cmkb78kez00kz2mrmaqn0ke6t	cmk199e3m007t2mi0ixoer361	cmk2kqdht00kg2msa6bprjwd1	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:01.759	2026-01-12 13:29:01.759
cmkb78kt300l12mrmegf076n3	cmk199e3m007t2mi0ixoer361	cmk2kqdht00kg2msa6bprjwd1	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:02.295	2026-01-12 13:29:02.295
cmkb78l7s00l32mrm1bs5pgz3	cmk199e3m007t2mi0ixoer361	cmk2kqbe900fo2msazmsum81w	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:02.825	2026-01-12 13:29:02.825
cmkb78lm400l52mrmb6s2puj3	cmk199e3m007t2mi0ixoer361	cmk2kqbe900fo2msazmsum81w	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:03.34	2026-01-12 13:29:03.34
cmkb78m0k00l72mrmoyvpk3c6	cmk199e3m007t2mi0ixoer361	cmk2kqbe900fo2msazmsum81w	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:03.86	2026-01-12 13:29:03.86
cmkb78mei00l92mrmxzisczvp	cmk199e3m007t2mi0ixoer361	cmk2kqbe900fo2msazmsum81w	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:04.362	2026-01-12 13:29:04.362
cmkb78mt400lb2mrmon4mdi4q	cmk199e3m007t2mi0ixoer361	cmk2kqbe900fo2msazmsum81w	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:04.888	2026-01-12 13:29:04.888
cmkb78o5p00lg2mrmfrry2dvx	cmkb78nmz00le2mrmrxffixj2	cmkb77yb500ju2mrmh718oogt	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:06.637	2026-01-12 13:29:06.637
cmkb78ok400li2mrmosgyn7a5	cmkb78nmz00le2mrmrxffixj2	cmkb77yb500ju2mrmh718oogt	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:07.157	2026-01-12 13:29:07.157
cmkb78oyp00lk2mrmlg0yq21f	cmkb78nmz00le2mrmrxffixj2	cmkb77yb500ju2mrmh718oogt	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:07.681	2026-01-12 13:29:07.681
cmkb78pdb00lm2mrmiwguk7lq	cmkb78nmz00le2mrmrxffixj2	cmkb77yb500ju2mrmh718oogt	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:08.207	2026-01-12 13:29:08.207
cmkb799tl00mg2mrmffmgx2te	cmk199c8o00782mi0i58xo9to	cmkb78ptg00ln2mrmanq23795	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:34.714	2026-01-12 13:29:34.714
cmkb79a8c00mi2mrmr44e8zr3	cmk199c8o00782mi0i58xo9to	cmkb78ptg00ln2mrmanq23795	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:35.244	2026-01-12 13:29:35.244
cmkb79ams00mk2mrmd4rjij9a	cmk199c8o00782mi0i58xo9to	cmkb78ptg00ln2mrmanq23795	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:35.764	2026-01-12 13:29:35.764
cmkb79b8h00mm2mrm6bter6yl	cmk199c8o00782mi0i58xo9to	cmkb78ptg00ln2mrmanq23795	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:36.546	2026-01-12 13:29:36.546
cmkb79bmz00mo2mrme0bfraih	cmk199c8o00782mi0i58xo9to	cmk2mg5w300012m4kjy7imet4	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:37.068	2026-01-12 13:29:37.068
cmkb79c1l00mq2mrmj7zb4b5o	cmk199c8o00782mi0i58xo9to	cmk2mg5w300012m4kjy7imet4	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:37.593	2026-01-12 13:29:37.593
cmkb79cg200ms2mrm9yjovan9	cmk199c8o00782mi0i58xo9to	cmk2mg5w300012m4kjy7imet4	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:38.114	2026-01-12 13:29:38.114
cmkb79cum00mu2mrmjct8ux5k	cmk199c8o00782mi0i58xo9to	cmk2mg5w300012m4kjy7imet4	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:38.639	2026-01-12 13:29:38.639
cmkb79d9c00mw2mrmz3nf9cak	cmk199c8o00782mi0i58xo9to	cmk2kqdgp00jo2msa6sonzcpl	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:39.169	2026-01-12 13:29:39.169
cmkb79dnv00my2mrmj9qneo97	cmk199c8o00782mi0i58xo9to	cmk2kqdgp00jo2msa6sonzcpl	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:39.692	2026-01-12 13:29:39.692
cmkb79e2f00n02mrm07v67abj	cmk199c8o00782mi0i58xo9to	cmk2kqdgp00jo2msa6sonzcpl	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:40.216	2026-01-12 13:29:40.216
cmkb79eh200n22mrmr8832cgz	cmk199c8o00782mi0i58xo9to	cmk2kqdgp00jo2msa6sonzcpl	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:40.742	2026-01-12 13:29:40.742
cmkb79evl00n42mrm1xqv42ka	cmk199c8o00782mi0i58xo9to	cmk2kqa5800a82msa4t1kwix5	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:41.265	2026-01-12 13:29:41.265
cmkb79fa600n62mrmbtpcozqa	cmk199c8o00782mi0i58xo9to	cmk2kqa5800a82msa4t1kwix5	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:41.79	2026-01-12 13:29:41.79
cmkb79fos00n82mrmwsjfm5ph	cmk199c8o00782mi0i58xo9to	cmk2kqa5800a82msa4t1kwix5	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:42.316	2026-01-12 13:29:42.316
cmkb79g3h00na2mrmndzu85do	cmk199c8o00782mi0i58xo9to	cmk2kqa5800a82msa4t1kwix5	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:42.846	2026-01-12 13:29:42.846
cmkb79ghs00nc2mrm11x73k2q	cmk199c8o00782mi0i58xo9to	cmk2kqa5800a82msa4t1kwix5	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:43.36	2026-01-12 13:29:43.36
cmkb79gwe00ne2mrm21on63mp	cmk199c8o00782mi0i58xo9to	cmkb791rp00m42mrmp45o027x	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:43.887	2026-01-12 13:29:43.887
cmkb79hay00ng2mrmslgzgtrc	cmk199c8o00782mi0i58xo9to	cmkb791rp00m42mrmp45o027x	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:44.411	2026-01-12 13:29:44.411
cmkb79hpj00ni2mrm71ocyn00	cmk199c8o00782mi0i58xo9to	cmkb791rp00m42mrmp45o027x	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:44.935	2026-01-12 13:29:44.935
cmkb79i4400nk2mrmc1mg2gg1	cmk199c8o00782mi0i58xo9to	cmkb791rp00m42mrmp45o027x	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:45.46	2026-01-12 13:29:45.46
cmkb79iir00nm2mrmp4xxqz5u	cmk199c8o00782mi0i58xo9to	cmkb791rp00m42mrmp45o027x	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:29:45.987	2026-01-12 13:29:45.987
cmkb79unk00p72mrmih9stapm	cmk1997o3005t2mi09sqsxelz	cmk2kq93w00542msamf8b9l44	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:01.712	2026-01-12 13:30:01.712
cmkb79v2r00p92mrm8izhjg0e	cmk1997o3005t2mi09sqsxelz	cmk2kq93w00542msamf8b9l44	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:02.231	2026-01-12 13:30:02.231
cmkb79vhi00pb2mrmtp2fw1tb	cmk1997o3005t2mi09sqsxelz	cmk2kq93w00542msamf8b9l44	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:02.79	2026-01-12 13:30:02.79
cmkb79vvx00pd2mrm4jktsmxn	cmk1997o3005t2mi09sqsxelz	cmk2kq93w00542msamf8b9l44	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:03.31	2026-01-12 13:30:03.31
cmkb79wag00pf2mrmik7k9o6e	cmk1997o3005t2mi09sqsxelz	cmk2m1qun00002m4k4vi2rp9t	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:30:03.832	2026-01-12 13:30:03.832
cmkb79wp400ph2mrmdtwmnqou	cmk1997o3005t2mi09sqsxelz	cmk2m1qun00002m4k4vi2rp9t	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:30:04.36	2026-01-12 13:30:04.36
cmkb79x3100pj2mrmfzxm31s7	cmk1997o3005t2mi09sqsxelz	cmk2m1qun00002m4k4vi2rp9t	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:30:04.861	2026-01-12 13:30:04.861
cmkb79xhh00pl2mrmgg4iy7lb	cmk1997o3005t2mi09sqsxelz	cmk2m1qun00002m4k4vi2rp9t	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:30:05.381	2026-01-12 13:30:05.381
cmkb79xw100pn2mrmgvpcl5l2	cmk1997o3005t2mi09sqsxelz	cmk2kq94g005l2msadl37g9mr	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:05.905	2026-01-12 13:30:05.905
cmkb79yaj00pp2mrm1k830nq1	cmk1997o3005t2mi09sqsxelz	cmk2kq94g005l2msadl37g9mr	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:06.427	2026-01-12 13:30:06.427
cmkb79yp200pr2mrmd67fjq05	cmk1997o3005t2mi09sqsxelz	cmk2kq94g005l2msadl37g9mr	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:06.95	2026-01-12 13:30:06.95
cmkb79z3r00pt2mrmlntp4ko1	cmk1997o3005t2mi09sqsxelz	cmk2kq94g005l2msadl37g9mr	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:07.48	2026-01-12 13:30:07.48
cmkb79zia00pv2mrm1krwsw4w	cmk1997o3005t2mi09sqsxelz	cmk2kq95400652msatq98u949	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:08.002	2026-01-12 13:30:08.002
cmkb79zww00px2mrmb6pgwhuf	cmk1997o3005t2mi09sqsxelz	cmk2kq95400652msatq98u949	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:08.528	2026-01-12 13:30:08.528
cmkb7a0bb00pz2mrmx3w47f83	cmk1997o3005t2mi09sqsxelz	cmk2kq95400652msatq98u949	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:09.048	2026-01-12 13:30:09.048
cmkb7a0py00q12mrm4pwqknok	cmk1997o3005t2mi09sqsxelz	cmk2kq95400652msatq98u949	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:09.574	2026-01-12 13:30:09.574
cmkb7a14h00q32mrmfd39x05e	cmk1997o3005t2mi09sqsxelz	cmk2kq95400652msatq98u949	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:10.097	2026-01-12 13:30:10.097
cmkb7cmpm012f2mrm1aai92wy	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8kr002b2msamkksrgf5	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:11.386	2026-01-12 13:32:11.386
cmkb7cn41012h2mrmh7cxujo4	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8kr002b2msamkksrgf5	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:11.906	2026-01-12 13:32:11.906
cmkb7cniu012j2mrmkbx8b7sj	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8kr002b2msamkksrgf5	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:12.438	2026-01-12 13:32:12.438
cmkb7cnwz012l2mrmhyabn2ht	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8kr002b2msamkksrgf5	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:12.947	2026-01-12 13:32:12.947
cmkb7coaz012n2mrmbnh9tnk8	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8lx003d2msaicgiovas	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:13.451	2026-01-12 13:32:13.451
cmkb7copt012p2mrmiwiurvuf	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8lx003d2msaicgiovas	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:13.985	2026-01-12 13:32:13.985
cmkb7cp44012r2mrmhrlkvpl3	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8lx003d2msaicgiovas	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:14.501	2026-01-12 13:32:14.501
cmkb7cpii012t2mrmkd2hqkx6	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8lx003d2msaicgiovas	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:15.019	2026-01-12 13:32:15.019
cmkb7cpwx012v2mrmctido1au	cmkb7cm9n012d2mrmdxpg6lii	cmk2kq8lx003d2msaicgiovas	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:15.537	2026-01-12 13:32:15.537
cmkb7ah5x00s62mrm4bep1i8g	cmk2kqanj00co2msaur8cwfez	cmk2kq8j5000y2msarfpfpk7o	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:30.885	2026-01-12 13:30:30.885
cmkb7ahk700s82mrmpxk4q682	cmk2kqanj00co2msaur8cwfez	cmk2kq8j5000y2msarfpfpk7o	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:31.399	2026-01-12 13:30:31.399
cmkb7ahye00sa2mrmx6i1nsjy	cmk2kqanj00co2msaur8cwfez	cmk2kq8j5000y2msarfpfpk7o	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:31.91	2026-01-12 13:30:31.91
cmkb7aid100sc2mrm2g9mz0pe	cmk2kqanj00co2msaur8cwfez	cmk2kq8j5000y2msarfpfpk7o	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:32.437	2026-01-12 13:30:32.437
cmkb7airq00se2mrm93f3jwrk	cmk2kqanj00co2msaur8cwfez	cmk2kq8jt001g2msaiyh21pmu	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:32.966	2026-01-12 13:30:32.966
cmkb7aj6b00sg2mrm66d1joqz	cmk2kqanj00co2msaur8cwfez	cmk2kq8jt001g2msaiyh21pmu	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:33.492	2026-01-12 13:30:33.492
cmkb7ajko00si2mrmpdk51nce	cmk2kqanj00co2msaur8cwfez	cmk2kq8jt001g2msaiyh21pmu	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:34.008	2026-01-12 13:30:34.008
cmkb7ajzd00sk2mrmfcuwpy53	cmk2kqanj00co2msaur8cwfez	cmk2kq8jt001g2msaiyh21pmu	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:34.537	2026-01-12 13:30:34.537
cmkb7ake100sm2mrm3vp9e0t0	cmk2kqanj00co2msaur8cwfez	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:35.061	2026-01-12 13:30:35.061
cmkb7aksk00so2mrmf3dnk02a	cmk2kqanj00co2msaur8cwfez	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:35.588	2026-01-12 13:30:35.588
cmkb7al6z00sq2mrmwltfyn6s	cmk2kqanj00co2msaur8cwfez	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:36.107	2026-01-12 13:30:36.107
cmkb7allg00ss2mrmpyse2dxg	cmk2kqanj00co2msaur8cwfez	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:36.629	2026-01-12 13:30:36.629
cmkb7alza00su2mrmjqb937zy	cmk2kqanj00co2msaur8cwfez	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:37.127	2026-01-12 13:30:37.127
cmkb7an5z00sz2mrmbkqjhvsz	cmkb7amq600sx2mrmpwk39iog	cmk2kq8j5000y2msarfpfpk7o	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:30:38.663	2026-01-12 13:30:38.663
cmkb7cwn2013q2mrmnj3rqhvg	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8kr002b2msamkksrgf5	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:24.255	2026-01-12 13:32:24.255
cmkb7cx1o013s2mrmsw3npk0r	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8kr002b2msamkksrgf5	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:24.781	2026-01-12 13:32:24.781
cmkb7ank400t12mrmnyt8obdl	cmkb7amq600sx2mrmpwk39iog	cmk2kq8j5000y2msarfpfpk7o	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:30:39.172	2026-01-12 13:30:39.172
cmkb7anyo00t32mrmjr1x2dm4	cmkb7amq600sx2mrmpwk39iog	cmk2kq8j5000y2msarfpfpk7o	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:30:39.696	2026-01-12 13:30:39.696
cmkb7aod000t52mrmilfqyuj6	cmkb7amq600sx2mrmpwk39iog	cmk2kq8j5000y2msarfpfpk7o	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:30:40.212	2026-01-12 13:30:40.212
cmkb7aoqs00t72mrmq76iu0ex	cmkb7amq600sx2mrmpwk39iog	cmk2kq8jt001g2msaiyh21pmu	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:30:40.708	2026-01-12 13:30:40.708
cmkb7ap5b00t92mrmgf4pwygv	cmkb7amq600sx2mrmpwk39iog	cmk2kq8jt001g2msaiyh21pmu	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:30:41.232	2026-01-12 13:30:41.232
cmkb7apje00tb2mrm65miv7gw	cmkb7amq600sx2mrmpwk39iog	cmk2kq8jt001g2msaiyh21pmu	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:30:41.738	2026-01-12 13:30:41.738
cmkb7apxo00td2mrm98xy6dlw	cmkb7amq600sx2mrmpwk39iog	cmk2kq8jt001g2msaiyh21pmu	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:30:42.253	2026-01-12 13:30:42.253
cmkb7aqbm00tf2mrm0ctn2fvh	cmkb7amq600sx2mrmpwk39iog	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:30:42.754	2026-01-12 13:30:42.754
cmkb7aqq100th2mrmcjd784ua	cmkb7amq600sx2mrmpwk39iog	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:30:43.273	2026-01-12 13:30:43.273
cmkb7ar4p00tj2mrmyr12agzy	cmkb7amq600sx2mrmpwk39iog	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:30:43.801	2026-01-12 13:30:43.801
cmkb7arjd00tl2mrmm6k040om	cmkb7amq600sx2mrmpwk39iog	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:30:44.329	2026-01-12 13:30:44.329
cmkb7arxz00tn2mrmpe9xl35f	cmkb7amq600sx2mrmpwk39iog	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:30:44.855	2026-01-12 13:30:44.855
cmkb7ay5700uf2mrmp5t5o6dt	cmk198xki002n2mi0ld2bpbxf	cmk2kq8j5000y2msarfpfpk7o	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:30:52.892	2026-01-12 13:30:52.892
cmkb7ayjs00uh2mrmfgyw92p3	cmk198xki002n2mi0ld2bpbxf	cmk2kq8j5000y2msarfpfpk7o	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:30:53.417	2026-01-12 13:30:53.417
cmkb7ayy500uj2mrmb8znxlfy	cmk198xki002n2mi0ld2bpbxf	cmk2kq8j5000y2msarfpfpk7o	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:30:53.933	2026-01-12 13:30:53.933
cmkb7azcq00ul2mrmkma2wkjj	cmk198xki002n2mi0ld2bpbxf	cmk2kq8j5000y2msarfpfpk7o	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:30:54.459	2026-01-12 13:30:54.459
cmkb7azrj00un2mrmsh813abh	cmk198xki002n2mi0ld2bpbxf	cmk2kq8jt001g2msaiyh21pmu	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:30:54.991	2026-01-12 13:30:54.991
cmkb7b06100up2mrmh93ozo8y	cmk198xki002n2mi0ld2bpbxf	cmk2kq8jt001g2msaiyh21pmu	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:30:55.514	2026-01-12 13:30:55.514
cmkb7b0kr00ur2mrmh31nrgys	cmk198xki002n2mi0ld2bpbxf	cmk2kq8jt001g2msaiyh21pmu	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:30:56.044	2026-01-12 13:30:56.044
cmkb7b0z000ut2mrmtfq7yghq	cmk198xki002n2mi0ld2bpbxf	cmk2kq8jt001g2msaiyh21pmu	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:30:56.556	2026-01-12 13:30:56.556
cmkb7b1di00uv2mrmipqlysy8	cmk198xki002n2mi0ld2bpbxf	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:57.079	2026-01-12 13:30:57.079
cmkb7b1s400ux2mrm7j3q4fbq	cmk198xki002n2mi0ld2bpbxf	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:57.604	2026-01-12 13:30:57.604
cmkb7b26j00uz2mrmoxzggtn7	cmk198xki002n2mi0ld2bpbxf	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:58.123	2026-01-12 13:30:58.123
cmkb7b2kw00v12mrm07ozq7bb	cmk198xki002n2mi0ld2bpbxf	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:58.64	2026-01-12 13:30:58.64
cmkb7b2z100v32mrmwhz4qxs6	cmk198xki002n2mi0ld2bpbxf	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:30:59.149	2026-01-12 13:30:59.149
cmkb7b3pq00v52mrmfafkakte	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8j5000y2msarfpfpk7o	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:00.11	2026-01-12 13:31:00.11
cmkb7b45200v72mrmhrd5frl2	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8j5000y2msarfpfpk7o	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:00.663	2026-01-12 13:31:00.663
cmkb7b4jt00v92mrmxb062o7v	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8j5000y2msarfpfpk7o	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:01.194	2026-01-12 13:31:01.194
cmkb7b4yc00vb2mrmlr50h612	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8j5000y2msarfpfpk7o	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:01.717	2026-01-12 13:31:01.717
cmkb7b5cp00vd2mrme3ho9rg6	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8jt001g2msaiyh21pmu	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:02.233	2026-01-12 13:31:02.233
cmkb7b5ri00vf2mrmocgtzivo	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8jt001g2msaiyh21pmu	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:02.767	2026-01-12 13:31:02.767
cmkb7b66800vh2mrmeo9jkz78	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8jt001g2msaiyh21pmu	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:03.297	2026-01-12 13:31:03.297
cmkb7b6ke00vj2mrmjei8vx3s	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8jt001g2msaiyh21pmu	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:03.806	2026-01-12 13:31:03.806
cmkb7b6yy00vl2mrm2brza7hf	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:04.331	2026-01-12 13:31:04.331
cmkb7b7dl00vn2mrmppyt5nxd	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:04.858	2026-01-12 13:31:04.858
cmkb7b7s600vp2mrmkwnf3ytd	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:05.382	2026-01-12 13:31:05.382
cmkb7b86r00vr2mrmkub0bp8g	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:05.908	2026-01-12 13:31:05.908
cmkb7b8le00vt2mrmyxq93dld	cmk1993ou004k2mi0o0iyh8eu	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:06.434	2026-01-12 13:31:06.434
cmkb7b97v00vv2mrms45anbni	cmk2kqawv00dz2msarz5blzno	cmk2kq8j5000y2msarfpfpk7o	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:31:07.244	2026-01-12 13:31:07.244
cmkb7b9mh00vx2mrmf2dll7c5	cmk2kqawv00dz2msarz5blzno	cmk2kq8j5000y2msarfpfpk7o	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:31:07.769	2026-01-12 13:31:07.769
cmkb7ba1300vz2mrm0zms8dn4	cmk2kqawv00dz2msarz5blzno	cmk2kq8j5000y2msarfpfpk7o	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:31:08.295	2026-01-12 13:31:08.295
cmkb7bafk00w12mrm10c4rwig	cmk2kqawv00dz2msarz5blzno	cmk2kq8j5000y2msarfpfpk7o	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:31:08.817	2026-01-12 13:31:08.817
cmkb7bau500w32mrmho317rjf	cmk2kqawv00dz2msarz5blzno	cmk2kq8jt001g2msaiyh21pmu	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:31:09.341	2026-01-12 13:31:09.341
cmkb7bb8p00w52mrm2y5xwgnf	cmk2kqawv00dz2msarz5blzno	cmk2kq8jt001g2msaiyh21pmu	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:31:09.865	2026-01-12 13:31:09.865
cmkb7bbn800w72mrmiokcy86l	cmk2kqawv00dz2msarz5blzno	cmk2kq8jt001g2msaiyh21pmu	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:31:10.388	2026-01-12 13:31:10.388
cmkb7bc1w00w92mrm9qsyg7ua	cmk2kqawv00dz2msarz5blzno	cmk2kq8jt001g2msaiyh21pmu	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:31:10.916	2026-01-12 13:31:10.916
cmkb7bcgg00wb2mrmva85wzju	cmk2kqawv00dz2msarz5blzno	cmk2kq8ke00202msas9foc61a	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:11.44	2026-01-12 13:31:11.44
cmkb7bcv200wd2mrmz3tulwce	cmk2kqawv00dz2msarz5blzno	cmk2kq8ke00202msas9foc61a	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:11.967	2026-01-12 13:31:11.967
cmkb7bd9i00wf2mrmlz1t951c	cmk2kqawv00dz2msarz5blzno	cmk2kq8ke00202msas9foc61a	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:12.487	2026-01-12 13:31:12.487
cmkb7bdo300wh2mrm57zib370	cmk2kqawv00dz2msarz5blzno	cmk2kq8ke00202msas9foc61a	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:13.011	2026-01-12 13:31:13.011
cmkb7be2o00wj2mrm2daxyi8u	cmk2kqawv00dz2msarz5blzno	cmk2kq8ke00202msas9foc61a	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:13.536	2026-01-12 13:31:13.536
cmkb7cxg6013u2mrm4txmh3xd	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8kr002b2msamkksrgf5	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:25.303	2026-01-12 13:32:25.303
cmkb7cxuu013w2mrmi3ob0hfe	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8kr002b2msamkksrgf5	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:25.83	2026-01-12 13:32:25.83
cmkb7cy9g013y2mrm9edquzka	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8lx003d2msaicgiovas	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:26.356	2026-01-12 13:32:26.356
cmkb7cynz01402mrm9hubgggb	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8lx003d2msaicgiovas	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:26.879	2026-01-12 13:32:26.879
cmkb7cz2i01422mrm9w094l48	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8lx003d2msaicgiovas	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:27.402	2026-01-12 13:32:27.402
cmkb7czh101442mrmszv4p1ms	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8lx003d2msaicgiovas	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:27.926	2026-01-12 13:32:27.926
cmkb7czvp01462mrmv316epmr	cmkb7cw5i013o2mrmzcc043sb	cmk2kq8lx003d2msaicgiovas	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:28.453	2026-01-12 13:32:28.453
cmkb7dae7015j2mrmh7y3bbf4	cmk198pbt00022mi0uothgwyv	SEGUNDA-17:00	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:42.079	2026-01-12 13:32:42.079
cmkb7dast015l2mrma85l71vf	cmk198pbt00022mi0uothgwyv	SEGUNDA-17:00	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:42.605	2026-01-12 13:32:42.605
cmkb7db7d015n2mrmlidrmumm	cmk198pbt00022mi0uothgwyv	SEGUNDA-17:00	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:43.129	2026-01-12 13:32:43.129
cmkb7dblw015p2mrmq4bzuiog	cmk198pbt00022mi0uothgwyv	SEGUNDA-17:00	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:43.653	2026-01-12 13:32:43.653
cmkb7dc0g015r2mrmgb9x55hq	cmk198pbt00022mi0uothgwyv	QUINTA-17:00	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:44.176	2026-01-12 13:32:44.176
cmkb7dcf4015t2mrm4cchd13p	cmk198pbt00022mi0uothgwyv	QUINTA-17:00	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:44.703	2026-01-12 13:32:44.703
cmkb7dcto015v2mrmwdb27j3a	cmk198pbt00022mi0uothgwyv	QUINTA-17:00	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:45.228	2026-01-12 13:32:45.228
cmkb7dd85015x2mrmy61r4fmf	cmk198pbt00022mi0uothgwyv	QUINTA-17:00	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:45.75	2026-01-12 13:32:45.75
cmkb7ddmt015z2mrmeg8q1mp6	cmk198pbt00022mi0uothgwyv	QUINTA-17:00	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:32:46.277	2026-01-12 13:32:46.277
cmkb7bs1000yc2mrm401m7ae9	cmk1993f9004h2mi0fqdke02o	cmk2kq8kr002b2msamkksrgf5	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:31.621	2026-01-12 13:31:31.621
cmkb7bsfx00ye2mrmsbh7ksjl	cmk1993f9004h2mi0fqdke02o	cmk2kq8kr002b2msamkksrgf5	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:32.157	2026-01-12 13:31:32.157
cmkb7bsub00yg2mrmqbfrqklq	cmk1993f9004h2mi0fqdke02o	cmk2kq8kr002b2msamkksrgf5	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:32.676	2026-01-12 13:31:32.676
cmkb7bwxq00z02mrmw8n45rg8	cmk1993f9004h2mi0fqdke02o	cmk2kq8lm00322msas3daxefo	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:37.982	2026-01-12 13:31:37.982
cmkb7bxch00z22mrmvmzl95cw	cmk1993f9004h2mi0fqdke02o	cmk2kq8lm00322msas3daxefo	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:38.513	2026-01-12 13:31:38.513
cmkb7bxr400z42mrm8jd6f5yq	cmk1993f9004h2mi0fqdke02o	cmk2kq8lm00322msas3daxefo	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:39.04	2026-01-12 13:31:39.04
cmkb7by5h00z62mrmo44y7218	cmk1993f9004h2mi0fqdke02o	cmk2kq8lm00322msas3daxefo	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:39.558	2026-01-12 13:31:39.558
cmkb7byjv00z82mrmkd6lcfy3	cmk1993f9004h2mi0fqdke02o	cmk2kq8lm00322msas3daxefo	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:40.075	2026-01-12 13:31:40.075
cmkb7byy500za2mrmgditrthw	cmk1993f9004h2mi0fqdke02o	cmk2kq8lx003d2msaicgiovas	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:40.59	2026-01-12 13:31:40.59
cmkb7bzbx00zc2mrm5skz6d3r	cmk1993f9004h2mi0fqdke02o	cmk2kq8lx003d2msaicgiovas	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:41.085	2026-01-12 13:31:41.085
cmkb7bzqf00ze2mrmbplbl3bc	cmk1993f9004h2mi0fqdke02o	cmk2kq8lx003d2msaicgiovas	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:41.608	2026-01-12 13:31:41.608
cmkb7c04m00zg2mrm1hbzjbb7	cmk1993f9004h2mi0fqdke02o	cmk2kq8lx003d2msaicgiovas	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:42.118	2026-01-12 13:31:42.118
cmkb7c0j300zi2mrmkvyf5of4	cmk1993f9004h2mi0fqdke02o	cmk2kq8lx003d2msaicgiovas	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:42.639	2026-01-12 13:31:42.639
cmkb7c6r1010a2mrm2us07tip	cmk198xtz002q2mi0oynknikc	cmk2kq8kr002b2msamkksrgf5	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:50.701	2026-01-12 13:31:50.701
cmkb7c75m010c2mrmcsk7ipmn	cmk198xtz002q2mi0oynknikc	cmk2kq8kr002b2msamkksrgf5	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:51.226	2026-01-12 13:31:51.226
cmkb7c7ka010e2mrmg1qyop5n	cmk198xtz002q2mi0oynknikc	cmk2kq8kr002b2msamkksrgf5	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:51.754	2026-01-12 13:31:51.754
cmkb7c7yt010g2mrmsli2j91w	cmk198xtz002q2mi0oynknikc	cmk2kq8kr002b2msamkksrgf5	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:52.277	2026-01-12 13:31:52.277
cmkb7drz0017v2mrmropfsj1q	cmk199g8l008h2mi0oa3cch2x	SEGUNDA-17:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:33:04.86	2026-01-12 13:33:04.86
cmkb7dsdf017x2mrmgm9mctpq	cmk199g8l008h2mi0oa3cch2x	SEGUNDA-17:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:33:05.379	2026-01-12 13:33:05.379
cmkb7dsrt017z2mrmun5bmlwr	cmk199g8l008h2mi0oa3cch2x	SEGUNDA-17:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:33:05.898	2026-01-12 13:33:05.898
cmkb7dt5o01812mrm0csdch46	cmk199g8l008h2mi0oa3cch2x	SEGUNDA-17:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:33:06.396	2026-01-12 13:33:06.396
cmkb7dtjf01832mrmqkx9vt7k	cmk199g8l008h2mi0oa3cch2x	QUARTA-17:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:33:06.891	2026-01-12 13:33:06.891
cmkb7dtxw01852mrm20564i8q	cmk199g8l008h2mi0oa3cch2x	QUARTA-17:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:33:07.413	2026-01-12 13:33:07.413
cmkb7dubt01872mrm34cpgyod	cmk199g8l008h2mi0oa3cch2x	QUARTA-17:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:33:07.913	2026-01-12 13:33:07.913
cmkb7dvin018d2mrms5wcgj3x	cmk199g8l008h2mi0oa3cch2x	SEXTA-17:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:33:09.455	2026-01-12 13:33:09.455
cmkb7dvwg018f2mrmip3yh0lp	cmk199g8l008h2mi0oa3cch2x	SEXTA-17:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:33:09.952	2026-01-12 13:33:09.952
cmkb7dwa7018h2mrmq1xehpjm	cmk199g8l008h2mi0oa3cch2x	SEXTA-17:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:33:10.448	2026-01-12 13:33:10.448
cmkb7dwop018j2mrm40xmqtkf	cmk199g8l008h2mi0oa3cch2x	SEXTA-17:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:33:10.97	2026-01-12 13:33:10.97
cmkb7dx38018l2mrms2jciebs	cmk199g8l008h2mi0oa3cch2x	SABADO-08:00	2026-01-03	\N	Instrutor: GABI	2026-01-12 13:33:11.492	2026-01-12 13:33:11.492
cmkb7dxh3018n2mrmegpgf7fg	cmk199g8l008h2mi0oa3cch2x	SABADO-08:00	2026-01-10	\N	Instrutor: GABI	2026-01-12 13:33:11.991	2026-01-12 13:33:11.991
cmkb7dxuw018p2mrminskc3oc	cmk199g8l008h2mi0oa3cch2x	SABADO-08:00	2026-01-17	\N	Instrutor: GABI	2026-01-12 13:33:12.488	2026-01-12 13:33:12.488
cmkb7dy6r018r2mrm3lhg3zwh	cmk199g8l008h2mi0oa3cch2x	SABADO-08:00	2026-01-24	\N	Instrutor: GABI	2026-01-12 13:33:12.915	2026-01-12 13:33:12.915
cmkb7dyki018t2mrmg004aomr	cmk199g8l008h2mi0oa3cch2x	SABADO-08:00	2026-01-31	\N	Instrutor: GABI	2026-01-12 13:33:13.41	2026-01-12 13:33:13.41
cmkb7dz9p018v2mrm6k3hcwqg	cmk1ezw3100cz2mi0mg127gqi	SEGUNDA-17:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:33:14.317	2026-01-12 13:33:14.317
cmkb7dzni018x2mrmq1ri52jj	cmk1ezw3100cz2mi0mg127gqi	SEGUNDA-17:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:33:14.815	2026-01-12 13:33:14.815
cmkb7e020018z2mrm37kg0wf6	cmk1ezw3100cz2mi0mg127gqi	SEGUNDA-17:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:33:15.337	2026-01-12 13:33:15.337
cmkb7enl501c52mrmfj36zfl0	cmk199l0m009z2mi0o4jc5stf	SEGUNDA-18:00	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:45.833	2026-01-12 13:33:45.833
cmkb7enzo01c72mrmf4ijshqy	cmk199l0m009z2mi0o4jc5stf	SEGUNDA-18:00	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:46.357	2026-01-12 13:33:46.357
cmkb7eoe601c92mrmgtzgw4z9	cmk199l0m009z2mi0o4jc5stf	SEGUNDA-18:00	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:46.879	2026-01-12 13:33:46.879
cmkb7eotn01cb2mrmz3109fuf	cmk199l0m009z2mi0o4jc5stf	SEGUNDA-18:00	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:47.435	2026-01-12 13:33:47.435
cmkb7ep8201cd2mrmr4hjo03g	cmk199l0m009z2mi0o4jc5stf	QUARTA-18:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:47.954	2026-01-12 13:33:47.954
cmkb7eplv01cf2mrmnno09d38	cmk199l0m009z2mi0o4jc5stf	QUARTA-18:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:48.451	2026-01-12 13:33:48.451
cmkb7eq0g01ch2mrmpkfe24z7	cmk199l0m009z2mi0o4jc5stf	QUARTA-18:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:48.976	2026-01-12 13:33:48.976
cmkb7eqe701cj2mrmk9sd3152	cmk199l0m009z2mi0o4jc5stf	QUARTA-18:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:49.471	2026-01-12 13:33:49.471
cmkb73ps500012mrmscpyig3t	cmk1998zo00682mi0mjhxpnpw	cmk2i2sqh00002mcj8khig5hz	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:25:15.461	2026-01-12 13:25:15.461
cmkb7bt8u00yi2mrmm54d52de	cmk1993f9004h2mi0fqdke02o	cmk2kq8kr002b2msamkksrgf5	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:33.199	2026-01-12 13:31:33.199
cmkb7btor00yk2mrmoex1lfrc	cmk1993f9004h2mi0fqdke02o	cmk2kq8ji00172msal7kljpg1	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:33.772	2026-01-12 13:31:33.772
cmkb7bu3o00ym2mrmdnx489j5	cmk1993f9004h2mi0fqdke02o	cmk2kq8ji00172msal7kljpg1	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:34.309	2026-01-12 13:31:34.309
cmkb7bui000yo2mrmo9wl0zjl	cmk1993f9004h2mi0fqdke02o	cmk2kq8ji00172msal7kljpg1	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:34.825	2026-01-12 13:31:34.825
cmkb7buwk00yq2mrmbhcc3rw3	cmk1993f9004h2mi0fqdke02o	cmk2kq8ji00172msal7kljpg1	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:35.348	2026-01-12 13:31:35.348
cmkb7bvbh00ys2mrmnc19pefh	cmk1993f9004h2mi0fqdke02o	cmk2kq8lc002t2msag1rmi700	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:35.886	2026-01-12 13:31:35.886
cmkb7bvpy00yu2mrm4kps22fo	cmk1993f9004h2mi0fqdke02o	cmk2kq8lc002t2msag1rmi700	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:36.406	2026-01-12 13:31:36.406
cmkb7bw4800yw2mrm77odxec9	cmk1993f9004h2mi0fqdke02o	cmk2kq8lc002t2msag1rmi700	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:36.921	2026-01-12 13:31:36.921
cmkb7bwj200yy2mrmeit1zkxm	cmk1993f9004h2mi0fqdke02o	cmk2kq8lc002t2msag1rmi700	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:31:37.455	2026-01-12 13:31:37.455
cmkb7dupk01892mrm2w3jdkmv	cmk199g8l008h2mi0oa3cch2x	QUARTA-17:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:33:08.409	2026-01-12 13:33:08.409
cmkb7dv48018b2mrmt6xfs35k	cmk199g8l008h2mi0oa3cch2x	SEXTA-17:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:33:08.936	2026-01-12 13:33:08.936
cmkb7e0fv01912mrm21u5rgc1	cmk1ezw3100cz2mi0mg127gqi	SEGUNDA-17:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:33:15.835	2026-01-12 13:33:15.835
cmkb7e0ub01932mrm9x3n2msz	cmk1ezw3100cz2mi0mg127gqi	QUARTA-17:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:33:16.355	2026-01-12 13:33:16.355
cmkb7e19501952mrm4kklr4s7	cmk1ezw3100cz2mi0mg127gqi	QUARTA-17:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:33:16.89	2026-01-12 13:33:16.89
cmkb7e1nh01972mrmk841rodq	cmk1ezw3100cz2mi0mg127gqi	QUARTA-17:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:33:17.405	2026-01-12 13:33:17.405
cmkb7e21c01992mrmy7bkkhf2	cmk1ezw3100cz2mi0mg127gqi	QUARTA-17:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:33:17.904	2026-01-12 13:33:17.904
cmkb7e2s2019b2mrm4z2p58to	cmk198unf001q2mi0mwzfdm8t	SEGUNDA-18:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:33:18.866	2026-01-12 13:33:18.866
cmkb7e35v019d2mrm8jetbhkl	cmk198unf001q2mi0mwzfdm8t	SEGUNDA-18:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:33:19.363	2026-01-12 13:33:19.363
cmkb7e3k9019f2mrma1o5e1en	cmk198unf001q2mi0mwzfdm8t	SEGUNDA-18:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:33:19.881	2026-01-12 13:33:19.881
cmkb7e3yy019h2mrm13l51ux2	cmk198unf001q2mi0mwzfdm8t	SEGUNDA-18:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:33:20.41	2026-01-12 13:33:20.41
cmkb7e4dc019j2mrmrx5zcgvv	cmk198unf001q2mi0mwzfdm8t	QUARTA-18:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:33:20.929	2026-01-12 13:33:20.929
cmkb7e4r8019l2mrmn7op3xdj	cmk198unf001q2mi0mwzfdm8t	QUARTA-18:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:33:21.428	2026-01-12 13:33:21.428
cmkb7e55s019n2mrm0g9unjpe	cmk198unf001q2mi0mwzfdm8t	QUARTA-18:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:33:21.952	2026-01-12 13:33:21.952
cmkb7e5jl019p2mrmijttpbf8	cmk198unf001q2mi0mwzfdm8t	QUARTA-18:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:33:22.449	2026-01-12 13:33:22.449
cmkb7e5vh019r2mrmkpl1f4ly	cmk198unf001q2mi0mwzfdm8t	SEXTA-18:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:33:22.877	2026-01-12 13:33:22.877
cmkb7e69a019t2mrml5xjj23i	cmk198unf001q2mi0mwzfdm8t	SEXTA-18:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:33:23.375	2026-01-12 13:33:23.375
cmkb7e6nq019v2mrmvzfvq5w1	cmk198unf001q2mi0mwzfdm8t	SEXTA-18:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:33:23.895	2026-01-12 13:33:23.895
cmkb7e726019x2mrmz08rtpo3	cmk198unf001q2mi0mwzfdm8t	SEXTA-18:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:33:24.414	2026-01-12 13:33:24.414
cmkb7e7gi019z2mrmawijv8kr	cmk198unf001q2mi0mwzfdm8t	SEXTA-18:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:33:24.93	2026-01-12 13:33:24.93
cmkb7eqst01cl2mrm3bxo8i90	cmk199l0m009z2mi0o4jc5stf	QUINTA-18:00	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:49.997	2026-01-12 13:33:49.997
cmkb7er7401cn2mrmr8by0lae	cmk199l0m009z2mi0o4jc5stf	QUINTA-18:00	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:50.513	2026-01-12 13:33:50.513
cmkb7erl701cp2mrmr9ch2v10	cmk199l0m009z2mi0o4jc5stf	QUINTA-18:00	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:51.02	2026-01-12 13:33:51.02
cmkb7erzj01cr2mrm4lscyb35	cmk199l0m009z2mi0o4jc5stf	QUINTA-18:00	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:51.535	2026-01-12 13:33:51.535
cmkb7esdc01ct2mrm437nbpul	cmk199l0m009z2mi0o4jc5stf	QUINTA-18:00	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:33:52.033	2026-01-12 13:33:52.033
cmkb7et3c01cv2mrmn2pzw3rm	cmk198vpt00222mi0p1etbg19	SEGUNDA-18:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:33:52.968	2026-01-12 13:33:52.968
cmkb7etha01cx2mrmoflsqnlt	cmk198vpt00222mi0p1etbg19	SEGUNDA-18:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:33:53.47	2026-01-12 13:33:53.47
cmkb7etvo01cz2mrmdv0otevo	cmk198vpt00222mi0p1etbg19	SEGUNDA-18:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:33:53.988	2026-01-12 13:33:53.988
cmkb7eua401d12mrm078t93mw	cmk198vpt00222mi0p1etbg19	SEGUNDA-18:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:33:54.508	2026-01-12 13:33:54.508
cmkb7f7bf01es2mrm252e9pkg	cmkb7f6vo01eq2mrm9dpu9p6e	SEGUNDA-18:00	2026-01-05	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:11.404	2026-01-12 13:34:11.404
cmkb7f7q901eu2mrmiskb6hts	cmkb7f6vo01eq2mrm9dpu9p6e	SEGUNDA-18:00	2026-01-12	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:11.937	2026-01-12 13:34:11.937
cmkb7f84h01ew2mrmy68naesi	cmkb7f6vo01eq2mrm9dpu9p6e	SEGUNDA-18:00	2026-01-19	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:12.45	2026-01-12 13:34:12.45
cmkb7f8id01ey2mrmwrurutqy	cmkb7f6vo01eq2mrm9dpu9p6e	SEGUNDA-18:00	2026-01-26	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:12.949	2026-01-12 13:34:12.949
cmkb7f8wq01f02mrmbknhrb19	cmkb7f6vo01eq2mrm9dpu9p6e	SEXTA-18:00	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:13.467	2026-01-12 13:34:13.467
cmkb7f9an01f22mrmlgizem9k	cmkb7f6vo01eq2mrm9dpu9p6e	SEXTA-18:00	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:13.967	2026-01-12 13:34:13.967
cmkb7f9p201f42mrmfunipo5b	cmkb7f6vo01eq2mrm9dpu9p6e	SEXTA-18:00	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:14.486	2026-01-12 13:34:14.486
cmkb7fa2z01f62mrmibsgj1yh	cmkb7f6vo01eq2mrm9dpu9p6e	SEXTA-18:00	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:14.987	2026-01-12 13:34:14.987
cmkb7fagq01f82mrmj9tgss52	cmkb7f6vo01eq2mrm9dpu9p6e	SEXTA-18:00	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:15.482	2026-01-12 13:34:15.482
cmkb7fb4u01fa2mrmv46tjz4t	cmk198tur001h2mi0aitg53mf	SEGUNDA-19:00	2026-01-05	\N	Instrutor: GABI	2026-01-12 13:34:16.351	2026-01-12 13:34:16.351
cmkb7fbio01fc2mrmq4iv8oih	cmk198tur001h2mi0aitg53mf	SEGUNDA-19:00	2026-01-12	\N	Instrutor: GABI	2026-01-12 13:34:16.848	2026-01-12 13:34:16.848
cmkb7fbx301fe2mrmjt7kqcmi	cmk198tur001h2mi0aitg53mf	SEGUNDA-19:00	2026-01-19	\N	Instrutor: GABI	2026-01-12 13:34:17.367	2026-01-12 13:34:17.367
cmkb7fcbr01fg2mrm65059oq5	cmk198tur001h2mi0aitg53mf	SEGUNDA-19:00	2026-01-26	\N	Instrutor: GABI	2026-01-12 13:34:17.896	2026-01-12 13:34:17.896
cmkb7fcpj01fi2mrm0l704c0s	cmk198tur001h2mi0aitg53mf	QUINTA-19:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:34:18.391	2026-01-12 13:34:18.391
cmkb7fd3z01fk2mrmlc3082qw	cmk198tur001h2mi0aitg53mf	QUINTA-19:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:34:18.912	2026-01-12 13:34:18.912
cmkb7fdhr01fm2mrma4z72uce	cmk198tur001h2mi0aitg53mf	QUINTA-19:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:34:19.407	2026-01-12 13:34:19.407
cmkb7fdvk01fo2mrmkpbiwosa	cmk198tur001h2mi0aitg53mf	QUINTA-19:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:34:19.904	2026-01-12 13:34:19.904
cmkb7fe9e01fq2mrmdr53rilq	cmk198tur001h2mi0aitg53mf	QUINTA-19:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:34:20.402	2026-01-12 13:34:20.402
cmkb7fenw01fs2mrmtw5kevs4	cmk198tur001h2mi0aitg53mf	SEXTA-19:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:34:20.925	2026-01-12 13:34:20.925
cmkb7ff1m01fu2mrmi3vh206l	cmk198tur001h2mi0aitg53mf	SEXTA-19:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:34:21.419	2026-01-12 13:34:21.419
cmkb7ffff01fw2mrmo6yzeea5	cmk198tur001h2mi0aitg53mf	SEXTA-19:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:34:21.916	2026-01-12 13:34:21.916
cmkb7fftx01fy2mrmsjhbqvjp	cmk198tur001h2mi0aitg53mf	SEXTA-19:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:34:22.437	2026-01-12 13:34:22.437
cmkb7fg7r01g02mrmqibmow0y	cmk198tur001h2mi0aitg53mf	SEXTA-19:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:34:22.936	2026-01-12 13:34:22.936
cmkb7fruw01hk2mrmfp9yamqk	cmk198zf500382mi0jrnab4xv	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:38.024	2026-01-12 13:34:38.024
cmkb7fs8v01hm2mrma7jjkym0	cmk198zf500382mi0jrnab4xv	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:38.528	2026-01-12 13:34:38.528
cmkb7fsn601ho2mrm8pjpmx6p	cmk198zf500382mi0jrnab4xv	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:39.042	2026-01-12 13:34:39.042
cmkb7ft0y01hq2mrmiu52dznl	cmk198zf500382mi0jrnab4xv	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:39.539	2026-01-12 13:34:39.539
cmkb7ftfj01hs2mrmtpcbhsrd	cmk198zf500382mi0jrnab4xv	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:40.064	2026-01-12 13:34:40.064
cmkb7fttb01hu2mrmmzjs380o	cmk198zf500382mi0jrnab4xv	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:40.559	2026-01-12 13:34:40.559
cmkb7fu7w01hw2mrmx97bz5ne	cmk198zf500382mi0jrnab4xv	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:41.084	2026-01-12 13:34:41.084
cmkb7fujw01hy2mrm6rwdxkhz	cmk198zf500382mi0jrnab4xv	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:41.516	2026-01-12 13:34:41.516
cmkb7fuyd01i02mrmzbgb1tvk	cmk198zf500382mi0jrnab4xv	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:34:42.038	2026-01-12 13:34:42.038
cmkb7fvo501i22mrmt3do6xlq	cmk198plh00052mi0vd9sq0ac	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:34:42.966	2026-01-12 13:34:42.966
cmkb7fw2601i42mrmfo2q4w9x	cmk198plh00052mi0vd9sq0ac	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:34:43.471	2026-01-12 13:34:43.471
cmkb7fwgo01i62mrm6jgzmg3e	cmk198plh00052mi0vd9sq0ac	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:34:43.992	2026-01-12 13:34:43.992
cmkb7fwui01i82mrmqxsrmvun	cmk198plh00052mi0vd9sq0ac	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:34:44.491	2026-01-12 13:34:44.491
cmkb7fx9001ia2mrmr99ha4dw	cmk198plh00052mi0vd9sq0ac	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:34:45.012	2026-01-12 13:34:45.012
cmkb7fxnp01ic2mrmbgrweejm	cmk198plh00052mi0vd9sq0ac	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:34:45.541	2026-01-12 13:34:45.541
cmkb7fy2501ie2mrmgp6vx4rz	cmk198plh00052mi0vd9sq0ac	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:34:46.061	2026-01-12 13:34:46.061
cmkb7fyhc01ig2mrmk40y945y	cmk198plh00052mi0vd9sq0ac	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:34:46.608	2026-01-12 13:34:46.608
cmkb7fyv701ii2mrmiz8rml8x	cmk198plh00052mi0vd9sq0ac	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:34:47.108	2026-01-12 13:34:47.108
cmkb7fz8z01ik2mrmb3xl56n5	cmk198plh00052mi0vd9sq0ac	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:34:47.604	2026-01-12 13:34:47.604
cmkb7fzol01im2mrm7q2b0rcy	cmk198plh00052mi0vd9sq0ac	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:34:48.165	2026-01-12 13:34:48.165
cmkb7g03901io2mrmfr76w05n	cmk198plh00052mi0vd9sq0ac	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:34:48.693	2026-01-12 13:34:48.693
cmkb7g0hl01iq2mrm5wcjhjdx	cmk198plh00052mi0vd9sq0ac	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:34:49.209	2026-01-12 13:34:49.209
cmkb7g0w201is2mrmw4tlrgux	cmk198plh00052mi0vd9sq0ac	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:34:49.731	2026-01-12 13:34:49.731
cmkb7g1m001iu2mrmq5gwzgl9	cmk199q4v00bk2mi0k9cdjvj1	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:34:50.665	2026-01-12 13:34:50.665
cmkb7g20e01iw2mrm8zu4vlyr	cmk199q4v00bk2mi0k9cdjvj1	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:34:51.183	2026-01-12 13:34:51.183
cmkb7g2e901iy2mrmdbdkv24b	cmk199q4v00bk2mi0k9cdjvj1	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:34:51.682	2026-01-12 13:34:51.682
cmkb7g2s401j02mrmaoqn9dys	cmk199q4v00bk2mi0k9cdjvj1	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:34:52.18	2026-01-12 13:34:52.18
cmkb7g36m01j22mrmtejelnsf	cmk199q4v00bk2mi0k9cdjvj1	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:34:52.703	2026-01-12 13:34:52.703
cmkb7g3ke01j42mrmq4411c1q	cmk199q4v00bk2mi0k9cdjvj1	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:34:53.198	2026-01-12 13:34:53.198
cmkb7g3y601j62mrmu5td9wx4	cmk199q4v00bk2mi0k9cdjvj1	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:34:53.694	2026-01-12 13:34:53.694
cmkb7g4bz01j82mrmwxyl5819	cmk199q4v00bk2mi0k9cdjvj1	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:34:54.192	2026-01-12 13:34:54.192
cmkb7g4o101ja2mrmgtd722vu	cmk199q4v00bk2mi0k9cdjvj1	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:34:54.626	2026-01-12 13:34:54.626
cmkb7gbnx01k52mrmzahrnqaq	cmk199jye009n2mi0w0jfqkmz	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:03.693	2026-01-12 13:35:03.693
cmkb7gc2a01k72mrm7ym3y88v	cmk199jye009n2mi0w0jfqkmz	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:04.211	2026-01-12 13:35:04.211
cmkb7gcgw01k92mrm3jdg8aut	cmk199jye009n2mi0w0jfqkmz	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:04.736	2026-01-12 13:35:04.736
cmkb7gcvf01kb2mrmhphppo24	cmk199jye009n2mi0w0jfqkmz	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:05.259	2026-01-12 13:35:05.259
cmkb7gda901kd2mrmtqsou45f	cmk199jye009n2mi0w0jfqkmz	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:05.793	2026-01-12 13:35:05.793
cmkb7gdoi01kf2mrmm0pjbdlc	cmk199jye009n2mi0w0jfqkmz	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:06.306	2026-01-12 13:35:06.306
cmkb7ge3601kh2mrmlw2mf88k	cmk199jye009n2mi0w0jfqkmz	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:06.835	2026-01-12 13:35:06.835
cmkb7gehp01kj2mrm9j345qc5	cmk199jye009n2mi0w0jfqkmz	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:07.357	2026-01-12 13:35:07.357
cmkb7gewa01kl2mrm1yo25t7i	cmk199jye009n2mi0w0jfqkmz	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:07.882	2026-01-12 13:35:07.882
cmkb7gfkq01kn2mrmb5ti4vsd	cmk199htt008z2mi0x6jn63l0	cmk2it6xl000a2mcj8tik4ak9	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:35:08.763	2026-01-12 13:35:08.763
cmkb7gfzc01kp2mrmcu2qjba1	cmk199htt008z2mi0x6jn63l0	cmk2it6xl000a2mcj8tik4ak9	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:35:09.288	2026-01-12 13:35:09.288
cmkb7gge101kr2mrmi809i8il	cmk199htt008z2mi0x6jn63l0	cmk2it6xl000a2mcj8tik4ak9	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:35:09.817	2026-01-12 13:35:09.817
cmkb7ggsj01kt2mrmm45n0d4p	cmk199htt008z2mi0x6jn63l0	cmk2it6xl000a2mcj8tik4ak9	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:35:10.34	2026-01-12 13:35:10.34
cmkb7gh7101kv2mrmye012jex	cmk199htt008z2mi0x6jn63l0	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:10.862	2026-01-12 13:35:10.862
cmkb7ghl601kx2mrm9s1s5jf4	cmk199htt008z2mi0x6jn63l0	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:11.371	2026-01-12 13:35:11.371
cmkb7gi0801kz2mrm5bqw3k5t	cmk199htt008z2mi0x6jn63l0	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:11.912	2026-01-12 13:35:11.912
cmkb7giep01l12mrmsns3bgkw	cmk199htt008z2mi0x6jn63l0	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:12.434	2026-01-12 13:35:12.434
cmkb7git901l32mrm0npltmzl	cmk199htt008z2mi0x6jn63l0	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:12.956	2026-01-12 13:35:12.956
cmkb7gyl101n42mrm6p4ayrgf	cmk199av4006t2mi0bziu6mfr	TERCA-06:00	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:33.397	2026-01-12 13:35:33.397
cmkb7gyza01n62mrmogm5zkm4	cmk199av4006t2mi0bziu6mfr	TERCA-06:00	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:33.911	2026-01-12 13:35:33.911
cmkb7gzd701n82mrm7lnrh9yz	cmk199av4006t2mi0bziu6mfr	TERCA-06:00	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:34.411	2026-01-12 13:35:34.411
cmkb7gzxc01na2mrmufyj33u7	cmk199av4006t2mi0bziu6mfr	TERCA-06:00	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:35.137	2026-01-12 13:35:35.137
cmkb7h0c101nc2mrm6a7oglaw	cmk199av4006t2mi0bziu6mfr	QUINTA-18:00	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:35.665	2026-01-12 13:35:35.665
cmkb7h0pu01ne2mrmlui6okyx	cmk199av4006t2mi0bziu6mfr	QUINTA-18:00	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:36.162	2026-01-12 13:35:36.162
cmkb7h14901ng2mrmcfeu9g1e	cmk199av4006t2mi0bziu6mfr	QUINTA-18:00	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:36.681	2026-01-12 13:35:36.681
cmkb7h1i401ni2mrm7ri3big8	cmk199av4006t2mi0bziu6mfr	QUINTA-18:00	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:37.18	2026-01-12 13:35:37.18
cmkb7h1u801nk2mrm2wfee6x1	cmk199av4006t2mi0bziu6mfr	QUINTA-18:00	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:37.616	2026-01-12 13:35:37.616
cmkb7h2b901nm2mrm7eehg20n	cmk199av4006t2mi0bziu6mfr	SEXTA-06:00	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:38.23	2026-01-12 13:35:38.23
cmkb7h2n201no2mrmbumjexnd	cmk199av4006t2mi0bziu6mfr	SEXTA-06:00	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:38.655	2026-01-12 13:35:38.655
cmkb7h30v01nq2mrm3uih2kpy	cmk199av4006t2mi0bziu6mfr	SEXTA-06:00	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:39.152	2026-01-12 13:35:39.152
cmkb7h3ep01ns2mrm5b3gykxo	cmk199av4006t2mi0bziu6mfr	SEXTA-06:00	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:39.65	2026-01-12 13:35:39.65
cmkb7h3sm01nu2mrmrwft5hws	cmk199av4006t2mi0bziu6mfr	SEXTA-06:00	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:40.151	2026-01-12 13:35:40.151
cmkb7h4jd01nw2mrmjh9k55r9	cmk19950f004z2mi0up36poxo	TERCA-06:00	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:35:41.113	2026-01-12 13:35:41.113
cmkb7h4xs01ny2mrmvrk6z8tf	cmk19950f004z2mi0up36poxo	TERCA-06:00	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:35:41.631	2026-01-12 13:35:41.631
cmkb7h5ce01o02mrmgaen8lyj	cmk19950f004z2mi0up36poxo	TERCA-06:00	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:35:42.158	2026-01-12 13:35:42.158
cmkb7h5ql01o22mrm08zbbz7a	cmk19950f004z2mi0up36poxo	TERCA-06:00	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:35:42.669	2026-01-12 13:35:42.669
cmkb7h65301o42mrmcdm8jn7j	cmk19950f004z2mi0up36poxo	QUINTA-06:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:35:43.191	2026-01-12 13:35:43.191
cmkb7h6jm01o62mrm954fzb0e	cmk19950f004z2mi0up36poxo	QUINTA-06:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:35:43.714	2026-01-12 13:35:43.714
cmkb7h6xy01o82mrm2klfxgdy	cmk19950f004z2mi0up36poxo	QUINTA-06:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:35:44.23	2026-01-12 13:35:44.23
cmkb7h7ck01oa2mrmsqxndcd9	cmk19950f004z2mi0up36poxo	QUINTA-06:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:35:44.756	2026-01-12 13:35:44.756
cmkb7h7r101oc2mrm6hc7kee2	cmk19950f004z2mi0up36poxo	QUINTA-06:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:35:45.277	2026-01-12 13:35:45.277
cmkb7h8it01oe2mrmo1pwjsr8	cmk19962d005b2mi0d9hsy0kv	TERCA-06:00	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:35:46.277	2026-01-12 13:35:46.277
cmkb7h8x001og2mrmmgzehjc8	cmk19962d005b2mi0d9hsy0kv	TERCA-06:00	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:35:46.788	2026-01-12 13:35:46.788
cmkb7h9aw01oi2mrmdkyehzqp	cmk19962d005b2mi0d9hsy0kv	TERCA-06:00	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:35:47.288	2026-01-12 13:35:47.288
cmkb7h9pf01ok2mrm5mcu766i	cmk19962d005b2mi0d9hsy0kv	TERCA-06:00	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:35:47.811	2026-01-12 13:35:47.811
cmkb7hafg01om2mrml7uiyofc	cmk1998zo00682mi0mjhxpnpw	TERCA-07:00	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:35:48.748	2026-01-12 13:35:48.748
cmkb7hatz01oo2mrmnmb1k6fy	cmk1998zo00682mi0mjhxpnpw	TERCA-07:00	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:35:49.272	2026-01-12 13:35:49.272
cmkb7hb7o01oq2mrmorja8dmw	cmk1998zo00682mi0mjhxpnpw	TERCA-07:00	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:35:49.764	2026-01-12 13:35:49.764
cmkb7hbm701os2mrmrftoyyk0	cmk1998zo00682mi0mjhxpnpw	TERCA-07:00	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:35:50.287	2026-01-12 13:35:50.287
cmkb7hc1001ou2mrmtm36f48s	cmk1998zo00682mi0mjhxpnpw	QUARTA-07:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:35:50.821	2026-01-12 13:35:50.821
cmkb7hcfc01ow2mrmc6qgvo3v	cmk1998zo00682mi0mjhxpnpw	QUARTA-07:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:35:51.337	2026-01-12 13:35:51.337
cmkb7hcrc01oy2mrm9v45x3b5	cmk1998zo00682mi0mjhxpnpw	QUARTA-07:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:35:51.768	2026-01-12 13:35:51.768
cmkb7hd5101p02mrmh97cqk39	cmk1998zo00682mi0mjhxpnpw	QUARTA-07:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:35:52.261	2026-01-12 13:35:52.261
cmkb7hdj501p22mrm0u743raz	cmk1998zo00682mi0mjhxpnpw	SEXTA-07:00	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:52.768	2026-01-12 13:35:52.768
cmkb7hdxc01p42mrmz03nt81h	cmk1998zo00682mi0mjhxpnpw	SEXTA-07:00	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:53.28	2026-01-12 13:35:53.28
cmkb7heb601p62mrm6y1e2fx3	cmk1998zo00682mi0mjhxpnpw	SEXTA-07:00	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:53.778	2026-01-12 13:35:53.778
cmkb7hep401p82mrmvqxc5jrs	cmk1998zo00682mi0mjhxpnpw	SEXTA-07:00	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:54.28	2026-01-12 13:35:54.28
cmkb7hf3i01pa2mrmkyngjlpj	cmk1998zo00682mi0mjhxpnpw	SEXTA-07:00	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:54.799	2026-01-12 13:35:54.799
cmkb7hg8001pf2mrmzr364des	cmkb7hfs501pd2mrmm4vbozc3	TERCA-07:00	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:56.257	2026-01-12 13:35:56.257
cmkb7hgls01ph2mrmafop4nv3	cmkb7hfs501pd2mrmm4vbozc3	TERCA-07:00	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:56.752	2026-01-12 13:35:56.752
cmkb7hh0801pj2mrmmebxqb7y	cmkb7hfs501pd2mrmm4vbozc3	TERCA-07:00	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:57.272	2026-01-12 13:35:57.272
cmkb7hhe301pl2mrmwyznjw14	cmkb7hfs501pd2mrmm4vbozc3	TERCA-07:00	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:57.771	2026-01-12 13:35:57.771
cmkb7hhru01pn2mrm7w3omix0	cmkb7hfs501pd2mrmm4vbozc3	QUARTA-07:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:58.266	2026-01-12 13:35:58.266
cmkb7hi6801pp2mrmohir8tza	cmkb7hfs501pd2mrmm4vbozc3	QUARTA-07:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:58.785	2026-01-12 13:35:58.785
cmkb7hik301pr2mrm0o5zoldt	cmkb7hfs501pd2mrmm4vbozc3	QUARTA-07:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:59.284	2026-01-12 13:35:59.284
cmkb7hixx01pt2mrmnhwbv1d5	cmkb7hfs501pd2mrmm4vbozc3	QUARTA-07:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:35:59.782	2026-01-12 13:35:59.782
cmkb7hjbo01pv2mrmeeivpa3l	cmkb7hfs501pd2mrmm4vbozc3	QUINTA-07:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:36:00.277	2026-01-12 13:36:00.277
cmkb7hjqb01px2mrmu3mcg9s9	cmkb7hfs501pd2mrmm4vbozc3	QUINTA-07:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:36:00.773	2026-01-12 13:36:00.773
cmkb7hk4t01pz2mrmsqyvaj2a	cmkb7hfs501pd2mrmm4vbozc3	QUINTA-07:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:36:01.326	2026-01-12 13:36:01.326
cmkb7hkil01q12mrmdb4i3ct5	cmkb7hfs501pd2mrmm4vbozc3	QUINTA-07:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:36:01.821	2026-01-12 13:36:01.821
cmkb7hkug01q32mrmskwd0knw	cmkb7hfs501pd2mrmm4vbozc3	QUINTA-07:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:36:02.248	2026-01-12 13:36:02.248
cmkb7hpyg01qq2mrmbc8818yj	cmkb7hpil01qo2mrmmzuankq4	cmk2m1qun00002m4k4vi2rp9t	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:36:08.872	2026-01-12 13:36:08.872
cmkb7hqd401qs2mrmyxogjk3z	cmkb7hpil01qo2mrmmzuankq4	cmk2m1qun00002m4k4vi2rp9t	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:36:09.401	2026-01-12 13:36:09.401
cmkb7hqrx01qu2mrmvmipfocw	cmkb7hpil01qo2mrmmzuankq4	cmk2m1qun00002m4k4vi2rp9t	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:36:09.933	2026-01-12 13:36:09.933
cmkb7hr7301qw2mrmfx3cplso	cmkb7hpil01qo2mrmmzuankq4	cmk2m1qun00002m4k4vi2rp9t	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:36:10.479	2026-01-12 13:36:10.479
cmkb7hrld01qy2mrmdjxr6jpk	cmkb7hpil01qo2mrmmzuankq4	cmk2kq93j004t2msa1hcg8y08	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:36:10.993	2026-01-12 13:36:10.993
cmkb7hs0501r02mrmir2a0lcm	cmkb7hpil01qo2mrmmzuankq4	cmk2kq93j004t2msa1hcg8y08	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:36:11.523	2026-01-12 13:36:11.523
cmkb7hses01r22mrm7jzslifc	cmkb7hpil01qo2mrmmzuankq4	cmk2kq93j004t2msa1hcg8y08	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:36:12.053	2026-01-12 13:36:12.053
cmkb7hst801r42mrmkxjile0l	cmkb7hpil01qo2mrmmzuankq4	cmk2kq93j004t2msa1hcg8y08	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:36:12.572	2026-01-12 13:36:12.572
cmkb7ht7n01r62mrmfs707vgm	cmkb7hpil01qo2mrmmzuankq4	cmk2kq93j004t2msa1hcg8y08	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:36:13.092	2026-01-12 13:36:13.092
cmkb7hvx101rh2mrmb64a0b1q	cmk1997el005q2mi02t6inz7d	cmkb7htnu01r72mrmgne9fuk3	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:36:16.597	2026-01-12 13:36:16.597
cmkb7hwbg01rj2mrm8pqwpsoo	cmk1997el005q2mi02t6inz7d	cmkb7htnu01r72mrmgne9fuk3	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:36:17.116	2026-01-12 13:36:17.116
cmkb7hwq901rl2mrm2ykpk77i	cmk1997el005q2mi02t6inz7d	cmkb7htnu01r72mrmgne9fuk3	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:36:17.65	2026-01-12 13:36:17.65
cmkb7hx4p01rn2mrmwak8kqif	cmk1997el005q2mi02t6inz7d	cmkb7htnu01r72mrmgne9fuk3	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:36:18.169	2026-01-12 13:36:18.169
cmkb7hxj101rp2mrm2yevqmko	cmk1997el005q2mi02t6inz7d	cmk2kqbe900fo2msazmsum81w	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:36:18.685	2026-01-12 13:36:18.685
cmkb7hxxu01rr2mrmpgxjh6gj	cmk1997el005q2mi02t6inz7d	cmk2kqbe900fo2msazmsum81w	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:36:19.218	2026-01-12 13:36:19.218
cmkb7hyc501rt2mrm7uojlow4	cmk1997el005q2mi02t6inz7d	cmk2kqbe900fo2msazmsum81w	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:36:19.734	2026-01-12 13:36:19.734
cmkb7hypx01rv2mrmlmuq1ywu	cmk1997el005q2mi02t6inz7d	cmk2kqbe900fo2msazmsum81w	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:36:20.229	2026-01-12 13:36:20.229
cmkb7hz4f01rx2mrmmfneyy4l	cmk1997el005q2mi02t6inz7d	cmk2kqbe900fo2msazmsum81w	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:36:20.752	2026-01-12 13:36:20.752
cmkb7i3f801sh2mrm2caap4x9	cmk2kql9c014s2msaark27qrj	cmk2kq8ji00172msal7kljpg1	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:26.324	2026-01-12 13:36:26.324
cmkb7i3tt01sj2mrmlvmagyb8	cmk2kql9c014s2msaark27qrj	cmk2kq8ji00172msal7kljpg1	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:26.849	2026-01-12 13:36:26.849
cmkb7i48a01sl2mrmpwwjpt60	cmk2kql9c014s2msaark27qrj	cmk2kq8ji00172msal7kljpg1	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:27.37	2026-01-12 13:36:27.37
cmkb7i4mo01sn2mrm3h2kj8sz	cmk2kql9c014s2msaark27qrj	cmk2kq8ji00172msal7kljpg1	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:27.889	2026-01-12 13:36:27.889
cmkb7i51j01sp2mrm7mk2cpod	cmk2kql9c014s2msaark27qrj	cmk2kq8k3001p2msay0oj9p7u	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:28.423	2026-01-12 13:36:28.423
cmkb7i5g601sr2mrmrb302ypd	cmk2kql9c014s2msaark27qrj	cmk2kq8k3001p2msay0oj9p7u	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:28.95	2026-01-12 13:36:28.95
cmkb7i5ue01st2mrmkm20v7d4	cmk2kql9c014s2msaark27qrj	cmk2kq8k3001p2msay0oj9p7u	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:29.463	2026-01-12 13:36:29.463
cmkb7i69501sv2mrm1f4slx7b	cmk2kql9c014s2msaark27qrj	cmk2kq8k3001p2msay0oj9p7u	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:29.994	2026-01-12 13:36:29.994
cmkb7i6no01sx2mrm6mxp5kk1	cmk2kql9c014s2msaark27qrj	cmk2kq8k3001p2msay0oj9p7u	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:30.516	2026-01-12 13:36:30.516
cmkb7id3x01tr2mrm6dzbeifp	cmk2kqeie00p62msabkj3x7j3	cmk2kq8l0002k2msasi6djwph	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:38.877	2026-01-12 13:36:38.877
cmkb7idii01tt2mrm297nyq5w	cmk2kqeie00p62msabkj3x7j3	cmk2kq8l0002k2msasi6djwph	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:39.402	2026-01-12 13:36:39.402
cmkb7idx801tv2mrmi2oc2dr5	cmk2kqeie00p62msabkj3x7j3	cmk2kq8l0002k2msasi6djwph	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:39.932	2026-01-12 13:36:39.932
cmkb7iebn01tx2mrm2qpjsnk6	cmk2kqeie00p62msabkj3x7j3	cmk2kq8l0002k2msasi6djwph	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:40.451	2026-01-12 13:36:40.451
cmkb7ieq401tz2mrmqwl6ngjh	cmk2kqeie00p62msabkj3x7j3	cmk2kq8lm00322msas3daxefo	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:40.972	2026-01-12 13:36:40.972
cmkb7if4j01u12mrmxhp8zsvv	cmk2kqeie00p62msabkj3x7j3	cmk2kq8lm00322msas3daxefo	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:41.491	2026-01-12 13:36:41.491
cmkb7ifj001u32mrmxq25vgxc	cmk2kqeie00p62msabkj3x7j3	cmk2kq8lm00322msas3daxefo	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:42.012	2026-01-12 13:36:42.012
cmkb7ifxz01u52mrmlcak74uz	cmk2kqeie00p62msabkj3x7j3	cmk2kq8lm00322msas3daxefo	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:42.551	2026-01-12 13:36:42.551
cmkb7igc801u72mrmqsr9nujs	cmk2kqeie00p62msabkj3x7j3	cmk2kq8lm00322msas3daxefo	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:43.064	2026-01-12 13:36:43.064
cmkb7ihih01uc2mrmdq8kdwwj	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8l0002k2msasi6djwph	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:44.586	2026-01-12 13:36:44.586
cmkb7ihx001ue2mrm8wm8wm9u	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8l0002k2msasi6djwph	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:45.106	2026-01-12 13:36:45.106
cmkb7iibs01ug2mrm8epruu6u	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8l0002k2msasi6djwph	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:45.64	2026-01-12 13:36:45.64
cmkb7iiq701ui2mrmzt1b6hwi	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8l0002k2msasi6djwph	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:46.159	2026-01-12 13:36:46.159
cmkb7ij5h01uk2mrmxndor78y	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8lm00322msas3daxefo	2026-01-01	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:46.71	2026-01-12 13:36:46.71
cmkb7ijkh01um2mrmhgfmh8ph	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8lm00322msas3daxefo	2026-01-08	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:47.249	2026-01-12 13:36:47.249
cmkb7ijyc01uo2mrmfu99bina	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8lm00322msas3daxefo	2026-01-15	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:47.748	2026-01-12 13:36:47.748
cmkb7ikci01uq2mrm3x9fisf3	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8lm00322msas3daxefo	2026-01-22	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:48.258	2026-01-12 13:36:48.258
cmkb7ikqp01us2mrm0605th1w	cmkb7ih2l01ua2mrmj46s75bo	cmk2kq8lm00322msas3daxefo	2026-01-29	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:48.769	2026-01-12 13:36:48.769
cmkb7ipx401vf2mrmgie3hupc	cmk1990h9003k2mi0138jf3hx	TERCA-17:00	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:55.481	2026-01-12 13:36:55.481
cmkb7iqbp01vh2mrmy0g9721q	cmk1990h9003k2mi0138jf3hx	TERCA-17:00	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:56.005	2026-01-12 13:36:56.005
cmkb7iqq301vj2mrm9d08q80y	cmk1990h9003k2mi0138jf3hx	TERCA-17:00	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:56.523	2026-01-12 13:36:56.523
cmkb7ir4i01vl2mrm4ev5z5tk	cmk1990h9003k2mi0138jf3hx	TERCA-17:00	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:57.042	2026-01-12 13:36:57.042
cmkb7irj701vn2mrmjfdebahz	cmk1990h9003k2mi0138jf3hx	QUARTA-17:00	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:57.571	2026-01-12 13:36:57.571
cmkb7irxy01vp2mrmadkcsqse	cmk1990h9003k2mi0138jf3hx	QUARTA-17:00	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:58.103	2026-01-12 13:36:58.103
cmkb7isd201vr2mrm7xtpbnuf	cmk1990h9003k2mi0138jf3hx	QUARTA-17:00	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:58.647	2026-01-12 13:36:58.647
cmkb7isrr01vt2mrmfmy6lo88	cmk1990h9003k2mi0138jf3hx	QUARTA-17:00	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:36:59.175	2026-01-12 13:36:59.175
cmkb7itir01vv2mrmxsfiavx9	cmk199bec006z2mi0bu10sc9v	TERCA-17:00	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:37:00.147	2026-01-12 13:37:00.147
cmkb7itx101vx2mrmydwi9rtw	cmk199bec006z2mi0bu10sc9v	TERCA-17:00	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:37:00.661	2026-01-12 13:37:00.661
cmkb7iubh01vz2mrm435aydzn	cmk199bec006z2mi0bu10sc9v	TERCA-17:00	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:37:01.181	2026-01-12 13:37:01.181
cmkb7iuqs01w12mrm8bj552bg	cmk199bec006z2mi0bu10sc9v	TERCA-17:00	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:37:01.732	2026-01-12 13:37:01.732
cmkb7iv5f01w32mrmce3ur08q	cmk199bec006z2mi0bu10sc9v	QUINTA-17:00	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:37:02.259	2026-01-12 13:37:02.259
cmkb7ivk901w52mrmvcjbi25n	cmk199bec006z2mi0bu10sc9v	QUINTA-17:00	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:37:02.793	2026-01-12 13:37:02.793
cmkb7ivyk01w72mrmnoclzy8x	cmk199bec006z2mi0bu10sc9v	QUINTA-17:00	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:37:03.308	2026-01-12 13:37:03.308
cmkb7iwdc01w92mrmwe8b4p1n	cmk199bec006z2mi0bu10sc9v	QUINTA-17:00	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:37:03.84	2026-01-12 13:37:03.84
cmkb7iwrp01wb2mrmhz9wfkmx	cmk199bec006z2mi0bu10sc9v	QUINTA-17:00	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:37:04.358	2026-01-12 13:37:04.358
cmkb7ixid01wd2mrmu3oi7x8l	cmk2kqfxw00tf2msap1yqtfhk	TERCA-18:00	2026-01-06	\N	Instrutor: GABI	2026-01-12 13:37:05.317	2026-01-12 13:37:05.317
cmkb7ixww01wf2mrm60zt546p	cmk2kqfxw00tf2msap1yqtfhk	TERCA-18:00	2026-01-13	\N	Instrutor: GABI	2026-01-12 13:37:05.84	2026-01-12 13:37:05.84
cmkb7iybb01wh2mrmb4wcvads	cmk2kqfxw00tf2msap1yqtfhk	TERCA-18:00	2026-01-20	\N	Instrutor: GABI	2026-01-12 13:37:06.359	2026-01-12 13:37:06.359
cmkb7iyq501wj2mrm1h9vju8i	cmk2kqfxw00tf2msap1yqtfhk	TERCA-18:00	2026-01-27	\N	Instrutor: GABI	2026-01-12 13:37:06.893	2026-01-12 13:37:06.893
cmkb7iz4k01wl2mrm9otfj649	cmk2kqfxw00tf2msap1yqtfhk	SEXTA-18:00	2026-01-02	\N	Instrutor: GABI	2026-01-12 13:37:07.413	2026-01-12 13:37:07.413
cmkb7izid01wn2mrmyid0u5pn	cmk2kqfxw00tf2msap1yqtfhk	SEXTA-18:00	2026-01-09	\N	Instrutor: GABI	2026-01-12 13:37:07.909	2026-01-12 13:37:07.909
cmkb7izw501wp2mrm06ax3902	cmk2kqfxw00tf2msap1yqtfhk	SEXTA-18:00	2026-01-16	\N	Instrutor: GABI	2026-01-12 13:37:08.405	2026-01-12 13:37:08.405
cmkb7j0az01wr2mrmufb6niuk	cmk2kqfxw00tf2msap1yqtfhk	SEXTA-18:00	2026-01-23	\N	Instrutor: GABI	2026-01-12 13:37:08.939	2026-01-12 13:37:08.939
cmkb7j0pa01wt2mrmek1mx824	cmk2kqfxw00tf2msap1yqtfhk	SEXTA-18:00	2026-01-30	\N	Instrutor: GABI	2026-01-12 13:37:09.454	2026-01-12 13:37:09.454
cmkb7jm5u01zl2mrm0cvber48	cmk1992w9004b2mi08maqjp3l	TERCA-19:00	2026-01-06	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:37.266	2026-01-12 13:37:37.266
cmkb7jmke01zn2mrmvan2vhhp	cmk1992w9004b2mi08maqjp3l	TERCA-19:00	2026-01-13	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:37.79	2026-01-12 13:37:37.79
cmkb7jmz701zp2mrmyu5pisbh	cmk1992w9004b2mi08maqjp3l	TERCA-19:00	2026-01-20	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:38.323	2026-01-12 13:37:38.323
cmkb7jndl01zr2mrmr2qtj6xc	cmk1992w9004b2mi08maqjp3l	TERCA-19:00	2026-01-27	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:38.841	2026-01-12 13:37:38.841
cmkb7jsuu020f2mrmsgexzjo5	cmk2kqlpu01582msauiozwpwr	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:45.943	2026-01-12 13:37:45.943
cmkb7jt8o020h2mrmu82fii2t	cmk2kqlpu01582msauiozwpwr	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:46.44	2026-01-12 13:37:46.44
cmkb7jto2020j2mrmq116fzap	cmk2kqlpu01582msauiozwpwr	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:46.993	2026-01-12 13:37:46.993
cmkb7ju2z020l2mrmblz7464p	cmk2kqlpu01582msauiozwpwr	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:47.531	2026-01-12 13:37:47.531
cmkb7juhc020n2mrm9h8nsc3i	cmk2kqlpu01582msauiozwpwr	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:48.048	2026-01-12 13:37:48.048
cmkb7juvt020p2mrmtfvuyc5u	cmk2kqlpu01582msauiozwpwr	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:48.568	2026-01-12 13:37:48.568
cmkb7jvaa020r2mrmldsfasst	cmk2kqlpu01582msauiozwpwr	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:49.09	2026-01-12 13:37:49.09
cmkb7jvoe020t2mrmj2iwojuz	cmk2kqlpu01582msauiozwpwr	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:49.598	2026-01-12 13:37:49.598
cmkb7jw2l020v2mrm5ymm6imd	cmk2kqlpu01582msauiozwpwr	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:50.109	2026-01-12 13:37:50.109
cmkb7jz7902182mrmcj9yy3r2	cmk1ezvuu00cw2mi0rui6xiaw	cmk2itfng000f2mcjemtcltxm	2026-01-07	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:54.165	2026-01-12 13:37:54.165
cmkb7jzll021a2mrmt4yko3f6	cmk1ezvuu00cw2mi0rui6xiaw	cmk2itfng000f2mcjemtcltxm	2026-01-14	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:54.681	2026-01-12 13:37:54.681
cmkb7k00c021c2mrmy2zkxo5e	cmk1ezvuu00cw2mi0rui6xiaw	cmk2itfng000f2mcjemtcltxm	2026-01-21	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:55.211	2026-01-12 13:37:55.211
cmkb7k0ew021e2mrmnmtebxfw	cmk1ezvuu00cw2mi0rui6xiaw	cmk2itfng000f2mcjemtcltxm	2026-01-28	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:55.736	2026-01-12 13:37:55.736
cmkb7k0tf021g2mrm20yjqjcb	cmk1ezvuu00cw2mi0rui6xiaw	cmkb73zzh001e2mrmyw04xxnn	2026-01-02	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:56.259	2026-01-12 13:37:56.259
cmkb7k189021i2mrmnu9zhmt5	cmk1ezvuu00cw2mi0rui6xiaw	cmkb73zzh001e2mrmyw04xxnn	2026-01-09	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:56.793	2026-01-12 13:37:56.793
cmkb7k1mn021k2mrmsbootnw6	cmk1ezvuu00cw2mi0rui6xiaw	cmkb73zzh001e2mrmyw04xxnn	2026-01-16	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:57.311	2026-01-12 13:37:57.311
cmkb7k219021m2mrmdj5nfehg	cmk1ezvuu00cw2mi0rui6xiaw	cmkb73zzh001e2mrmyw04xxnn	2026-01-23	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:57.837	2026-01-12 13:37:57.837
cmkb7k2fr021o2mrmk0x8r3js	cmk1ezvuu00cw2mi0rui6xiaw	cmkb73zzh001e2mrmyw04xxnn	2026-01-30	\N	Instrutor: ESTAGIÁRIO	2026-01-12 13:37:58.359	2026-01-12 13:37:58.359
cmkb7kq8e024p2mrmnwc7tke0	cmkb7kps9024n2mrmstf3c4nh	QUARTA-18:00	2026-01-07	\N	Instrutor: GABI	2026-01-12 13:38:29.198	2026-01-12 13:38:29.198
cmkb7kqmy024r2mrmmr3x4ww5	cmkb7kps9024n2mrmstf3c4nh	QUARTA-18:00	2026-01-14	\N	Instrutor: GABI	2026-01-12 13:38:29.722	2026-01-12 13:38:29.722
cmkb7kr1q024t2mrmnsw7t68u	cmkb7kps9024n2mrmstf3c4nh	QUARTA-18:00	2026-01-21	\N	Instrutor: GABI	2026-01-12 13:38:30.255	2026-01-12 13:38:30.255
cmkb7krg3024v2mrm44iehsfs	cmkb7kps9024n2mrmstf3c4nh	QUARTA-18:00	2026-01-28	\N	Instrutor: GABI	2026-01-12 13:38:30.771	2026-01-12 13:38:30.771
cmkb7ks4p024x2mrmeuaixxua	cmk199crt007e2mi0wep49upc	cmk2jetqg000s2mcjgfxb5waq	2026-01-01	\N	Instrutor: GABI	2026-01-12 13:38:31.657	2026-01-12 13:38:31.657
cmkb7ksiv024z2mrm53v0hi47	cmk199crt007e2mi0wep49upc	cmk2jetqg000s2mcjgfxb5waq	2026-01-08	\N	Instrutor: GABI	2026-01-12 13:38:32.168	2026-01-12 13:38:32.168
cmkb7ksyc02512mrm5y00eip6	cmk199crt007e2mi0wep49upc	cmk2jetqg000s2mcjgfxb5waq	2026-01-15	\N	Instrutor: GABI	2026-01-12 13:38:32.725	2026-01-12 13:38:32.725
cmkb7ktcp02532mrmokn1y98w	cmk199crt007e2mi0wep49upc	cmk2jetqg000s2mcjgfxb5waq	2026-01-22	\N	Instrutor: GABI	2026-01-12 13:38:33.242	2026-01-12 13:38:33.242
cmkb7ktqn02552mrmhjvmtmym	cmk199crt007e2mi0wep49upc	cmk2jetqg000s2mcjgfxb5waq	2026-01-29	\N	Instrutor: GABI	2026-01-12 13:38:33.743	2026-01-12 13:38:33.743
cmkb75bqm007g2mrmoqfb9slz	cmk1998q400652mi0j3oh8k8f	cmkeadfce0000le04973ylera	2026-01-14	t		2026-01-12 13:26:30.574	2026-01-14 17:20:18.85
\.


--
-- Data for Name: anamneses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.anamneses (id, membro_id, altura, peso_atual, objetivo, pratica_atividade, pratica_atividade_qual, tempo_sedentario, condicao_medica, condicao_medica_qual, lesao, lesao_qual, restricao_movimento, restricao_movimento_qual, desconforto_movimento, desconforto_movimento_qual, problemas_ortopedicos, problemas_ortopedicos_qual, medicamento_controlado, medicamento_controlado_qual, obeso_sobrepeso, colesterol_elevado, taquicardia, doencas_cardiacas, diabetes, dificuldade_exercicio, ciclo_menstrual, experiencia_musculacao, onde_conheceu, expectativas, parq1, parq2, parq3, parq4, parq5, parq6, parq7, nextfit_avaliacao_id, sincronizado_em, criado_em, atualizado_em) FROM stdin;
cmko1fvmh0004l404nvx760t1	cmko19dm60002l4047rkhiv1r	1.65	80	Emagrecimento	Não	\N	5 anos	Sim	LER, Fibromialgia.	Não	\N	Não	\N	Sim	Pulsos.	Não	\N	Sim	N/A	Sim.	Sim	Sim	Não	Não	Não sabe dizer.	1 Semana antes do período sente muito desconforto e fraqueza.	Sim, iniciante.	Rede social	Profissionalismo.	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-21 13:07:45.498	2026-01-21 13:07:45.498
cmkvsiv160001la04mb1m0tcp	cmkvrmdf30002kv04fiektoth	1.72	80	Emagrecimento	Não	\N	3 anos	Não	\N	Não	\N	Não	\N	Não	\N	Não	\N	Não	\N	Imagino que não	Não	Não	Não	Não	Dificuldade em realizar abdominais	5 dias, sem desconforto ou fraqueza	Faz 3 anos sem praticar musculação, me considero iniciante	Online	Bom atendimento	Não	Não	Não	Não	Não	Não	Não	\N	\N	2026-01-26 23:20:17.562	2026-01-26 23:39:13.582
cmkvu6t970001l104hh2ydylx	cmkvtqft80002lb0432dc1djm	1.40	100.04	Emagrecimento	Sim	Caminhada por conta do trabalho	\N	Sim	Pressão Alta	Sim	Nos ombros ao levantar e nos pés ao levantar também	Sim	Restrição de muito esforço nos ombros e pés	Sim	Sente dor ao levantar os ombros e ao se levantar	Sim	Artrose	Sim	Losartana 50mg 	Obeso	Sim	Não	Sim	Não	Quando se senta em algum lugar sente dores fortes ao se levantar nos pés por conta da Artrose, dores ao levantar os braços	\N	Iniciante, faz dieta mas não fez exercicio fisico	Mora ao lado	\N	Não	Não	Não	Não	Não	Sim	Não	\N	\N	2026-01-27 00:06:54.619	2026-01-27 00:07:00.374
cmkwhow0e0004jo043krg7wf7	cmkwhlrxt0002jo04qahubxge	1.62	60	Saúde	Não	\N	1	Não	\N	Não	\N	Não	\N	Não	\N	Sim	Glúteos	Não	\N	Não	Sim	Não	Não	Não	Não	Não	Sim, intermediário	...	...	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-27 11:04:49.166	2026-01-27 11:04:49.166
cmkwo6oo70004la04pgifuvs1	cmkwo4i8f0002la04saafdb2c	1.63	78	Reabilitação	Sim	Academia	\N	Sim	Osteoporose	Não	\N	Não	\N	Não	\N	Sim	Bursite	Não	\N	Sim	Não	Não	Não	Não	Não.	...	Sim, iniciante-intermediário	...	...	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-27 14:06:37.159	2026-01-27 14:06:37.159
cmkxxv8zm0004ju04pr2ewzmx	cmkxxuw690002ju04z2awyd1l	1.86	91	Emagrecimento	Sim	Nado	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	2026-01-28 11:25:25.954	2026-01-28 11:25:25.954
\.


--
-- Data for Name: configuracoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.configuracoes (id, chave, valor, descricao, atualizado_em) FROM stdin;
cmk14m3o900016bg06n74tffb	NOME_ESTUDIO	Gabi Studio	Nome do estúdio	2026-01-05 12:17:52.666
cmk14m3od00026bg0zrde8ctj	TELEFONE_CONTATO		Telefone para contato	2026-01-05 12:17:52.67
cmk14m3og00036bg0a8ff9i2y	EMAIL_CONTATO	contato@gabistudio.com.br	Email para contato	2026-01-05 12:17:52.673
cmk14m3oi00046bg01suwwozl	DIAS_AVISO_VENCIMENTO	3	Dias antes do vencimento para enviar aviso	2026-01-05 12:17:52.675
cmk14m3ok00056bg0uqzmb770	HORARIO_LEMBRETE_AULA	2	Horas antes da aula para enviar lembrete	2026-01-05 12:17:52.676
\.


--
-- Data for Name: exercicios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exercicios (id, ficha_id, nome, grupo_muscular, series, repeticoes, descanso, observacoes, ordem, criado_em, atualizado_em, sessao) FROM stdin;
\.


--
-- Data for Name: fichas_treino; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fichas_treino (id, membro_id, nome, objetivo, observacoes, ativo, criado_em, atualizado_em, data) FROM stdin;
\.


--
-- Data for Name: horarios_disponiveis; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.horarios_disponiveis (id, dia_semana, hora_inicio, hora_fim, vagas_total, ativo, criado_em, atualizado_em) FROM stdin;
SEGUNDA-06:00	SEGUNDA	06:00	07:00	8	t	2026-01-05 12:17:52.588	2026-01-05 12:17:52.588
SEGUNDA-07:00	SEGUNDA	07:00	08:00	8	t	2026-01-05 12:17:52.592	2026-01-05 12:17:52.592
SEGUNDA-08:00	SEGUNDA	08:00	09:00	8	t	2026-01-05 12:17:52.595	2026-01-05 12:17:52.595
SEGUNDA-17:00	SEGUNDA	17:00	18:00	8	t	2026-01-05 12:17:52.598	2026-01-05 12:17:52.598
SEGUNDA-18:00	SEGUNDA	18:00	19:00	8	t	2026-01-05 12:17:52.6	2026-01-05 12:17:52.6
SEGUNDA-19:00	SEGUNDA	19:00	20:00	8	t	2026-01-05 12:17:52.604	2026-01-05 12:17:52.604
TERCA-06:00	TERCA	06:00	07:00	8	t	2026-01-05 12:17:52.606	2026-01-05 12:17:52.606
TERCA-07:00	TERCA	07:00	08:00	8	t	2026-01-05 12:17:52.609	2026-01-05 12:17:52.609
TERCA-08:00	TERCA	08:00	09:00	8	t	2026-01-05 12:17:52.612	2026-01-05 12:17:52.612
TERCA-17:00	TERCA	17:00	18:00	8	t	2026-01-05 12:17:52.614	2026-01-05 12:17:52.614
TERCA-18:00	TERCA	18:00	19:00	8	t	2026-01-05 12:17:52.616	2026-01-05 12:17:52.616
TERCA-19:00	TERCA	19:00	20:00	8	t	2026-01-05 12:17:52.618	2026-01-05 12:17:52.618
QUARTA-06:00	QUARTA	06:00	07:00	8	t	2026-01-05 12:17:52.621	2026-01-05 12:17:52.621
QUARTA-07:00	QUARTA	07:00	08:00	8	t	2026-01-05 12:17:52.623	2026-01-05 12:17:52.623
QUARTA-08:00	QUARTA	08:00	09:00	8	t	2026-01-05 12:17:52.625	2026-01-05 12:17:52.625
QUARTA-17:00	QUARTA	17:00	18:00	8	t	2026-01-05 12:17:52.627	2026-01-05 12:17:52.627
QUARTA-18:00	QUARTA	18:00	19:00	8	t	2026-01-05 12:17:52.629	2026-01-05 12:17:52.629
QUARTA-19:00	QUARTA	19:00	20:00	8	t	2026-01-05 12:17:52.631	2026-01-05 12:17:52.631
QUINTA-06:00	QUINTA	06:00	07:00	8	t	2026-01-05 12:17:52.633	2026-01-05 12:17:52.633
QUINTA-07:00	QUINTA	07:00	08:00	8	t	2026-01-05 12:17:52.636	2026-01-05 12:17:52.636
QUINTA-08:00	QUINTA	08:00	09:00	8	t	2026-01-05 12:17:52.638	2026-01-05 12:17:52.638
QUINTA-17:00	QUINTA	17:00	18:00	8	t	2026-01-05 12:17:52.64	2026-01-05 12:17:52.64
QUINTA-18:00	QUINTA	18:00	19:00	8	t	2026-01-05 12:17:52.642	2026-01-05 12:17:52.642
QUINTA-19:00	QUINTA	19:00	20:00	8	t	2026-01-05 12:17:52.644	2026-01-05 12:17:52.644
SEXTA-06:00	SEXTA	06:00	07:00	8	t	2026-01-05 12:17:52.646	2026-01-05 12:17:52.646
SEXTA-07:00	SEXTA	07:00	08:00	8	t	2026-01-05 12:17:52.648	2026-01-05 12:17:52.648
SEXTA-08:00	SEXTA	08:00	09:00	8	t	2026-01-05 12:17:52.65	2026-01-05 12:17:52.65
SEXTA-17:00	SEXTA	17:00	18:00	8	t	2026-01-05 12:17:52.652	2026-01-05 12:17:52.652
SEXTA-18:00	SEXTA	18:00	19:00	8	t	2026-01-05 12:17:52.654	2026-01-05 12:17:52.654
SEXTA-19:00	SEXTA	19:00	20:00	8	t	2026-01-05 12:17:52.656	2026-01-05 12:17:52.656
SABADO-08:00	SABADO	08:00	09:00	6	t	2026-01-05 12:17:52.658	2026-01-05 12:17:52.658
SABADO-09:00	SABADO	09:00	10:00	6	t	2026-01-05 12:17:52.661	2026-01-05 12:17:52.661
SABADO-10:00	SABADO	10:00	11:00	6	t	2026-01-05 12:17:52.663	2026-01-05 12:17:52.663
cmk2i2sqh00002mcj8khig5hz	SEGUNDA	05:00	06:00	10	t	2026-01-06 11:22:32.826	2026-01-06 11:22:32.826
cmk2idjua00072mcjbxcoga4m	TERCA	13:00	14:00	10	t	2026-01-06 11:30:54.514	2026-01-06 11:30:54.514
cmk2it6xl000a2mcj8tik4ak9	TERCA	05:00	06:00	10	t	2026-01-06 11:43:04.281	2026-01-06 11:43:04.281
cmk2itfng000f2mcjemtcltxm	QUARTA	05:00	06:00	10	t	2026-01-06 11:43:15.581	2026-01-06 11:43:15.581
cmk2jetqg000s2mcjgfxb5waq	QUINTA	05:00	06:00	10	t	2026-01-06 11:59:53.608	2026-01-06 11:59:53.608
cmk2kq8j5000y2msarfpfpk7o	SEGUNDA	15:00	16:00	10	t	2026-01-06 12:36:45.617	2026-01-06 12:36:45.617
cmk2kq8ji00172msal7kljpg1	TERCA	15:00	16:00	10	t	2026-01-06 12:36:45.631	2026-01-06 12:36:45.631
cmk2kq8jt001g2msaiyh21pmu	QUARTA	15:00	16:00	10	t	2026-01-06 12:36:45.641	2026-01-06 12:36:45.641
cmk2kq8k3001p2msay0oj9p7u	QUINTA	15:00	16:00	10	t	2026-01-06 12:36:45.652	2026-01-06 12:36:45.652
cmk2kq8ke00202msas9foc61a	SEXTA	15:00	16:00	10	t	2026-01-06 12:36:45.663	2026-01-06 12:36:45.663
cmk2kq8kr002b2msamkksrgf5	SEGUNDA	16:00	17:00	10	t	2026-01-06 12:36:45.675	2026-01-06 12:36:45.675
cmk2kq8l0002k2msasi6djwph	TERCA	16:00	17:00	10	t	2026-01-06 12:36:45.685	2026-01-06 12:36:45.685
cmk2kq8lc002t2msag1rmi700	QUARTA	16:00	17:00	10	t	2026-01-06 12:36:45.696	2026-01-06 12:36:45.696
cmk2kq8lm00322msas3daxefo	QUINTA	16:00	17:00	10	t	2026-01-06 12:36:45.706	2026-01-06 12:36:45.706
cmk2kq8lx003d2msaicgiovas	SEXTA	16:00	17:00	10	t	2026-01-06 12:36:45.718	2026-01-06 12:36:45.718
cmk2kq8u3003r2msahxegmrk3	QUARTA	09:00	10:00	10	t	2026-01-06 12:36:46.012	2026-01-06 12:36:46.012
cmk2kq93j004t2msa1hcg8y08	QUINTA	09:00	10:00	10	t	2026-01-06 12:36:46.351	2026-01-06 12:36:46.351
cmk2kq93w00542msamf8b9l44	SEGUNDA	13:00	14:00	10	t	2026-01-06 12:36:46.365	2026-01-06 12:36:46.365
cmk2kq94g005l2msadl37g9mr	QUARTA	13:00	14:00	10	t	2026-01-06 12:36:46.385	2026-01-06 12:36:46.385
cmk2kq94r005u2msaiblb4z13	QUINTA	13:00	14:00	10	t	2026-01-06 12:36:46.396	2026-01-06 12:36:46.396
cmk2kq95400652msatq98u949	SEXTA	13:00	14:00	10	t	2026-01-06 12:36:46.409	2026-01-06 12:36:46.409
cmk2kqa5800a82msa4t1kwix5	QUINTA	11:00	12:00	10	t	2026-01-06 12:36:47.708	2026-01-06 12:36:47.708
cmk2kqbe900fo2msazmsum81w	QUINTA	10:00	11:00	10	t	2026-01-06 12:36:49.329	2026-01-06 12:36:49.329
cmk2kqdgp00jo2msa6sonzcpl	QUARTA	11:00	12:00	10	t	2026-01-06 12:36:52.009	2026-01-06 12:36:52.009
cmk2kqdhh00k52msa4z5y5x0y	SABADO	17:00	18:00	10	t	2026-01-06 12:36:52.037	2026-01-06 12:36:52.037
cmk2kqdht00kg2msa6bprjwd1	QUARTA	10:00	11:00	10	t	2026-01-06 12:36:52.05	2026-01-06 12:36:52.05
cmk2kqfhl00sp2msax6n9bedh	QUINTA	12:00	13:00	10	t	2026-01-06 12:36:54.634	2026-01-06 12:36:54.634
cmk2kqlqe015j2msav05sqhbr	SABADO	05:00	06:00	10	t	2026-01-06 12:37:02.727	2026-01-06 12:37:02.727
cmk2m1qun00002m4k4vi2rp9t	TERCA	09:00	10:00	10	t	2026-01-06 13:13:42.192	2026-01-06 13:13:42.192
cmk2mg5w300012m4kjy7imet4	TERCA	11:00	12:00	10	t	2026-01-06 13:24:54.868	2026-01-06 13:24:54.868
cmkb53kmy0000ju04fwqn5jq9	SEGUNDA	12:00	13:00	10	t	2026-01-12 12:29:09.562	2026-01-12 12:29:09.562
cmkb73zzh001e2mrmyw04xxnn	SEXTA	05:00	06:00	10	t	2026-01-12 13:25:28.686	2026-01-12 13:25:28.686
cmkb77mzd00ic2mrmagrtkapf	SEGUNDA	09:00	10:00	10	t	2026-01-12 13:28:18.457	2026-01-12 13:28:18.457
cmkb77qbc00it2mrm48myv7cm	SEXTA	09:00	10:00	10	t	2026-01-12 13:28:22.776	2026-01-12 13:28:22.776
cmkb77yb500ju2mrmh718oogt	SEGUNDA	10:00	11:00	10	t	2026-01-12 13:28:33.138	2026-01-12 13:28:33.138
cmkb78a3u00kb2mrmtcyty4sp	SEXTA	10:00	11:00	10	t	2026-01-12 13:28:48.426	2026-01-12 13:28:48.426
cmkb78ptg00ln2mrmanq23795	SEGUNDA	11:00	12:00	10	t	2026-01-12 13:29:08.789	2026-01-12 13:29:08.789
cmkb791rp00m42mrmp45o027x	SEXTA	11:00	12:00	10	t	2026-01-12 13:29:24.277	2026-01-12 13:29:24.277
cmkb79mmr00o52mrmrmzlybf8	SEXTA	12:00	13:00	10	t	2026-01-12 13:29:51.315	2026-01-12 13:29:51.315
cmkb7htnu01r72mrmgne9fuk3	TERCA	10:00	11:00	10	t	2026-01-12 13:36:13.674	2026-01-12 13:36:13.674
cmkeadfce0000le04973ylera	QUARTA	12:00	13:00	10	t	2026-01-14 17:20:05.87	2026-01-14 17:20:05.87
cmkym0b280000ky04adozghti	SEGUNDA	14:00	15:00	10	t	2026-01-28 22:41:12.704	2026-01-28 22:41:12.704
\.


--
-- Data for Name: horarios_fixos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.horarios_fixos (id, membro_id, dia_semana, hora, criado_em) FROM stdin;
cmky24da60000jm04bqncwlgc	cmkwo4i8f0002la04saafdb2c	SEGUNDA	08:00	2026-01-28 13:24:29.886
cmky24da60001jm04j8br46on	cmkwo4i8f0002la04saafdb2c	QUARTA	08:00	2026-01-28 13:24:29.886
cmky24da60002jm0415huum96	cmkwo4i8f0002la04saafdb2c	QUINTA	09:00	2026-01-28 13:24:29.886
\.


--
-- Data for Name: membros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.membros (id, usuario_id, cpf, telefone, data_nascimento, observacoes, status, foto_url, criado_em, atualizado_em, plano_id, rg, preco_customizado, sexo, anamnese_token, anamnese_token_expira) FROM stdin;
cmk198udu001n2mi08jmfeiiv	cmk198uds001l2mi0ywai9qty	01771324180	67996127753	1987-10-08 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:32.178	2026-01-05 14:27:32.178	\N	\N	\N	\N	\N	\N
cmk198vpt00222mi0p1etbg19	cmk198vpq00202mi0hvjkbdvh	03557629198	67996992960	1996-01-17 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:33.905	2026-01-05 14:27:33.905	\N	\N	\N	\N	\N	\N
cmk198xb0002k2mi0o3fe7wrw	cmk198xay002i2mi0ks5nqmcm	93033222072	66981184252	1977-02-04 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:35.965	2026-01-05 14:27:35.965	\N	\N	\N	\N	\N	\N
cmk198z5n00352mi0n28kj1ab	cmk198z5l00332mi0i5gx8ig2	50162420110	67999350333	1972-11-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:38.364	2026-01-05 14:27:38.364	\N	\N	\N	\N	\N	\N
cmk198zf500382mi0jrnab4xv	cmk198zf300362mi0ifzkx623	81542968100	67999768110	1977-07-22 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:38.705	2026-01-05 14:27:38.705	\N	\N	\N	\N	\N	\N
cmk198zoo003b2mi0ysucbtvn	cmk198zom00392mi00dool0pw	85354899672	6781243131	1973-08-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:39.049	2026-01-05 14:27:39.049	\N	\N	\N	\N	\N	\N
cmk198zy7003e2mi05f1soi6b	cmk198zy5003c2mi0zk3nw6y4	00313313199	67999451450	1981-12-13 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:39.391	2026-01-05 14:27:39.391	\N	\N	\N	\N	\N	\N
cmk1990h9003k2mi0138jf3hx	cmk1990h7003i2mi0wdc0k4zv	03210945144	67999263270	1986-12-20 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:40.077	2026-01-05 14:27:40.077	\N	\N	\N	\N	\N	\N
cmk19935r004e2mi0m2r8qwye	cmk19935o004c2mi0w4dliofv	21752220803	67998368622	1980-03-23 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:43.551	2026-01-05 14:27:43.551	\N	\N	\N	\N	\N	\N
cmk1993ou004k2mi0o0iyh8eu	cmk1993or004i2mi0v92jzh8y	01553060148	67981134045	1985-10-19 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:44.238	2026-01-05 14:27:44.238	\N	\N	\N	\N	\N	\N
cmk198q4n000b2mi0m4gh4l7d	cmk198q4l00092mi08fzl7up0	06769093880	67999604193	1969-02-03 00:00:00	\N	ATIVO	\N	2026-01-05 14:27:26.663	2026-01-22 13:27:47.56	cmk1f7oxe00032mj5rulkz0fu		\N	\N	\N	\N
cmk198qnv000h2mi03o0z9uz1	cmk198qnt000f2mi03n5p5l7w	78437288134	67996627783	1977-05-16 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:27.355	2026-01-05 17:15:13.628	cmk1f7oxf00042mj5uq7afrs4	\N	\N	\N	\N	\N
cmk198rgk000q2mi06son5v80	cmk198rgg000o2mi0cam23k7n	04645439162	67996015382	1993-05-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:28.388	2026-01-05 17:15:13.64	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmkxxuw690002ju04z2awyd1l	cmkxxtlk60000ju04pr6q8g3u	04940661130	67992445736	2006-03-09 00:00:00	\N	ATIVO	\N	2026-01-28 11:25:09.345	2026-01-28 11:26:09.954	cmk1f7oxj00092mj50f764fef		0.00	MASCULINO	0ddfd5f400a2193d568b8fe717747b75d3a3e37602066f441bc29636d74b8dd5	2026-01-29 11:25:09.324
cmk198rzq000w2mi0zho10guw	cmk198rzn000u2mi0l50tldta	04183366100	67996328670	1993-01-15 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:29.078	2026-01-05 17:15:13.646	cmk1f7oxg00052mj5fvecfmq4	\N	\N	\N	\N	\N
cmk198ssg00152mi0n4l4fp96	cmk198ssd00132mi00mwvymrw	77223748168	67999619293	1975-05-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:30.112	2026-01-05 17:15:13.655	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk198t2000182mi065p6smae	cmk198t1y00162mi0hcojyy7i	51845482115	67999735160	1972-11-26 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:30.456	2026-01-05 17:15:13.658	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk198tbj001b2mi0x13vbcvr	cmk198tbh00192mi03y00rh1r	60831677104	67999779240	1975-03-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:30.8	2026-01-05 17:15:13.659	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198u4a001k2mi0ca568vue	cmk198u48001i2mi0nzwlwkmg	04650297109	67996728812	1994-04-14 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:31.835	2026-01-05 17:15:13.664	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198unf001q2mi0mwzfdm8t	cmk198und001o2mi0oh2gezmf	02460469101	67996907737	1988-12-03 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:32.523	2026-01-05 17:15:13.666	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk198v6k001w2mi02ivlhs3x	cmk198v6h001u2mi04sn2a5v2	33872350110	67999565353	1964-12-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:33.212	2026-01-05 17:15:13.67	cmk1f7oxh00072mj5vitn09ou	\N	\N	\N	\N	\N
cmk198vzb00252mi04vqq9fqr	cmk198vz900232mi0gu6vbfge	03072139199	67998346068	1988-08-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:34.248	2026-01-05 17:15:13.675	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk198w8w00282mi0j7se4tva	cmk198w8u00262mi09bb39uo4	89725026187	67999220953	1980-05-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:34.592	2026-01-05 17:15:13.677	cmk1f7oxi00082mj54d8lbst3	\N	\N	\N	\N	\N
cmk198wig002b2mi06vqg92nm	cmk198wie00292mi072vbm1ur	02927154120	67996077090	1994-10-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:34.937	2026-01-05 17:15:13.678	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk198wrz002e2mi0yuwdflbl	cmk198wrx002c2mi06yc6floh	01318851114	67981768815	1985-08-04 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:35.279	2026-01-05 17:15:13.68	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198xki002n2mi0ld2bpbxf	cmk198xkh002l2mi0v92rd3pt	03515202102	67999738797	1993-07-08 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:36.307	2026-01-05 17:15:13.683	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk198xtz002q2mi0oynknikc	cmk198xtx002o2mi0d6iu4fgr	04365599194	67996577779	1993-09-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:36.648	2026-01-05 17:15:13.685	cmk1f7oxj00092mj50f764fef	\N	\N	\N	\N	\N
cmk198y3i002t2mi0mtl1jvo5	cmk198y3h002r2mi03zm8z3qp	03394071150	67998887320	1991-04-27 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:36.991	2026-01-05 17:15:13.687	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198yd2002w2mi0q45w78j8	cmk198yd0002u2mi0nyzyayer	01732000107	67999481113	1987-09-12 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:37.335	2026-01-05 17:15:13.689	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk198yw500322mi040x0cops	cmk198yw300302mi05lbtak7b	51836289120	67996315797	1970-12-17 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:38.021	2026-01-05 17:15:13.693	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk19907q003h2mi0qnc78uip	cmk19907o003f2mi0lnpkfc9r	01070102164	67999485034	1995-12-11 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:39.735	2026-01-05 17:15:13.695	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk1990qt003n2mi0hdys30el	cmk1990qr003l2mi05ihqr8b4	00449583155	67981734895	1985-01-28 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:40.422	2026-01-05 17:15:13.698	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk19910c003q2mi020xyodij	cmk19910a003o2mi0x4in8vkv	84547006172	67999735059	1978-05-31 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:40.765	2026-01-05 17:15:13.7	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk1991je003w2mi0ht5znrf8	cmk1991jc003u2mi0x43k03da	00478480148	67996938347	1982-06-07 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:41.45	2026-01-05 17:15:13.704	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk1991u6003z2mi0k29x32yg	cmk1991u4003x2mi0lzrvuoyj	02123469114	62981299334	1988-06-24 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:41.838	2026-01-05 17:15:13.706	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk19923q00422mi0yqihonao	cmk19923o00402mi04jhhoukb	05123571108	67992877465	1995-01-09 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:42.182	2026-01-05 17:15:13.708	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1992d700452mi0rqrrtbi2	cmk1992d600432mi0a12mvzsm	08440764146	67996096667	2011-01-24 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:42.524	2026-01-05 17:15:13.71	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1992w9004b2mi08maqjp3l	cmk1992w700492mi03gxe37jd	00733206921	67996202574	1979-10-26 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:43.21	2026-01-05 17:15:13.714	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1993f9004h2mi0fqdke02o	cmk1993f7004f2mi0sj3w9sny	01050955161	67991358980	1984-10-23 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:43.894	2026-01-05 17:15:13.716	cmk1f7oxj00092mj50f764fef	\N	\N	\N	\N	\N
cmk19950f004z2mi0up36poxo	cmk19950e004x2mi0kx0a6k3k	04411986191	67999734700	1943-03-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:45.952	2026-01-05 14:27:45.952	\N	\N	\N	\N	\N	\N
cmk19962d005b2mi0d9hsy0kv	cmk19962b00592mi0tdywcjp0	36670915837	67996465877	1989-08-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:47.318	2026-01-05 14:27:47.318	\N	\N	\N	\N	\N	\N
cmk1996lu005h2mi0krzlfmel	cmk1996ls005f2mi08l3x8a33	08468934100	67998929649	2003-04-25 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:48.018	2026-01-05 14:27:48.018	\N	\N	\N	\N	\N	\N
cmk19974z005n2mi07svyi7h3	cmk19974x005l2mi0krywoy33	24914431807	67999647886	1976-04-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:48.707	2026-01-05 14:27:48.707	\N	\N	\N	\N	\N	\N
cmk1997xk005w2mi01zy19trl	cmk1997xi005u2mi0ap4dsiaq	02387908198	67996887951	1989-03-13 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:49.737	2026-01-05 14:27:49.737	\N	\N	\N	\N	\N	\N
cmk199abj006n2mi0uq99m3c9	cmk199abh006l2mi0oh2jwgf7	08958652110	67998050384	2006-06-09 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:52.831	2026-01-05 14:27:52.831	\N	\N	\N	\N	\N	\N
cmk199av4006t2mi0bziu6mfr	cmk199av2006r2mi0ozs44dpw	87061635134	67999720221	1980-01-29 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:53.536	2026-01-05 14:27:53.536	\N	\N	\N	\N	\N	\N
cmk199c8o00782mi0i58xo9to	cmk199c8m00762mi00qg491f9	03980329127	67999238681	1991-05-15 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:55.321	2026-01-05 14:27:55.321	\N	\N	\N	\N	\N	\N
cmk199cic007b2mi0qtp5mco9	cmk199cib00792mi0jf1bc69l	58325611120	67998318810	1975-07-17 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:55.669	2026-01-05 14:27:55.669	\N	\N	\N	\N	\N	\N
cmk199dau007k2mi0lhotaaqr	cmk199das007i2mi0kzuvrkrc	02405981130	67998616006	1989-01-06 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:56.695	2026-01-05 14:27:56.695	\N	\N	\N	\N	\N	\N
cmk199du0007q2mi0n8lox17j	cmk199dtz007o2mi08umpmhcx	22038922187	67999734041	1960-09-13 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:57.384	2026-01-05 14:27:57.384	\N	\N	\N	\N	\N	\N
cmk199ewr00822mi0vuk7c9dr	cmk199ewp00802mi0r2xau24f	05370483167	67998103365	1994-04-22 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:58.78	2026-01-05 14:27:58.78	\N	\N	\N	\N	\N	\N
cmk199f6d00852mi0mbwn66lc	cmk199f6b00832mi0f5zgjn8p	05112119101	67996059276	1997-07-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:59.126	2026-01-05 14:27:59.126	\N	\N	\N	\N	\N	\N
cmk199fpg008b2mi0xsa8dufo	cmk199fpe00892mi0yxndcdik	60950706191	67999735610	1969-02-28 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:59.812	2026-01-05 14:27:59.812	\N	\N	\N	\N	\N	\N
cmkvrmdf30002kv04fiektoth	cmkvrmdej0000kv04qkmd6w40	10726224162	67999815873	2002-09-07 00:00:00	\N	ATIVO	\N	2026-01-26 22:55:01.744	2026-01-26 22:55:01.744	cmk1f7ox800002mj59lsuuga4	2031033	265.00	FEMININO	\N	\N
cmk199h15008q2mi0g41n6pjf	cmk199h13008o2mi00ehoc3u7	04751131109	67998969004	1992-05-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:01.53	2026-01-05 14:28:01.53	\N	\N	\N	\N	\N	\N
cmk199hk8008w2mi0fgv8gyme	cmk199hk6008u2mi0348ojpj4	93477570120	67999048723	1978-11-30 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:02.217	2026-01-05 14:28:02.217	\N	\N	\N	\N	\N	\N
cmk199htt008z2mi0x6jn63l0	cmk199htr008x2mi0igi7971b	01715106156	67999768208	1987-06-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:02.561	2026-01-05 14:28:02.561	\N	\N	\N	\N	\N	\N
cmk199i3b00922mi0b9qug5km	cmk199i3900902mi0e844g6pu	57240280187	67999735068	1972-01-17 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:02.904	2026-01-05 14:28:02.904	\N	\N	\N	\N	\N	\N
cmk1994hf004t2mi0x3r67zy4	cmk1994hd004r2mi0f835pusx	04673973178	67999381341	1994-10-03 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:45.267	2026-01-05 17:15:13.721	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk1994qy004w2mi0xw4k8wum	cmk1994qw004u2mi0chbr5ywx	04837110126	67999986406	1993-04-27 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:45.61	2026-01-05 17:15:13.723	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk19959u00522mi0axqrsecj	cmk19959s00502mi0r8rblpb7	00671413902	43988316542	1961-03-10 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:46.291	2026-01-05 17:15:13.724	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1995jc00552mi0cc7ame27	cmk1995ja00532mi08xh5ghze	81145721168	67999734914	1978-02-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:46.632	2026-01-05 17:15:13.726	cmk1f7oxq000a2mj5q21b3ugp	\N	\N	\N	\N	\N
cmk1996by005e2mi0jcdco3ca	cmk1996bw005c2mi0o2nx84ji	10000846120	67999816426	2014-04-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:47.662	2026-01-05 17:15:13.731	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1996vh005k2mi0fo6ow0xh	cmk1996vd005i2mi02hiunqnw	01957315148	67996237701	1990-05-23 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:48.366	2026-01-05 17:15:13.733	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk1997el005q2mi02t6inz7d	cmk1997ek005o2mi0zrzqit0y	00543552144	67996096667	1985-09-12 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:49.054	2026-01-05 17:15:13.735	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk1997o3005t2mi09sqsxelz	cmk1997o0005r2mi0enxfx4g1	02748325184	67999193196	1988-03-17 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:49.395	2026-01-05 17:15:13.736	cmk1f7oxc00012mj5ojq5bean	\N	\N	\N	\N	\N
cmk1998gm00622mi0co8yuy4y	cmk1998gi00602mi0u1mldh3f	04200717174	67999191882	1994-08-27 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:50.422	2026-01-05 17:15:13.74	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk1998q400652mi0j3oh8k8f	cmk1998q100632mi00619av3h	63719100197	67999733071	1975-06-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:50.764	2026-01-05 17:15:13.741	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk1998zo00682mi0mjhxpnpw	cmk1998zl00662mi0y5n1gtio	06548129180	67996056091	1998-10-26 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:51.108	2026-01-05 17:15:13.743	cmk1f7oxc00012mj5ojq5bean	\N	\N	\N	\N	\N
cmk1999s8006h2mi0p4pbtt3b	cmk1999s7006f2mi0wpia2cvy	44626215149	67999565256	1951-02-05 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:52.137	2026-01-05 17:15:13.749	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199a1u006k2mi0nip791nz	cmk199a1s006i2mi0u68cfb4e	87997843191	6799474694	1975-03-22 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:52.482	2026-01-05 17:15:13.751	cmk1f7oxc00012mj5ojq5bean	\N	\N	\N	\N	\N
cmk199alf006q2mi0v7013ak0	cmk199ald006o2mi0sjo0t1qy	26021972899	67999222208	1977-09-29 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:53.187	2026-01-05 17:15:13.754	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199b4q006w2mi04s7rgel2	cmk199b4o006u2mi0hpfoxu9z	04680903120	67996599023	1992-11-27 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:53.883	2026-01-05 17:15:13.756	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199bpg00722mi0h2liupqd	cmk199bpe00702mi0qr0r3wxk	10507162994	67998086708	2012-09-12 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:54.628	2026-01-05 17:15:13.759	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199bz100752mi0l1otqgsk	cmk199bz000732mi05u2on7mv	40066227836	67996132417	1991-02-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:54.974	2026-01-05 17:15:13.761	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199crt007e2mi0wep49upc	cmk199crs007c2mi00ihlpvgz	59593725172	67981363777	1975-10-15 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:56.009	2026-01-05 17:15:13.763	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199d1a007h2mi0x7acbnq4	cmk199d17007f2mi0suka644o	92590454104	67999544680	1981-03-30 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:56.35	2026-01-05 17:15:13.764	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199e3m007t2mi0ixoer361	cmk199e3k007r2mi0bf2eaqtt	04981914946	44999912264	1992-04-14 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:57.731	2026-01-05 17:15:13.767	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199ed9007w2mi097opy2sx	cmk199ed6007u2mi0dkp0a0mv	04892899160	67998890989	2009-07-01 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:58.077	2026-01-05 17:15:13.769	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk199en2007z2mi0dx7y88kk	cmk199emy007x2mi0xrrlzdtv	00042201101	67996765901	1983-07-13 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:58.43	2026-01-05 17:15:13.77	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199ffw00882mi0kl7sg4ty	cmk199ffu00862mi0nunhp0km	04144781186	67996467339	1998-09-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:59.468	2026-01-05 17:15:13.772	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199g8l008h2mi0oa3cch2x	cmk199g8j008f2mi0imwh7vif	92603815172	67996022336	1969-04-17 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:00.501	2026-01-05 17:15:13.776	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199grl008n2mi04xzr6jlk	cmk199grj008l2mi0wkdnkwvc	02462545131	67992262809	1989-12-15 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:01.186	2026-01-05 17:15:13.777	cmk1f7oxf00042mj5uq7afrs4	\N	\N	\N	\N	\N
cmk199han008t2mi0gavokllh	cmk199ham008r2mi0yxh3g1lj	01486633110	67991759669	1987-09-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:01.872	2026-01-05 17:15:13.779	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199icw00952mi0lsmpw8e3	cmk199icv00932mi0qki96l3s	12940843805	67999387789	1970-06-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:03.249	2026-01-05 17:15:13.781	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199jov009k2mi0duwv55hw	cmk199jos009i2mi0qqpemvu8	10044880170	67993080320	2000-06-19 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:04.975	2026-01-05 14:28:04.975	\N	\N	\N	\N	\N	\N
cmk199ltl00a82mi0gt98iimk	cmk199ltk00a62mi0dqt53n1y	01971659150	67999812208	1986-05-19 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:07.738	2026-01-05 14:28:07.738	\N	\N	\N	\N	\N	\N
cmk199m3600ab2mi079i4s20x	cmk199m3400a92mi0pzp0kc3q	81400446104	67999730773	1977-08-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:08.082	2026-01-05 14:28:08.082	\N	\N	\N	\N	\N	\N
cmk199mmc00ah2mi0j7idnzko	cmk199mma00af2mi0ww8zv7d9	29440874104	67999734496	1960-01-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:08.773	2026-01-05 14:28:08.773	\N	\N	\N	\N	\N	\N
cmk199n5t00an2mi0ei7myxal	cmk199n5r00al2mi09zzoqgs0	02676996118	67996781094	1987-06-01 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:09.474	2026-01-05 14:28:09.474	\N	\N	\N	\N	\N	\N
cmk199nyo00aw2mi0l2xxozps	cmk199nyl00au2mi0o45ydmcg	08643487112	67999373555	2001-12-05 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:10.513	2026-01-05 14:28:10.513	\N	\N	\N	\N	\N	\N
cmk199o8e00az2mi0yin8q7j6	cmk199o8c00ax2mi0mrrt6s7x	03581333198	67999580298	1987-06-10 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:10.863	2026-01-05 14:28:10.863	\N	\N	\N	\N	\N	\N
cmk199osp00b52mi07yc89x8b	cmk199osn00b32mi0rx0s7i2m	03409521135	6799234571	1989-04-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:11.594	2026-01-05 14:28:11.594	\N	\N	\N	\N	\N	\N
cmk199p2a00b82mi0ip25rsdl	cmk199p2800b62mi07u72n8bb	00652837166	67992990052	1984-12-01 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:11.939	2026-01-05 14:28:11.939	\N	\N	\N	\N	\N	\N
cmk199pc000bb2mi0o2xcuh9m	cmk199pbv00b92mi0jrc2svqq	05862591125	44999702179	1996-08-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:12.288	2026-01-05 14:28:12.288	\N	\N	\N	\N	\N	\N
cmk199plo00be2mi0zvel8mkr	cmk199pln00bc2mi0jypj7dmb	27946482841	67999426998	1979-11-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:12.637	2026-01-05 14:28:12.637	\N	\N	\N	\N	\N	\N
cmk199q4v00bk2mi0k9cdjvj1	cmk199q4t00bi2mi0aq3roc1z	06191620900	18981014061	1988-07-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:13.328	2026-01-05 14:28:13.328	\N	\N	\N	\N	\N	\N
cmkvtqft80002lb0432dc1djm	cmkvtqfs40000lb04kdoyam1v	16484819149	67999734795	1961-06-02 00:00:00	\N	ATIVO	\N	2026-01-26 23:54:10.7	2026-01-26 23:54:10.7	cmk1f7oxd00022mj5ok901iru	040360	365.00	MASCULINO	\N	\N
cmk199rgu00bz2mi0jbm83e0i	cmk199rgs00bx2mi0bbqak6jc	10953901980	67998649645	1996-05-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:15.055	2026-01-05 14:28:15.055	\N	\N	\N	\N	\N	\N
cmk199sb700c82mi0f6kviwjw	cmk199sb500c62mi0prqzsc5y	07759084102	67999120287	2001-02-15 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:16.148	2026-01-05 14:28:16.148	\N	\N	\N	\N	\N	\N
cmk199skr00cb2mi04b0b5ohm	cmk199skp00c92mi0zz3ua5b4	00336806124	67984822936	1982-09-08 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:16.492	2026-01-05 14:28:16.492	\N	\N	\N	\N	\N	\N
cmk199suc00ce2mi0ubmhze80	cmk199sua00cc2mi0s3shckxl	01764779185	67999425927	1986-07-07 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:16.836	2026-01-05 14:28:16.836	\N	\N	\N	\N	\N	\N
cmk199u5w00ct2mi01h2b92y7	cmk199u5v00cr2mi07t2ys1rq	02740314183	67996413430	1987-03-23 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:18.549	2026-01-05 14:28:18.549	\N	\N	\N	\N	\N	\N
cmk1ezvuu00cw2mi0rui6xiaw	cmk1ezvuq00cu2mi0tfpmdvd7	05182440677	67998805555	1983-04-15 04:00:00	\N	ATIVO	\N	2026-01-05 17:08:31.879	2026-01-05 17:08:31.879	\N	\N	\N	\N	\N	\N
cmk1ezw3100cz2mi0mg127gqi	cmk1ezw2z00cx2mi0zppyx9sg	05863736160	67996636096	1995-09-29 04:00:00	\N	ATIVO	\N	2026-01-05 17:08:32.173	2026-01-05 17:08:32.173	\N	\N	\N	\N	\N	\N
cmk198pbt00022mi0uothgwyv	cmk198pbp00002mi0p331wbza	83689435153	67998133086	1977-06-19 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:25.626	2026-01-05 17:15:13.611	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk198plh00052mi0vd9sq0ac	cmk198plf00032mi0s79vyr6w	01450622100	67996545483	1987-04-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:25.973	2026-01-05 17:15:13.618	cmk1f7oxc00012mj5ojq5bean	\N	\N	\N	\N	\N
cmk198qxe000k2mi0yrn7b1l5	cmk198qxc000i2mi04jtafxdy	92267858134	67999436631	1980-09-10 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:27.699	2026-01-05 17:15:13.635	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198s9b000z2mi0oqitra0w	cmk198s99000x2mi0r7gfbpx0	03101706130	67998644858	1989-07-20 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:29.423	2026-01-05 17:15:13.648	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk198tur001h2mi0aitg53mf	cmk198tup001f2mi01zz2sj0u	00896035166	67999633809	1991-06-22 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:31.491	2026-01-05 17:15:13.662	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk198vg8001z2mi0mo9by5g7	cmk198vg6001x2mi0hqy6rax2	05083131129	67996053468	1993-07-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:33.561	2026-01-05 17:15:13.672	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk198x1i002h2mi0xm55s0kp	cmk198x1g002f2mi0qnk0qphx	04616039186	67998298681	2000-05-19 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:35.623	2026-01-05 17:15:13.682	cmk1f7oxc00012mj5ojq5bean	\N	\N	\N	\N	\N
cmk199iw0009b2mi03pzql81x	cmk199ivy00992mi0hci37p99	00516231960	67998500103	1983-03-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:03.937	2026-01-05 17:15:13.784	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk199j5k009e2mi063detome	cmk199j5i009c2mi0yrb1dnkr	59607653149	67999735223	1968-09-12 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:04.28	2026-01-05 17:15:13.786	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199jye009n2mi0w0jfqkmz	cmk199jyc009l2mi0ti5dhfve	95000836120	67981337435	1982-04-15 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:05.318	2026-01-05 17:15:13.789	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199khj009t2mi0wi1jutmy	cmk199khh009r2mi0j09cqdx4	00116332123	67998470757	1979-08-25 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:06.007	2026-01-05 17:15:13.791	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199l0m009z2mi0o4jc5stf	cmk199l0k009x2mi0crhfczfx	85623067115	6799982225	1980-02-26 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:06.695	2026-01-05 17:15:13.792	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199la800a22mi0rix5sr61	cmk199la600a02mi0hejehbiw	44647360172	67999733559	1967-12-24 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:07.04	2026-01-05 17:15:13.794	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199mcr00ae2mi0ldpn3s2e	cmk199mcq00ac2mi0pkmz4xhd	61481238191	67984236816	1975-07-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:08.428	2026-01-05 17:15:13.797	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199mw000ak2mi0jci74kn1	cmk199mvy00ai2mi03u3gv6p0	96944676168	67996851837	1981-01-28 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:09.121	2026-01-05 17:15:13.799	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199nff00aq2mi0vb28mgm9	cmk199nfd00ao2mi0sdv9xkwk	86183800163	67998968697	1974-06-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:09.819	2026-01-05 17:15:13.801	cmk1f7oxq000b2mj522r61kkb	\N	\N	\N	\N	\N
cmk199np000at2mi029bdkmbl	cmk199noy00ar2mi0ge6nntiw	36201693068	67998315486	1962-03-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:10.165	2026-01-05 17:15:13.803	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199pva00bh2mi02mxgafux	cmk199pv900bf2mi0file4krc	89180607187	67998730184	1980-04-27 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:12.983	2026-01-05 17:15:13.807	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk199qek00bn2mi0uf8rcy1z	cmk199qei00bl2mi0d8pm6b31	04312755132	67998377858	1991-06-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:13.676	2026-01-05 17:15:13.809	cmk1f7oxi00082mj54d8lbst3	\N	\N	\N	\N	\N
cmk199qo600bq2mi03e2boh4l	cmk199qo500bo2mi0lupz4g7g	46480404149	67996303001	1970-03-07 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:14.023	2026-01-05 17:15:13.81	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199qxt00bt2mi0r95b680e	cmk199qxr00br2mi0zonpfm9g	05470265102	67999323192	1994-07-24 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:14.37	2026-01-05 17:15:13.812	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199s0g00c52mi0i8p0t7p0	cmk199s0c00c32mi0x591appl	04378887118	67992298071	2005-10-20 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:15.761	2026-01-05 17:15:13.816	cmk1f7oxj00092mj50f764fef	\N	\N	\N	\N	\N
cmk199t3v00ch2mi0a6m6uo63	cmk199t3t00cf2mi0rt9nhqp9	83841261191	67999197802	1977-02-04 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:17.18	2026-01-05 17:15:13.818	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199tde00ck2mi0g7i25ghy	cmk199tdc00ci2mi03ewvrczh	87068621104	67999620012	1979-07-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:17.522	2026-01-05 17:15:13.819	cmk1f7oxi00082mj54d8lbst3	\N	\N	\N	\N	\N
cmk199tmy00cn2mi09605wcmr	cmk199tmw00cl2mi011x6cccu	06368797983	44991541961	1990-04-21 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:17.866	2026-01-05 17:15:13.821	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk198ymk002z2mi0autshqqd	cmk198ymi002x2mi0ckjoakw3	80092390110	67999300120	1974-05-26 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:37.677	2026-01-05 17:15:13.69	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk19919v003t2mi03hkk7v2u	cmk19919t003r2mi093qbf3lh	72739606087	67992041120	1977-05-01 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:41.108	2026-01-05 17:15:13.702	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk1992mq00482mi0b387dr8k	cmk1992mo00462mi085sp83y0	04654710132	67998437190	2004-08-12 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:42.866	2026-01-05 17:15:13.712	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk19947v004q2mi0iaac2gmn	cmk19947t004o2mi0ohnm24nq	04168578178	67999183449	1993-02-04 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:44.923	2026-01-05 17:15:13.719	cmk1f7ox800002mj59lsuuga4	\N	\N	\N	\N	\N
cmk1995sw00582mi0hz95iyba	cmk1995su00562mi02nosyat0	52908429187	67996981388	1974-05-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:46.976	2026-01-05 17:15:13.729	cmk1f7oxd00022mj5ok901iru	\N	\N	\N	\N	\N
cmk199871005z2mi0idxecery	cmk199870005x2mi0ag1x4w8h	00751941980	67998621312	1981-01-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:50.078	2026-01-05 17:15:13.738	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk1999iq006e2mi0t3jx81b3	cmk1999ip006c2mi0orzonsxh	00691926182	67996350263	1985-01-15 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:51.795	2026-01-05 17:15:13.747	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199bec006z2mi0bu10sc9v	cmk199bea006x2mi06wm51646	04816100148	67999916831	1998-12-16 03:00:00	\N	ATIVO	\N	2026-01-05 14:27:54.229	2026-01-05 17:15:13.758	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199dkh007n2mi013blvxc9	cmk199dke007l2mi06agevfpo	39305171834	67995655256	1949-04-18 04:00:00	\N	ATIVO	\N	2026-01-05 14:27:57.041	2026-01-05 17:15:13.766	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199fyx008e2mi0fp972yif	cmk199fyv008c2mi0ju8vdrfv	04870482967	67982066707	1986-07-05 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:00.154	2026-01-05 17:15:13.774	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmkwhlrxt0002jo04qahubxge	cmkwhlrxg0000jo04zyhcyaqv	03544626101	67999427544	1990-12-23 00:00:00	\N	ATIVO	\N	2026-01-27 11:02:23.922	2026-01-27 11:02:23.922	cmk1f7oxd00022mj5ok901iru		365.00	FEMININO	\N	\N
cmk199jf8009h2mi0i5rphoxr	cmk199jf5009f2mi0jo23su1s	90786440104	67996850530	1982-05-28 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:04.628	2026-01-05 17:15:13.788	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199ljv00a52mi0kszrm603	cmk199lju00a32mi0g07ichyc	14316404172	67984245542	1954-01-15 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:07.388	2026-01-05 17:15:13.795	cmk1f7oxh00072mj5vitn09ou	\N	\N	\N	\N	\N
cmk199oj500b22mi0ymjfp899	cmk199oj300b02mi0wv32kfgj	40501710159	67999734846	1968-10-22 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:11.25	2026-01-05 17:15:13.805	cmk1f7oxe00032mj5rulkz0fu	\N	\N	\N	\N	\N
cmk199rqf00c22mi09zthn3to	cmk199rqd00c02mi0fb7pgxpb	07879619143	67999435665	2001-08-06 04:00:00	\N	ATIVO	\N	2026-01-05 14:28:15.4	2026-01-05 17:15:13.814	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk199twf00cq2mi0vlqg5i7z	cmk199twd00co2mi01df4al9d	05461082106	67996878512	1995-11-10 03:00:00	\N	ATIVO	\N	2026-01-05 14:28:18.207	2026-01-05 17:15:13.823	cmk1f7oxh00062mj5nk39ygd2	\N	\N	\N	\N	\N
cmk2kqanj00co2msaur8cwfez	cmk2kqang00cm2msaireep1aa	9998796126816	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:48.367	2026-01-06 12:36:48.367	\N	\N	\N	\N	\N	\N
cmk2kqawv00dz2msarz5blzno	cmk2kqawt00dx2msanqd5vcer	9993634138114	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:48.703	2026-01-06 12:36:48.703	\N	\N	\N	\N	\N	\N
cmk2kqeie00p62msabkj3x7j3	cmk2kqeic00p42msapxjlza7y	9994942871658	00000000000	1990-01-01 00:00:00	\N	ATIVO	\N	2026-01-06 12:36:53.366	2026-01-21 20:46:13.292	\N	\N	\N	\N	\N	\N
cmk2kqeaa00ov2msaw3hbi9vu	cmk2kqea800ot2msa5z3ni3jo	9993930343022	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:53.075	2026-01-06 12:36:53.075	\N	\N	\N	\N	\N	\N
cmk2kqfpm00t22msarhudewdw	cmk2kqfpj00t02msacqmwb9oh	9994194191242	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:54.922	2026-01-06 12:36:54.922	\N	\N	\N	\N	\N	\N
cmk2kqfxw00tf2msap1yqtfhk	cmk2kqfxt00td2msa7i4d98lf	9997019442509	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:55.22	2026-01-06 12:36:55.22	\N	\N	\N	\N	\N	\N
cmk2kqh2t00va2msayml7p5hq	cmk2kqh2q00v82msawoblalod	9999665814707	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:36:56.693	2026-01-06 12:36:56.693	\N	\N	\N	\N	\N	\N
cmkwo4i8f0002la04saafdb2c	cmkwo4i7x0000la04btmvx6wc	\N	67999734271	\N	\N	ATIVO	\N	2026-01-27 14:04:55.503	2026-01-28 13:24:29.886	cmk1f7oxh00062mj5nk39ygd2	\N	465.00	FEMININO	\N	\N
cmk2kql17014f2msa1vxjxmki	cmk2kql14014d2msaukami2ty	9996438595871	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:01.819	2026-01-06 12:37:01.819	\N	\N	\N	\N	\N	\N
cmk2kql9c014s2msaark27qrj	cmk2kql99014q2msa8a0l3e7a	9995622892603	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:02.112	2026-01-06 12:37:02.112	\N	\N	\N	\N	\N	\N
cmk2kqlpu01582msauiozwpwr	cmk2kqlps01562msa9dsy8xnz	9993305013643	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:02.707	2026-01-06 12:37:02.707	\N	\N	\N	\N	\N	\N
cmkb7amq600sx2mrmpwk39iog	cmkb7amol00sv2mrmghelaxfq	9991930968350	00000000000	1990-01-01 00:00:00	\N	ATIVO	\N	2026-01-12 13:30:38.094	2026-01-21 20:26:31.413	\N	\N	\N	\N	\N	\N
cmk2kqne101ae2msa676t786e	cmk2kqndy01ac2msaixkmci1q	9997597643583	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:04.873	2026-01-06 12:37:04.873	\N	\N	\N	\N	\N	\N
cmk2kqnnc01bp2msag0moziwl	cmk2kqnn801bn2msanuwlkbhk	9994582855420	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:05.209	2026-01-06 12:37:05.209	\N	\N	\N	\N	\N	\N
cmk2kqnvi01c02msabhc6542y	cmk2kqnvg01by2msa39sa18u6	9991232870971	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-06 12:37:05.503	2026-01-06 12:37:05.503	\N	\N	\N	\N	\N	\N
cmkb78nmz00le2mrmrxffixj2	cmkb78nlf00lc2mrmhzywhgk2	9992304693431	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:29:05.964	2026-01-12 13:29:05.964	\N	\N	\N	\N	\N	\N
cmkb7cm9n012d2mrmdxpg6lii	cmkb7cm7z012b2mrmtqlfww6b	9996090843917	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:32:10.811	2026-01-12 13:32:10.811	\N	\N	\N	\N	\N	\N
cmkb7cw5i013o2mrmzcc043sb	cmkb7cw3w013m2mrmfju4virw	9998221607994	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:32:23.622	2026-01-12 13:32:23.622	\N	\N	\N	\N	\N	\N
cmkb7f6vo01eq2mrm9dpu9p6e	cmkb7f6u101eo2mrmyto8ekce	9996084154195	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:34:10.837	2026-01-12 13:34:10.837	\N	\N	\N	\N	\N	\N
cmkb7hfs501pd2mrmm4vbozc3	cmkb7hfqi01pb2mrms6v08ewt	9996777892680	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:35:55.685	2026-01-12 13:35:55.685	\N	\N	\N	\N	\N	\N
cmkb7ih2l01ua2mrmj46s75bo	cmkb7ih0z01u82mrmnvf5u1ki	9994182817012	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:36:44.014	2026-01-12 13:36:44.014	\N	\N	\N	\N	\N	\N
cmkb7hpil01qo2mrmmzuankq4	cmkb7hph101qm2mrmye0ron1k	41851579087	67993443859	1947-03-19 00:00:00	\N	ATIVO	\N	2026-01-12 13:36:08.302	2026-01-21 20:44:14.954	cmk1f7oxj00092mj50f764fef		0.00	FEMININO	\N	\N
cmkb7kps9024n2mrmstf3c4nh	cmkb7kpoa024l2mrmf4825hot	9993051280442	00000000000	1990-01-01 00:00:00	\N	PENDENTE	\N	2026-01-12 13:38:28.617	2026-01-12 13:38:28.617	\N	\N	\N	\N	\N	\N
cmko19dm60002l4047rkhiv1r	cmko19dlk0000l404s4po7s6p	54376033120	67981481404	1972-07-26 00:00:00	\N	ATIVO	\N	2026-01-21 13:02:42.222	2026-01-23 13:54:16.755	cmk1f7ox800002mj59lsuuga4		265.00	FEMININO	cc5c17629997fd42b67eedbc8e7cdd9e743d0cb7241be8eee557a33396fff9f7	2026-01-24 13:54:16.754
cmk199k7z009q2mi0aihokjw4	cmk199k7x009o2mi0v9lxzo2b	91154677168	67999724358	1981-06-01 00:00:00	\N	ATIVO	\N	2026-01-05 14:28:05.663	2026-01-12 13:51:30.16	cmk1f7oxh00062mj5nk39ygd2		405.00	\N	\N	\N
cmk199998006b2mi02zwh4gr1	cmk19999600692mi0kb9tqs77	03584557151	67998342242	1993-06-02 00:00:00	\N	ATIVO	\N	2026-01-05 14:27:51.453	2026-01-12 15:12:41.546	cmk1f7oxd00022mj5ok901iru		\N	\N	\N	\N
cmkn4za5z0002lb04w6m98so4	cmkn4za550000lb0452pom903	71369015100	67998907746	1975-09-17 00:00:00	\N	ATIVO	\N	2026-01-20 21:59:03.479	2026-01-20 21:59:03.479	cmk1f7oxq000b2mj522r61kkb		465.00	FEMININO	\N	\N
cmklrze0n0002js04ruzp7pu0	cmklrzdzy0000js047yuavgu9	36718211168	67984035100	1971-06-08 00:00:00	\N	ATIVO	\N	2026-01-19 23:07:27.287	2026-01-19 23:07:27.287	cmk1f7oxd00022mj5ok901iru	500116	0.00	FEMININO	\N	\N
cmkls2mhk0005js04zp04zavx	cmkls2mh80003js04fie2j724	04858784100	67996744429	1992-09-25 00:00:00	\N	ATIVO	\N	2026-01-19 23:09:58.232	2026-01-19 23:09:58.232	cmk1f7oxd00022mj5ok901iru	001747910	0.00	FEMININO	\N	\N
\.


--
-- Data for Name: notificacoes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notificacoes (id, membro_id, tipo, titulo, mensagem, enviada, enviada_em, agendada_para, canal_whatsapp, canal_email, criado_em) FROM stdin;
\.


--
-- Data for Name: pagamentos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pagamentos (id, membro_id, plano_id, valor, data_vencimento, data_pagamento, status, forma_pagamento, comprovante, observacao, criado_em, atualizado_em) FROM stdin;
cmkb816lw00392mhg5tvencm8	cmk1993ou004k2mi0o0iyh8eu	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-10	2026-01-12 13:51:16.915	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:16.916	2026-01-12 13:51:16.916
cmkb817of003d2mhgrn9t506n	cmk199htt008z2mi0x6jn63l0	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-02-10	2026-01-12 13:51:18.303	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:18.304	2026-01-12 13:51:18.304
cmkb8188q003f2mhgoeemkxti	cmk198zf500382mi0jrnab4xv	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-02-10	2026-01-12 13:51:19.034	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:19.035	2026-01-12 13:51:19.035
cmkb819bh003j2mhg3kfewpzz	cmk1ezvuu00cw2mi0rui6xiaw	cmk1f7oxg00052mj5fvecfmq4	250.00	2026-02-10	2026-01-12 13:51:20.428	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:20.429	2026-01-12 13:51:20.429
cmkb81arv003p2mhgl2i5kqz6	cmk199ffw00882mi0kl7sg4ty	cmk1f7oxe00032mj5rulkz0fu	350.00	2026-02-10	2026-01-12 13:51:22.314	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:22.315	2026-01-12 13:51:22.315
cmkb81bxc003t2mhgykea831r	cmk1996by005e2mi0jcdco3ca	cmk1f7ox800002mj59lsuuga4	450.00	2026-02-10	2026-01-12 13:51:23.808	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:23.808	2026-01-12 13:51:23.808
cmkb81cju003v2mhg5zzc79pg	cmk1ezw3100cz2mi0mg127gqi	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-10	2026-01-12 13:51:24.618	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:24.618	2026-01-12 13:51:24.618
cmkb81ddv003x2mhgivim7q2y	cmk199q4v00bk2mi0k9cdjvj1	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-10	2026-01-12 13:51:25.699	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:25.7	2026-01-12 13:51:25.7
cmkb81dt7003z2mhgprt0wkvw	cmkb7cw5i013o2mrmzcc043sb	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-02-10	2026-01-12 13:51:26.25	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:26.251	2026-01-12 13:51:26.251
cmkb81e8k00412mhgqssqu9m9	cmkb7cm9n012d2mrmdxpg6lii	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-02-10	2026-01-12 13:51:26.804	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:26.804	2026-01-12 13:51:26.804
cmkb81es700432mhggyavb4ga	cmk19910c003q2mi020xyodij	cmk1f7oxe00032mj5rulkz0fu	365.00	2026-02-10	2026-01-12 13:51:27.51	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:27.511	2026-01-12 13:51:27.511
cmko1ysig0001la040wso0dll	cmko19dm60002l4047rkhiv1r	cmk1f7ox800002mj59lsuuga4	265.00	2026-02-10	\N	PENDENTE	PIX	\N	Pagamento agendado para terça-feira na primeira aula.	2026-01-21 13:22:27.924	2026-01-21 13:22:27.924
cmkwhr57x0006jo04d7qhh4l1	cmkwhlrxt0002jo04qahubxge	cmk1f7oxd00022mj5ok901iru	365.00	2026-02-27	2026-01-27 11:06:43.664	PAGO	PIX	\N	Pagamento feito às 07:05, 27 de janeiro	2026-01-27 11:06:34.41	2026-01-27 11:06:43.666
cmkb80emd00052mhgsxyep066	cmk198qxe000k2mi0yrn7b1l5	cmk1f7oxd00022mj5ok901iru	350.00	2026-02-10	2026-01-12 13:50:40.644	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:40.645	2026-01-12 13:50:40.645
cmkb80f6n00072mhg135ldb0f	cmk198xtz002q2mi0oynknikc	cmk1f7oxj00092mj50f764fef	350.00	2026-02-10	2026-01-12 13:50:41.375	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:41.376	2026-01-12 13:50:41.376
cmkb80g5a000b2mhgt0bacsvt	cmk1998q400652mi0j3oh8k8f	cmk1f7oxh00062mj5nk39ygd2	450.00	2026-02-10	2026-01-12 13:50:42.622	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:42.623	2026-01-12 13:50:42.623
cmkb80iks000l2mhgk52uduyb	cmk199icw00952mi0lsmpw8e3	cmk1f7oxe00032mj5rulkz0fu	350.00	2026-02-10	2026-01-12 13:50:45.771	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:45.772	2026-01-12 13:50:45.772
cmkb80j4x000n2mhg79qep8wp	cmk198pbt00022mi0uothgwyv	cmk1f7ox800002mj59lsuuga4	225.00	2026-02-10	2026-01-12 13:50:46.497	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:46.498	2026-01-12 13:50:46.498
cmkb80joh000p2mhgx16ylzz9	cmk1997el005q2mi02t6inz7d	cmk1f7oxe00032mj5rulkz0fu	315.00	2026-02-10	2026-01-12 13:50:47.2	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:47.201	2026-01-12 13:50:47.201
cmkb80kaz000r2mhggy5rhfl4	cmk1992d700452mi0rqrrtbi2	cmk1f7ox800002mj59lsuuga4	225.00	2026-02-10	2026-01-12 13:50:48.01	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:48.011	2026-01-12 13:50:48.011
cmkb80l7h000v2mhg5lvig9m6	cmk2kqanj00co2msaur8cwfez	cmk1f7oxg00052mj5fvecfmq4	200.00	2026-02-10	2026-01-12 13:50:49.18	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:49.181	2026-01-12 13:50:49.181
cmkb80lnz000x2mhgg0rw2e28	cmk2kqawv00dz2msarz5blzno	cmk1f7oxg00052mj5fvecfmq4	200.00	2026-02-10	2026-01-12 13:50:49.774	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:49.775	2026-01-12 13:50:49.775
cmkb80nl200152mhgbhwfgius	cmk199l0m009z2mi0o4jc5stf	cmk1f7oxd00022mj5ok901iru	350.00	2026-02-10	2026-01-12 13:50:52.261	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:52.262	2026-01-12 13:50:52.262
cmkb80ogm00192mhg8unfmuzi	cmk199bz100752mi0l1otqgsk	cmk1f7oxh00062mj5nk39ygd2	450.00	2026-02-10	2026-01-12 13:50:53.398	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:53.399	2026-01-12 13:50:53.399
cmkb80pzt001f2mhghdzswh83	cmk199du0007q2mi0n8lox17j	cmk1f7oxg00052mj5fvecfmq4	300.00	2026-02-10	2026-01-12 13:50:55.385	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:55.386	2026-01-12 13:50:55.386
cmkb80qfz001h2mhgozzao6d7	cmk19950f004z2mi0up36poxo	cmk1f7oxg00052mj5fvecfmq4	300.00	2026-02-10	2026-01-12 13:50:55.966	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:55.967	2026-01-12 13:50:55.967
cmkb80ruv001n2mhglc20spa9	cmk198x1i002h2mi0xm55s0kp	cmk1f7oxc00012mj5ojq5bean	600.00	2026-02-10	2026-01-12 13:50:57.799	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:57.8	2026-01-12 13:50:57.8
cmkb80sf0001p2mhg4gg46b5i	cmk1998zo00682mi0mjhxpnpw	cmk1f7oxc00012mj5ojq5bean	550.00	2026-02-10	2026-01-12 13:50:58.524	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:58.525	2026-01-12 13:50:58.525
cmkb80sz2001r2mhgfoiimnfj	cmk198v6k001w2mi02ivlhs3x	cmk1f7oxh00072mj5vitn09ou	550.00	2026-02-10	2026-01-12 13:50:59.245	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:50:59.246	2026-01-12 13:50:59.246
cmkb80tl9001t2mhgan314ubk	cmk199g8l008h2mi0oa3cch2x	cmk1f7oxh00062mj5nk39ygd2	450.00	2026-02-10	2026-01-12 13:51:00.044	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:00.045	2026-01-12 13:51:00.045
cmkb80u5h001v2mhg7x2rsor6	cmk199twf00cq2mi0vlqg5i7z	cmk1f7oxh00062mj5nk39ygd2	405.00	2026-02-10	2026-01-12 13:51:00.769	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:00.774	2026-01-12 13:51:00.774
cmkb80urz001x2mhgwlptwacq	cmk198wig002b2mi06vqg92nm	cmk1f7oxh00062mj5nk39ygd2	405.00	2026-02-10	2026-01-12 13:51:01.583	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:01.583	2026-01-12 13:51:01.583
cmkb80v7e001z2mhgqxz3djp1	cmk2kqeaa00ov2msaw3hbi9vu	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-10	2026-01-12 13:51:02.137	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:02.138	2026-01-12 13:51:02.138
cmkb80w3r00232mhg7tp4wxt8	cmk199jf8009h2mi0i5rphoxr	cmk1f7oxh00062mj5nk39ygd2	450.00	2026-02-10	2026-01-12 13:51:03.302	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:03.303	2026-01-12 13:51:03.303
cmkb80x0a00272mhgvqhyuil1	cmk2kqfpm00t22msarhudewdw	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-04	2026-01-12 13:51:04.473	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:04.474	2026-01-12 13:51:04.474
cmkb80xg200292mhgw88jk2br	cmk2kqfxw00tf2msap1yqtfhk	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-02-04	2026-01-12 13:51:05.041	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:05.042	2026-01-12 13:51:05.042
cmkb813m0002x2mhgtu8c0wxg	cmk198u4a001k2mi0ca568vue	cmk1f7oxd00022mj5ok901iru	315.00	2026-02-10	2026-01-12 13:51:13.031	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:13.032	2026-01-12 13:51:13.032
cmkb8146f002z2mhg9gwmojza	cmk199sb700c82mi0f6kviwjw	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-02-03	2026-01-12 13:51:13.766	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:13.767	2026-01-12 13:51:13.767
cmkb815iq00352mhgzlt49sbr	cmk2kqne101ae2msa676t786e	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-02-03	2026-01-12 13:51:15.506	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:15.507	2026-01-12 13:51:15.507
cmkb8161h00372mhg2i10mhw3	cmk2kqnnc01bp2msag0moziwl	cmk1f7oxg00052mj5fvecfmq4	250.00	2026-02-03	2026-01-12 13:51:16.18	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:16.181	2026-01-12 13:51:16.181
cmkb80e780001jo043klfrap9	cmk199qxt00bt2mi0r95b680e	cmk1f7oxd00022mj5ok901iru	350.00	2026-02-12	2026-01-12 13:52:35.228	PAGO	PIX	\N	...	2026-01-12 13:50:40.07	2026-01-12 13:52:35.23
cmkpfc5ty00002mcec6h7czc5	cmk2kqnnc01bp2msag0moziwl	cmk1f7oxe00032mj5rulkz0fu	350.00	2026-01-06	2026-01-06 16:12:16.239	PAGO	TRANSFERENCIA	\N	...	2026-01-06 16:12:09.31	2026-01-22 12:24:32.902
cmkpfc5tz00012mce94d6hl3c	cmk198qxe000k2mi0yrn7b1l5	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:33.615	2026-01-22 12:24:32.902
cmkpfc5tz00022mce2waxiqcp	cmk198xtz002q2mi0oynknikc	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:33.697	2026-01-22 12:24:32.902
cmkpfc5tz00032mcern174kbu	cmk199e3m007t2mi0ixoer361	cmk1f7oxg00052mj5fvecfmq4	465.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:33.726	2026-01-22 12:24:32.902
cmkpfc5tz00042mcexpr3jwso	cmk1998q400652mi0j3oh8k8f	cmk1f7oxg00052mj5fvecfmq4	450.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:33.752	2026-01-22 12:24:32.902
cmkpfc5tz00052mce48quzb09	cmk199icw00952mi0lsmpw8e3	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.037	2026-01-22 12:24:32.902
cmkpfc5tz00062mcexsfjkmww	cmk1997el005q2mi02t6inz7d	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.081	2026-01-22 12:24:32.902
cmkpfc5tz00072mceucqdejn6	cmk1992d700452mi0rqrrtbi2	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.117	2026-01-22 12:24:32.902
cmkpfc5tz00082mcex2ir663u	cmk2kqanj00co2msaur8cwfez	cmk1f7oxg00052mj5fvecfmq4	200.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.228	2026-01-22 12:24:32.902
cmkpfc5tz00092mce8fhxuu7j	cmk2kqawv00dz2msarz5blzno	cmk1f7oxg00052mj5fvecfmq4	200.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.276	2026-01-22 12:24:32.902
cmkpfc5tz000a2mce17pxtwr7	cmk199l0m009z2mi0o4jc5stf	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.496	2026-01-22 12:24:32.902
cmkpfc5tz000b2mce82h5b0tm	cmk199bz100752mi0l1otqgsk	cmk1f7oxg00052mj5fvecfmq4	450.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.593	2026-01-22 12:24:32.902
cmkpfc5tz000c2mceefioyr6k	cmk199du0007q2mi0n8lox17j	cmk1f7oxg00052mj5fvecfmq4	300.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.684	2026-01-22 12:24:32.902
cmkpfc5tz000d2mcequ5ot55f	cmk19950f004z2mi0up36poxo	cmk1f7oxg00052mj5fvecfmq4	300.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.719	2026-01-22 12:24:32.902
cmkpfc5tz000e2mce3jqsgi8y	cmk198x1i002h2mi0xm55s0kp	cmk1f7oxg00052mj5fvecfmq4	600.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.881	2026-01-22 12:24:32.902
cmkpfc5tz000f2mcehk5qmxml	cmk1998zo00682mi0mjhxpnpw	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.952	2026-01-22 12:24:32.902
cmkpfc5tz000g2mce23g4ynru	cmk198v6k001w2mi02ivlhs3x	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:34.985	2026-01-22 12:24:32.902
cmkpfc5tz000h2mce8ott06p1	cmk199g8l008h2mi0oa3cch2x	cmk1f7oxg00052mj5fvecfmq4	450.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.184	2026-01-22 12:24:32.902
cmkpfc5tz000i2mcetm31avfv	cmk199twf00cq2mi0vlqg5i7z	cmk1f7oxg00052mj5fvecfmq4	405.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.213	2026-01-22 12:24:32.902
cmkpfc5tz000j2mcegcdl6dj8	cmk198wig002b2mi06vqg92nm	cmk1f7oxg00052mj5fvecfmq4	405.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.246	2026-01-22 12:24:32.902
cmkpfc5tz000k2mcedzi2dtmw	cmk2kqeaa00ov2msaw3hbi9vu	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.278	2026-01-22 12:24:32.902
cmkpfc5tz000l2mcen47xg3nt	cmk199jf8009h2mi0i5rphoxr	cmk1f7oxg00052mj5fvecfmq4	450.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.504	2026-01-22 12:24:32.902
cmkpfc5tz000m2mce7i5vh4f4	cmk2kqfpm00t22msarhudewdw	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.562	2026-01-22 12:24:32.902
cmkpfc5tz000n2mcea4ssxqli	cmk2kqfxw00tf2msap1yqtfhk	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.58	2026-01-22 12:24:32.902
cmkpfc5tz000o2mceh5w2t87s	cmk199i3b00922mi0b9qug5km	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:35.655	2026-01-22 12:24:32.902
cmkpfc5tz000p2mceddueac6x	cmk199han008t2mi0gavokllh	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.298	2026-01-22 12:24:32.902
cmkpfc5tz000q2mcei5sga3hu	cmk199osp00b52mi07yc89x8b	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.519	2026-01-22 12:24:32.902
cmkpfc5tz000r2mce8uab17g8	cmk198u4a001k2mi0ca568vue	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.607	2026-01-22 12:24:32.902
cmkb811kd002p2mhg2zg7ngsz	cmk199han008t2mi0gavokllh	cmk1f7oxd00022mj5ok901iru	315.00	2026-02-05	2026-01-12 13:51:10.381	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:10.381	2026-01-12 13:51:10.381
cmkb812jv002t2mhgagqqlad8	cmk199osp00b52mi07yc89x8b	cmk1f7oxg00052mj5fvecfmq4	315.00	2026-02-06	2026-01-12 13:51:11.658	PAGO	\N	\N	Importado de lista.md - Janeiro 2026	2026-01-12 13:51:11.659	2026-01-12 13:51:11.659
cmkpfc5tz000s2mcetic19zjo	cmk199sb700c82mi0f6kviwjw	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.683	2026-01-22 12:24:32.902
cmkpfc5tz000t2mcekzvmpfz2	cmk2kqne101ae2msa676t786e	cmk1f7oxg00052mj5fvecfmq4	550.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.855	2026-01-22 12:24:32.902
cmkpfc5tz000u2mce5gx3xlbc	cmk1993ou004k2mi0o0iyh8eu	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.896	2026-01-22 12:24:32.902
cmkpfc5tz000v2mceppeytbko	cmk199htt008z2mi0x6jn63l0	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.943	2026-01-22 12:24:32.902
cmkpfc5tz000w2mceadmmlitl	cmk198zf500382mi0jrnab4xv	cmk1f7oxg00052mj5fvecfmq4	225.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.965	2026-01-22 12:24:32.902
cmkpfc5tz000x2mcegz4cvxks	cmk1ezvuu00cw2mi0rui6xiaw	cmk1f7oxg00052mj5fvecfmq4	250.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:36.997	2026-01-22 12:24:32.902
cmkpfc5tz000y2mce2ydp3cqu	cmk1996by005e2mi0jcdco3ca	cmk1f7oxg00052mj5fvecfmq4	450.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:37.121	2026-01-22 12:24:32.902
cmkpfc5tz000z2mce5vu5jowy	cmk198unf001q2mi0mwzfdm8t	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:37.145	2026-01-22 12:24:32.902
cmkpfc5u000102mce2gkxpuiw	cmk199q4v00bk2mi0k9cdjvj1	cmk1f7oxg00052mj5fvecfmq4	350.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:37.169	2026-01-22 12:24:32.902
cmkpfc5u000112mcega5bvnlj	cmk19910c003q2mi020xyodij	cmk1f7oxg00052mj5fvecfmq4	365.00	2026-01-10	\N	PENDENTE	\N	\N	Mensalidade Janeiro 2026	2026-01-12 12:41:37.294	2026-01-22 12:24:32.902
cmkpfc5u000122mcekcc6bupk	cmk198rzq000w2mi0zho10guw	cmk1f7oxh00062mj5nk39ygd2	385.00	2026-02-10	2026-01-21 12:06:10.056	PAGO	DINHEIRO	\N	Pagamento em dinheiro às 8h do dia 21 de janeiro, recebido por Augusto.	2026-01-21 11:56:52.24	2026-01-22 12:24:32.902
cmky1d3d00001kz0414qoo59x	cmkwo4i8f0002la04saafdb2c	cmk1f7oxh00062mj5nk39ygd2	465.00	2026-02-28	\N	PENDENTE	PIX	\N	...	2026-01-28 13:03:17.28	2026-01-28 13:03:17.28
\.


--
-- Data for Name: planos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planos (id, nome, descricao, valor, duracao_dias, aulas_semanais, ativo, criado_em, atualizado_em) FROM stdin;
cmk1f7oxq000b2mj522r61kkb	4x/semana - Estagiários	Quatro vezes por semana, guiado pelos estagiários.	450.00	30	4	t	2026-01-05 17:14:36.159	2026-01-05 17:28:15.901
cmk1f7ox800002mj59lsuuga4	2x/semana - Estagiários	Duas vezes por semana, guiado pelos estagiários.	250.00	30	2	t	2026-01-05 17:14:36.141	2026-01-05 17:28:15.88
cmk1f7oxc00012mj5ojq5bean	4x/semana - Gabi	Quatro vezes por semana, guiado por Gabi.	550.00	30	4	t	2026-01-05 17:14:36.144	2026-01-05 17:28:15.89
cmk1f7oxd00022mj5ok901iru	3x/semana - Estagiários	Três vezes por semana, guiado pelos estagiários.	350.00	30	3	t	2026-01-05 17:14:36.146	2026-01-05 17:28:15.892
cmk1f7oxe00032mj5rulkz0fu	2x/semana - Gabi	Duas vezes por semana, guiado por Gabi.	350.00	30	2	t	2026-01-05 17:14:36.147	2026-01-05 17:28:15.894
cmk1f7oxf00042mj5uq7afrs4	1x/semana - Gabi	Uma vez por semana, guiado por Gabi.	160.00	30	1	t	2026-01-05 17:14:36.147	2026-01-05 17:28:15.895
cmk1f7oxg00052mj5fvecfmq4	5x/semana - Exclusivo Estagiários	Cinco vezes por semana com atendimento exclusivo pelos estagiários.	650.00	30	5	t	2026-01-05 17:14:36.148	2026-01-05 17:28:15.896
cmk1f7oxh00062mj5nk39ygd2	3x/semana - Gabi	Três vezes por semana, guiado por Gabi.	450.00	30	3	t	2026-01-05 17:14:36.149	2026-01-05 17:28:15.897
cmk1f7oxh00072mj5vitn09ou	Personal 3x/semana - Gabi	Três vezes por semana com atendimento personalizado da Gabi.	550.00	30	3	t	2026-01-05 17:14:36.15	2026-01-05 17:28:15.897
cmk1f7oxi00082mj54d8lbst3	5x/semana - Estagiários	Cinco vezes por semana, guiado pelos estagiários.	550.00	30	5	t	2026-01-05 17:14:36.15	2026-01-05 17:28:15.898
cmk1f7oxj00092mj50f764fef	Plano Família	Plano especial para famílias treinarem juntas.	200.00	30	3	t	2026-01-05 17:14:36.151	2026-01-05 17:28:15.899
cmk1f7oxq000a2mj5q21b3ugp	5x/semana - Gabi	Cinco vezes por semana, guiado por Gabi.	585.00	30	5	t	2026-01-05 17:14:36.158	2026-01-05 17:28:15.9
\.


--
-- Data for Name: treinos_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treinos_template (id, nome, objetivo, observacoes, criado_em, atualizado_em) FROM stdin;
\.


--
-- Data for Name: treinos_template_exercicios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.treinos_template_exercicios (id, template_id, sessao, nome, grupo_muscular, series, repeticoes, descanso, observacoes, ordem, criado_em, atualizado_em) FROM stdin;
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.usuarios (id, email, senha, nome, role, criado_em, atualizado_em, email_verificado, etapa_onboarding, onboarding_completo, token_reset, token_reset_expira, token_verificacao, token_verificacao_expira, senha_definida) FROM stdin;
cmk198pbp00002mi0p331wbza	alexandreassouza@yahoo.com.br	$2b$12$wNY1iiO2HlqmMEJwoTJiheGKDTjmD/5nx3EX8ERPAvciOFLkUgpBy	ALEXANDRE ANTONIO SANTOS DE SOUZA	MEMBRO	2026-01-05 14:27:25.621	2026-01-05 14:27:25.621	\N	1	f	\N	\N	\N	\N	f
cmk198plf00032mi0s79vyr6w	anaf_csilva@hotmail.com	$2b$12$RIRxSirj2jH7oc73EG573eGILmcum4jmxAEg3cF/1fh2v1g3Qrfym	ANA FLÁVIA CARDOSO DA SILVA MEAZZA	MEMBRO	2026-01-05 14:27:25.971	2026-01-05 14:27:25.971	\N	1	f	\N	\N	\N	\N	f
cmk198qnt000f2mi03n5p5l7w	adri_giuliani@hotmail.com	$2b$12$cV25LybOIa4mkh.00YQfcORiZyD1b72H37t6N1Bq3.4h.43csc4QK	Adriana Giuliani Buosi	MEMBRO	2026-01-05 14:27:27.353	2026-01-05 14:27:27.353	\N	1	f	\N	\N	\N	\N	f
cmk198qxc000i2mi04jtafxdy	alc_cardoso@hotmail.com	$2b$12$Md8f7BaMmY1/rEjXsFefXODXhsEzRJvziT67EDatT4h65YoMrHzbu	Alcimara Ferreira Cardoso	MEMBRO	2026-01-05 14:27:27.697	2026-01-05 14:27:27.697	\N	1	f	\N	\N	\N	\N	f
cmk198rgg000o2mi0cam23k7n	Aline_avila93@hotmail.com	$2b$12$y8oGUc7JS5p8rrRpRN4AVOfByD6QXTdV7EEWR3U4sELmD/viKkII2	Aline Madruga de Avila	MEMBRO	2026-01-05 14:27:28.385	2026-01-05 14:27:28.385	\N	1	f	\N	\N	\N	\N	f
cmk198rzn000u2mi0l50tldta	anapaula_biazoto@hotmail.com	$2b$12$YgLp3/Mw3USYsESbG2fWxuC81ekVpl55a4/spzZb0fXdzojNsCNXi	Ana Paula Biazoto Matos	MEMBRO	2026-01-05 14:27:29.076	2026-01-05 14:27:29.076	\N	1	f	\N	\N	\N	\N	f
cmk198s99000x2mi0r7gfbpx0	anapaulacontadorarb@hotmail.com	$2b$12$5XWwW.QOsPCAhBbyXif5mujZIgdbgC07.WSzjb5.UPwlVPswLDtRK	Ana Paula de Souza Santos	MEMBRO	2026-01-05 14:27:29.421	2026-01-05 14:27:29.421	\N	1	f	\N	\N	\N	\N	f
cmk198q4l00092mi08fzl7up0	reginamurer@hotmail.com	$2b$12$O8ymR3/ucO0GzUqpg3rGye49xIHaDrSAei1RwcTKaLiXrUAA90xxa	Adalgisa Regina Ramos Ceolin	MEMBRO	2026-01-05 14:27:26.661	2026-01-22 13:27:47.54	\N	1	f	\N	\N	\N	\N	f
cmk198ssd00132mi00mwvymrw	Asvincensi@gmail.com	$2b$12$tNzFU1Zto4WpGI61HrOR8uqLhMKZRxVGiHwi60UPp.QzGDHJBW0g.	Andreia Vincensi	MEMBRO	2026-01-05 14:27:30.11	2026-01-05 14:27:30.11	\N	1	f	\N	\N	\N	\N	f
cmk198t1y00162mi0hcojyy7i	andrericardoschwingel@gmail.com	$2b$12$epZWgYHQbI8IEwqUwZtfw.IbkFVrxILrytyAelhrmlWwwGrXTAlRO	André Ricardo Schwingel	MEMBRO	2026-01-05 14:27:30.454	2026-01-05 14:27:30.454	\N	1	f	\N	\N	\N	\N	f
cmk198tbh00192mi03y00rh1r	sobreirabarbosa@hotmail.com	$2b$12$qn2MVotEdasUsVnUblPg3OPBbKS5SpKqhNZvG6AFlxjdIP6VKsa3O	André Sobreira Barbosa	MEMBRO	2026-01-05 14:27:30.798	2026-01-05 14:27:30.798	\N	1	f	\N	\N	\N	\N	f
cmk14m3l500006bg0655vofq6	admin@gabistudio.com.br	$2b$12$Pi92fZmp5qe1Djnxr5AnM.H/lgcHb1gxSDxL1/fu0nl6XNpC3ClbC	Administrador	ADMIN	2026-01-05 12:17:52.553	2026-01-05 12:17:52.553	\N	1	f	\N	\N	\N	\N	t
cmk198tup001f2mi01zz2sj0u	biancadalcin1@gmail.com	$2b$12$pcdw9HUq7amSO.UCscdmbuBy/VsV382SEpuuVjBrsMuYDBCyynfqK	BIANCA DALCIN STIEVEN LOURENÇO	MEMBRO	2026-01-05 14:27:31.489	2026-01-05 14:27:31.489	\N	1	f	\N	\N	\N	\N	f
cmk198u48001i2mi0nzwlwkmg	engmecagostini@gmail.com	$2b$12$HEDfKiTqESx2qGqK2w4ww.bwzNEhtuLXeSXUbgSFrNCd0mz9I.oPK	Bruna Agostini de Paiva	MEMBRO	2026-01-05 14:27:31.833	2026-01-05 14:27:31.833	\N	1	f	\N	\N	\N	\N	f
cmk198uds001l2mi0ywai9qty	catarina_giuliani@yahoo.com.br	$2b$12$K/V2n2tIK4UKl2//hVqfd.jhkhwTPFO/knUkJugTix4R56/s0bc0i	CATARINA GIULIANI VINCENSI	MEMBRO	2026-01-05 14:27:32.176	2026-01-05 14:27:32.176	\N	1	f	\N	\N	\N	\N	f
cmk198und001o2mi0oh2gezmf	Camila.ceolin@hotmail.com	$2b$12$NVP.Vs0DQU8gAw6NHJTs0eutcFT.HyFGEZIWIsuHQ.eqWRv5OKWCS	Camila Garcia Ceolin	MEMBRO	2026-01-05 14:27:32.521	2026-01-05 14:27:32.521	\N	1	f	\N	\N	\N	\N	f
cmk198v6h001u2mi04sn2a5v2	carla_fal1@hotmail.com	$2b$12$qkR9zl27q92YwaEuIMWl5.E6y96cW3MEBb9l9VbtzQ.M4/2DFYCgu	Carla Dilene Fernandes Almeida Lima	MEMBRO	2026-01-05 14:27:33.21	2026-01-05 14:27:33.21	\N	1	f	\N	\N	\N	\N	f
cmk198vg6001x2mi0hqy6rax2	carlifernandes43@gmail.com	$2b$12$kJ.ALzaoF0XxkGq1Qg0iFeifBYJQRE7Skwfj5PqLeOP9ekhDBBJT6	Carlieli Fernandes Romão Bastos	MEMBRO	2026-01-05 14:27:33.559	2026-01-05 14:27:33.559	\N	1	f	\N	\N	\N	\N	f
cmk198vpq00202mi0hvjkbdvh	ceduardo_soares@outlook.com	$2b$12$CHji6akdXuDy4cvG01hUB.i9PVE03g0uX9cbA/RoYuMGGTkmLNVjW	Carlos Eduardo Araujo Soares	MEMBRO	2026-01-05 14:27:33.902	2026-01-05 14:27:33.902	\N	1	f	\N	\N	\N	\N	f
cmk198vz900232mi0gu6vbfge	carlyanicampos@gmail.com	$2b$12$VnhYGXSlCr5NHjeW4XacUOuir55W2MdPBWEo3pssIWb5MM9I2Uajm	Carlyani Fernandes Romão Campos	MEMBRO	2026-01-05 14:27:34.246	2026-01-05 14:27:34.246	\N	1	f	\N	\N	\N	\N	f
cmk198w8u00262mi09bb39uo4	cleo.lima.dias@hotmail.com	$2b$12$WY7LVx4JfB4W9lIEheYzsOHb/H6DkjB5/8HPOBmT5JBOZCLZE68Vm	Cleonilda Dias de Lima Cereda	MEMBRO	2026-01-05 14:27:34.59	2026-01-05 14:27:34.59	\N	1	f	\N	\N	\N	\N	f
cmk198wie00292mi072vbm1ur	cristian_gelain@hotmail.com	$2b$12$lZn3PBC2Q7SOPbcIDCHCcebtUguKK46gT8H/L15Djc2.Jgf4wuwBO	Cristian Gelain do Nascimento	MEMBRO	2026-01-05 14:27:34.935	2026-01-05 14:27:34.935	\N	1	f	\N	\N	\N	\N	f
cmk198wrx002c2mi06yc6floh	chrrisskunz@yhoo.com.br	$2b$12$/wnYQoV6mO6tTqBV/wUTsOim5sN3UQ18EPdF59fJgWkuPGPFa2ZKG	Cristiane Elis Kunz	MEMBRO	2026-01-05 14:27:35.277	2026-01-05 14:27:35.277	\N	1	f	\N	\N	\N	\N	f
cmk198x1g002f2mi0qnk0qphx	schwengberdanielle@gmail.com	$2b$12$CzQf/4coKLZGz1C7l73XQeZqPPv2Gpq6c05QP7z7W.EBUDKOSb3iu	DANIELLE SCHWENGBER	MEMBRO	2026-01-05 14:27:35.621	2026-01-05 14:27:35.621	\N	1	f	\N	\N	\N	\N	f
cmk198xay002i2mi0ks5nqmcm	Danielijusto@hotmail.com	$2b$12$fHq8WJ8xRMConqC1xrXQmucFylQVcYdpxaO7M4fQtoaT2PtdHeF6m	Danieli da Silva Justo	MEMBRO	2026-01-05 14:27:35.963	2026-01-05 14:27:35.963	\N	1	f	\N	\N	\N	\N	f
cmk198xkh002l2mi0v92rd3pt	dani_tambosi@hotmail.com	$2b$12$YpUaE78Ywm5vxg2f85mqZer92zSoRkICsKNwiSEK8BUXPHI/UECPO	Danielli Neves Tambosi	MEMBRO	2026-01-05 14:27:36.305	2026-01-05 14:27:36.305	\N	1	f	\N	\N	\N	\N	f
cmk198xtx002o2mi0d6iu4fgr	silva.munizz@bol.com	$2b$12$.z/UIBR9kFJZFApT3lZL9.M4N1/TpsY76fy.Bi.5CJtp7.VSgEEBW	Davi da Silva Muniz	MEMBRO	2026-01-05 14:27:36.646	2026-01-05 14:27:36.646	\N	1	f	\N	\N	\N	\N	f
cmk198y3h002r2mi03zm8z3qp	Diego.agro.ufv@gmail.com	$2b$12$WTeV18hQ8iXSo23jdauB6O5zpbJKrx2.FUKBF13CGaslriHM.fU6m	Diego Oliveira	MEMBRO	2026-01-05 14:27:36.989	2026-01-05 14:27:36.989	\N	1	f	\N	\N	\N	\N	f
cmk198yd0002u2mi0nyzyayer	diegopiresdomingues@gmail.com	$2b$12$7LJKVgCSYNWJ7ofhV9wkgO7rsYDBfcv3.rixrVUHeHhJePTbQQabi	Diego Pires Domingues	MEMBRO	2026-01-05 14:27:37.333	2026-01-05 14:27:37.333	\N	1	f	\N	\N	\N	\N	f
cmk198ymi002x2mi0ckjoakw3	dinalva.cavalcante@hotmail.com	$2b$12$n.w5evZV6p/1v5k5DDWJtuaWe/vc/KzCZM1o4uf4l6QvNHanmykHy	Dinalva Bezerra Cavalcante	MEMBRO	2026-01-05 14:27:37.675	2026-01-05 14:27:37.675	\N	1	f	\N	\N	\N	\N	f
cmk198yw300302mi05lbtak7b	eldabragaxandu@gmail.com	$2b$12$S3F5UDtVEmJ3L64oiiFj.uk47JPlN4lMpXO11RlyKGkB51Y58/DrO	Elda A A Xandu	MEMBRO	2026-01-05 14:27:38.02	2026-01-05 14:27:38.02	\N	1	f	\N	\N	\N	\N	f
cmk198z5l00332mi0i5gx8ig2	eliane.marques18@hotmail.com	$2b$12$uRQbuVp78jvxXMAgINlySOlbiXSLK573DtWRnKQ6pKsHlLkkM9dQa	Eliane Marques da Silva Neves	MEMBRO	2026-01-05 14:27:38.362	2026-01-05 14:27:38.362	\N	1	f	\N	\N	\N	\N	f
cmk198zf300362mi0ifzkx623	eliezerrocha@hotmail.com	$2b$12$k8cZMBJSogN7pRvAARPpqu4Cbq4ncczndUMyel2bMP8cIQTER6pSK	Eliezer Bianchi Rocha	MEMBRO	2026-01-05 14:27:38.703	2026-01-05 14:27:38.703	\N	1	f	\N	\N	\N	\N	f
cmk198zom00392mi00dool0pw	elisangelaadao@hotmail.com	$2b$12$ZiOQjdh.4nlfDoUGLftAU.nLNvD4273KJeYXLathKEwnAVdl0i9NS	Elisangela Araujo Adão Ferreira	MEMBRO	2026-01-05 14:27:39.047	2026-01-05 14:27:39.047	\N	1	f	\N	\N	\N	\N	f
cmk198zy5003c2mi0zk3nw6y4	elizandraluzia13@gmil.com	$2b$12$XmpTwi7jhRFxmQLH2aT5rOEjSKVRJ/up3GRG3ZJWtKG7GjcNk1E1S	Elizandra Luzia Andrade Soares Guilherme	MEMBRO	2026-01-05 14:27:39.389	2026-01-05 14:27:39.389	\N	1	f	\N	\N	\N	\N	f
cmkwhlrxg0000jo04zyhcyaqv	vanessambremm@gmail.com	$2b$12$MrSZt8cKcURa.Zjn/CnCneFB4mwDFvPjfdfWvCviqR8TWKE13phsK	Vanessa Maria Bremm	MEMBRO	2026-01-27 11:02:23.908	2026-01-27 11:02:23.908	\N	4	t	\N	\N	\N	\N	f
cmk19907o003f2mi0lnpkfc9r	evbeal@icloud.com	$2b$12$fWm0AxIVkqFSmXm17XTmM.uWRFmIB9TiU0g1B0FqyboOILopy6BHS	Evone Bezerra Alves	MEMBRO	2026-01-05 14:27:39.732	2026-01-05 14:27:39.732	\N	1	f	\N	\N	\N	\N	f
cmk1990h7003i2mi0wdc0k4zv	fabiola_goncalez@hotmail.com	$2b$12$PIPFIRt2PC/77lfaCfKu9eoyRhKy/X/lPQlcFV/NWD1xUHwz8qdc6	Fabíola dos Santos Gonçalez	MEMBRO	2026-01-05 14:27:40.075	2026-01-05 14:27:40.075	\N	1	f	\N	\N	\N	\N	f
cmk1990qr003l2mi05ihqr8b4	Felicianarb@hotmail.com	$2b$12$XFSix5LQNM3mbIWt4dcofuwET4B/UD.V50OfYtXmBXfIfgLYfidZW	Feliciana Pereira Rodrigues	MEMBRO	2026-01-05 14:27:40.42	2026-01-05 14:27:40.42	\N	1	f	\N	\N	\N	\N	f
cmk19910a003o2mi0x4in8vkv	fergelain@hotmail.com	$2b$12$KInut7rY7g9KhGzpvXHRr.RI7NLxqhstQhjVhOtxpDrEpKMrtw6Q6	Fernanda Caroline Gelain	MEMBRO	2026-01-05 14:27:40.762	2026-01-05 14:27:40.762	\N	1	f	\N	\N	\N	\N	f
cmk19919t003r2mi093qbf3lh	fernandoriosul@hotmail.com	$2b$12$rvvH9yMwQK9xha69F9Ci6eXbC0rpMyXQQYP42zIqrbDLfWqKD1.Sq	Fernando Balestrin	MEMBRO	2026-01-05 14:27:41.106	2026-01-05 14:27:41.106	\N	1	f	\N	\N	\N	\N	f
cmk1991jc003u2mi0x43k03da	flasilveira1982@gmail.com	$2b$12$pyoYZutAJvPOz4t25WVbOOJTQYxgl/7yr9EobQHycPern383T46vO	Flávia Godoy Moraes Silveira	MEMBRO	2026-01-05 14:27:41.448	2026-01-05 14:27:41.448	\N	1	f	\N	\N	\N	\N	f
cmk1991u4003x2mi0lzrvuoyj	flaviallhy@hotmail.com	$2b$12$.ZRgfKew3JNx.feNwZ/8EeHiP95iTirY4E6w45Qr0m.FUBzr..Y6y	Flávia Rodrigues de Oliveira	MEMBRO	2026-01-05 14:27:41.837	2026-01-05 14:27:41.837	\N	1	f	\N	\N	\N	\N	f
cmk19923o00402mi04jhhoukb	Francilene.marim@gmail.com	$2b$12$mA67bzBAZOt8f/zT9aoJA.FOvTV1n0yG2Jkoom.MvtkhVYk75gFWS	Francilene daiana portillo marim	MEMBRO	2026-01-05 14:27:42.18	2026-01-05 14:27:42.18	\N	1	f	\N	\N	\N	\N	f
cmk1992d600432mi0a12mvzsm	giovanablume@gmail.com	$2b$12$v5bXDUPn/OTmsPGrGpzR2uD7su1ekQzbyHQ79ghTaSu5m1Rxm/pyS	GIOVANA BLUME DE SOUZA	MEMBRO	2026-01-05 14:27:42.523	2026-01-05 14:27:42.523	\N	1	f	\N	\N	\N	\N	f
cmk1992mo00462mi085sp83y0	ragagningabriela@gmail.com	$2b$12$aksCd5B6Oz9BLFACSW.1aOhrTsAT3sj8aSDYkBNWKc7ZBxs0MUjaW	Gabriela Ragagnin	MEMBRO	2026-01-05 14:27:42.864	2026-01-05 14:27:42.864	\N	1	f	\N	\N	\N	\N	f
cmk1992w700492mi03gxe37jd	Geni_strey@hotmail.com	$2b$12$FTQLlmJFsX9Ffx0RlPdcbu5LwevEg21MQOoIsD2DH07fUQfZuP1Yy	Geni strey	MEMBRO	2026-01-05 14:27:43.207	2026-01-05 14:27:43.207	\N	1	f	\N	\N	\N	\N	f
cmk19935o004c2mi0w4dliofv	glaumed26@hotmail.com	$2b$12$lSWHS3AMSTXXPxSBNiv/c.lJou8DKyDzxuWLU3uLqvCurlm6R2oKW	Glaucia Ricci Tolomei	MEMBRO	2026-01-05 14:27:43.549	2026-01-05 14:27:43.549	\N	1	f	\N	\N	\N	\N	f
cmk1993f7004f2mi0sj3w9sny	guilhermealveslopes@outlook.com	$2b$12$QJ/VcM2DwvRNFJtE8WZjROXcbIv8Ak49uTyekIdmr8HTImR2NHA/C	Guilherme Alves Lopes	MEMBRO	2026-01-05 14:27:43.892	2026-01-05 14:27:43.892	\N	1	f	\N	\N	\N	\N	f
cmk1993or004i2mi0v92jzh8y	ilie_vn@hotmail.com	$2b$12$YgkfF5WNHHICzZFpZ1tQNeSbPKx5VZrq2beXdgu4NCqxyGyvebEhm	Iliê Vidal Basso	MEMBRO	2026-01-05 14:27:44.236	2026-01-05 14:27:44.236	\N	1	f	\N	\N	\N	\N	f
cmk19947t004o2mi0ohnm24nq	isa_12cf@hotmail.com	$2b$12$YrA2DZo7SI0QQpOYQDxg4O4hAFywyDh0yDqdJuQfaUas06wKE/jSa	Isabela de Carvalho Fernandes	MEMBRO	2026-01-05 14:27:44.921	2026-01-05 14:27:44.921	\N	1	f	\N	\N	\N	\N	f
cmk1994hd004r2mi0f835pusx	isabella_fernandes3@hotmail.com	$2b$12$UjA6NdhhJAbNWXQwSWUFOOw/qR0UBCOygdymfovcdbKkdohXCeuSq	Isabella Carneiro Fernandes	MEMBRO	2026-01-05 14:27:45.265	2026-01-05 14:27:45.265	\N	1	f	\N	\N	\N	\N	f
cmk1994qw004u2mi0chbr5ywx	Italitagurtler@hotmail.com	$2b$12$TF.4JeWt5xcOHR5Sk6/USOqhBPW6f3z/SbqoY.36sd0n7niMmGDxO	Italita Alcântara Gurtler	MEMBRO	2026-01-05 14:27:45.608	2026-01-05 14:27:45.608	\N	1	f	\N	\N	\N	\N	f
cmk19950e004x2mi0kx0a6k3k	barbosa.jarbas@uol.com.br	$2b$12$vIU.uEX2fYTHbCE0Il2eCuKnZfPvz4ql85gqHMhTv4Gzb6zcZ1n0G	JARBAS BARBOSA	MEMBRO	2026-01-05 14:27:45.95	2026-01-05 14:27:45.95	\N	1	f	\N	\N	\N	\N	f
cmk19959s00502mi0r8rblpb7	betoni.joaquina@gmail.com	$2b$12$/RiET5DLhoOdctFpxe/7quPXa3AaJ20Y9b9H1xVmO3XIWWB4.VWtu	JOAQUINA DA COSTA BETONI	MEMBRO	2026-01-05 14:27:46.288	2026-01-05 14:27:46.288	\N	1	f	\N	\N	\N	\N	f
cmk1995ja00532mi08xh5ghze	juliocesar.fazpalmeira@gmail.com	$2b$12$.N//BY6CqHEBIJix/bRQUOB1BudzoDjrxft5jPu4GRXIaq2KABsR6	JULIO CÉSAR SOARES	MEMBRO	2026-01-05 14:27:46.63	2026-01-05 14:27:46.63	\N	1	f	\N	\N	\N	\N	f
cmk1995su00562mi02nosyat0	Jaquelinepgomes750@gmail.com	$2b$12$Tjw0/MkBNgwCicCD7PFWBORBjz9Kj2Q/Oq.zIqj6EK2tAOg6loDK2	Jaqueline Pimentel Gomes de Lima	MEMBRO	2026-01-05 14:27:46.974	2026-01-05 14:27:46.974	\N	1	f	\N	\N	\N	\N	f
cmk19962b00592mi0tdywcjp0	jlzcardoso@hotmail.com	$2b$12$nN8tfLvtzlOuJZYrFNnfLOKe6u1DB9LGveawzgbQkkQhjNzZOqPJC	Joao Luiz zirondi cardoso	MEMBRO	2026-01-05 14:27:47.315	2026-01-05 14:27:47.315	\N	1	f	\N	\N	\N	\N	f
cmk1996bw005c2mi0o2nx84ji	babykidsms@outlook.com	$2b$12$VfvBSNG0BCZwbNX/Yhy40.SliPXOmlewxwumjRCUsj6kOqPyEQbV.	Julia Lopes Vidal Carlesso	MEMBRO	2026-01-05 14:27:47.66	2026-01-05 14:27:47.66	\N	1	f	\N	\N	\N	\N	f
cmk1996ls005f2mi08l3x8a33	juliojunior40@outlook.com	$2b$12$UbGUioHokialQ4WpTWzyuuplJEEui9qefxM29MmfnBOfVwm.VGuNy	Julio cesar de souza soares junior	MEMBRO	2026-01-05 14:27:48.016	2026-01-05 14:27:48.016	\N	1	f	\N	\N	\N	\N	f
cmk1996vd005i2mi02hiunqnw	jessicapedo.adv@gmail.com	$2b$12$ZmtjztIxmJNVnXilAe3OPuBaObQanihECCP.eJTilk8hYsH3Ly1Va	Jéssica Pedó	MEMBRO	2026-01-05 14:27:48.361	2026-01-05 14:27:48.361	\N	1	f	\N	\N	\N	\N	f
cmk19974x005l2mi0krywoy33	jctolomei@gmail.com	$2b$12$6oB5TKN7FjmNs9.nphmTjuPxkXBIKXSBh0hUVgzfNn1yV832CHyJK	Júlio César Ricci Tolomei	MEMBRO	2026-01-05 14:27:48.705	2026-01-05 14:27:48.705	\N	1	f	\N	\N	\N	\N	f
cmk1997ek005o2mi0zrzqit0y	karineblume@yahoo.com.br	$2b$12$Ow2LgevB7.vNVvdoQcWms.mk0G/J8DyaYvLxNOiTj03g5BW0knIhC	KARINE BLUME DE SOUZA	MEMBRO	2026-01-05 14:27:49.052	2026-01-05 14:27:49.052	\N	1	f	\N	\N	\N	\N	f
cmk1997o0005r2mi0enxfx4g1	karen.castroo@hotmail.com	$2b$12$Pjt.YLvQxWb5Q28pY19A/O9A6kICgyhSSn1Q8CQa8XuEpArXYGc.S	Karen Ingrid Matias de Castro	MEMBRO	2026-01-05 14:27:49.393	2026-01-05 14:27:49.393	\N	1	f	\N	\N	\N	\N	f
cmk1997xi005u2mi0ap4dsiaq	batistelakaryna@gmail.com	$2b$12$JwDrraB6vn0hZihec.8N2utIThL9W1WP1x.yr7wc0yPP8J/0y7Upq	Karyna Batistela Paniagua Balta	MEMBRO	2026-01-05 14:27:49.734	2026-01-05 14:27:49.734	\N	1	f	\N	\N	\N	\N	f
cmk199870005x2mi0ag1x4w8h	Kelicristiane34@hotmail.com	$2b$12$3FaR4/uyQS7cPpi1EabUr.CM3A.rsMI./BWsYPxv5Bas3Nw7oLxcy	Keli Cristiane da Costa	MEMBRO	2026-01-05 14:27:50.076	2026-01-05 14:27:50.076	\N	1	f	\N	\N	\N	\N	f
cmk1998gi00602mi0u1mldh3f	Khety_line@hotmail.com	$2b$12$731q/rjQo7PS.r2GSkXN/uguLc0IAG7WQPMhunw7gW.r5sfAQMNCC	Khety Line Albarello Kubitz	MEMBRO	2026-01-05 14:27:50.418	2026-01-05 14:27:50.418	\N	1	f	\N	\N	\N	\N	f
cmk1998q100632mi00619av3h	loide.lopes@outlook.com.br	$2b$12$8toHRcAZYqbSIgvXyZf0iOTlrs/6YpKyBN0IGsJ3IxdooLAMuvQkm	LOIDE LOPES	MEMBRO	2026-01-05 14:27:50.762	2026-01-05 14:27:50.762	\N	1	f	\N	\N	\N	\N	f
cmk1998zl00662mi0y5n1gtio	luanan1@hotmail.com	$2b$12$PBIzcfxPUS/b64UwdjSM/eyyUxF6pWpnP6wbth/q5KIbDjozx0Nv.	LUANA DA SILVA NEVES	MEMBRO	2026-01-05 14:27:51.106	2026-01-05 14:27:51.106	\N	1	f	\N	\N	\N	\N	f
cmk1999ip006c2mi0orzonsxh	lucianasilva@uems.br	$2b$12$zODynED8ImEMisCzRVt3W.OQdBHSAarydE6UUaWOwvfe8599T.Hna	LUCIANA DA SILVA RODRIGUES	MEMBRO	2026-01-05 14:27:51.793	2026-01-05 14:27:51.793	\N	1	f	\N	\N	\N	\N	f
cmk1999s7006f2mi0wpia2cvy	luziamorgado@hotmail.com	$2b$12$0C2cC6CFhqgernZkMASq0OgT3ORj2jLLzGGLkXctXN1QJkanNHHEm	LUZIA CAMPOS MORGADO	MEMBRO	2026-01-05 14:27:52.135	2026-01-05 14:27:52.135	\N	1	f	\N	\N	\N	\N	f
cmk199a1s006i2mi0u68cfb4e	Carol_gabbi@hotmail.com	$2b$12$uh0b5x..quOfBC0zd7sU9OSXQrX.c7zJjbIpHv8t6h8f0OZpbOVQ6	Laudemira Gabbi	MEMBRO	2026-01-05 14:27:52.48	2026-01-05 14:27:52.48	\N	1	f	\N	\N	\N	\N	f
cmk199abh006l2mi0oh2jwgf7	Helenalaura.silvagoncalves@gmail.com	$2b$12$eE5NKAHC93hM2/4uc2QGguKOaZyJM.t6AlMk880OJsUGKQ5KFcej6	Laura Helena da Silva Gonçalves	MEMBRO	2026-01-05 14:27:52.829	2026-01-05 14:27:52.829	\N	1	f	\N	\N	\N	\N	f
cmk199ald006o2mi0sjo0t1qy	Leandrogasparduarte@yahoo.com	$2b$12$jGDc8h3YONMOB.2EFDhg6epgjACuoUl4Xn0257hg1ixqrwjA/17My	Leandro Gaspar Duarte	MEMBRO	2026-01-05 14:27:53.185	2026-01-05 14:27:53.185	\N	1	f	\N	\N	\N	\N	f
cmk199av2006r2mi0ozs44dpw	batistella2901@gmail.com	$2b$12$FYflgT7ydqqimE1e4t9Zr.Wi.rj.gSH2tp6krEhlXdZdrTdgUsBVa	Leandro Luiz Batistella	MEMBRO	2026-01-05 14:27:53.535	2026-01-05 14:27:53.535	\N	1	f	\N	\N	\N	\N	f
cmk199b4o006u2mi0hpfoxu9z	leandromuller.adv@gmail.com	$2b$12$la4oqpiJfyYZgkiD8E/TQeJOBj4DPt/G8hYdCxs53mkr.1roFXxsm	Leandro Muller	MEMBRO	2026-01-05 14:27:53.881	2026-01-05 14:27:53.881	\N	1	f	\N	\N	\N	\N	f
cmk199bea006x2mi06wm51646	liandra_canova@hotmail.com	$2b$12$W/6Aoi.aNo92JtleD8acHuZNH49sUvsA7stk2TxHHNq/6tB10tdGa	Liandra Vitoria Canova	MEMBRO	2026-01-05 14:27:54.226	2026-01-05 14:27:54.226	\N	1	f	\N	\N	\N	\N	f
cmk199bpe00702mi0qr0r3wxk	lorenzoleite09268@gmail.com	$2b$12$kLZr3Y13HWDBRGgb7BUd6e0uAwTbFQfJCR9Zg/AfbgLadiajlCLl6	Lorenzo Ribeiro Sanches Leite	MEMBRO	2026-01-05 14:27:54.626	2026-01-05 14:27:54.626	\N	1	f	\N	\N	\N	\N	f
cmk199bz000732mi05u2on7mv	Lovidal@outlook.com	$2b$12$pGoun8bDwsqINw6mIAcv9eO0OmymVQXCWXnGZE7g/ENdcGtH0Pn0y	Lorraine Vidal	MEMBRO	2026-01-05 14:27:54.973	2026-01-05 14:27:54.973	\N	1	f	\N	\N	\N	\N	f
cmk199c8m00762mi00qg491f9	lucas.elypay@gmail.com	$2b$12$fQfBSbvzwSxY8cNpT.I9L.jjvEKTR/Z8ftE4jg2oNss6WzQN1FKzu	Lucas Ferreira de oliveira	MEMBRO	2026-01-05 14:27:55.319	2026-01-05 14:27:55.319	\N	1	f	\N	\N	\N	\N	f
cmk199cib00792mi0jf1bc69l	Lucianafloraixx75@gmail.com	$2b$12$wxo09eF79FibMgu2N.Gziu7Hv7PtBSSzbvTxDYnoiIrZmYQXNoSQy	Luciana lago	MEMBRO	2026-01-05 14:27:55.667	2026-01-05 14:27:55.667	\N	1	f	\N	\N	\N	\N	f
cmk199crs007c2mi00ihlpvgz	lcmanfio19@gmail.com	$2b$12$XvSzKT.njl85.iI4PDwVDe0ggBMX3.gr8lSBouGEvrhk5otJ1VEXe	Luciano Cargnin Manfio	MEMBRO	2026-01-05 14:27:56.008	2026-01-05 14:27:56.008	\N	1	f	\N	\N	\N	\N	f
cmk199d17007f2mi0suka644o	L_messiasdasilva@hotmail.com	$2b$12$tVMYaggHiy2XTzT/V5/twOg7s4CM3A8A2Epp9oJKtpZTkdDTffEKG	Lucio Messias da Silva	MEMBRO	2026-01-05 14:27:56.348	2026-01-05 14:27:56.348	\N	1	f	\N	\N	\N	\N	f
cmk199das007i2mi0kzuvrkrc	livia_cabelo@hotmail.com	$2b$12$0uoOjYYMIYUbMyTM6kGtx.4ROw7P1BTu21w5dxsN.RflgCYiYx1w.	Lívia Cabelo	MEMBRO	2026-01-05 14:27:56.693	2026-01-05 14:27:56.693	\N	1	f	\N	\N	\N	\N	f
cmk199dke007l2mi06agevfpo	manoelmorgado@uol.com.br	$2b$12$uat9V4g2g0644ZUTlot6aOnqWCSO23l405O/HtB/AEhUFLTmVhD9q	MANOEL SANTOS MORGADO	MEMBRO	2026-01-05 14:27:57.038	2026-01-05 14:27:57.038	\N	1	f	\N	\N	\N	\N	f
cmk199dtz007o2mi08umpmhcx	barbosa.belinha@uol.com.br	$2b$12$f1XX0QqhdIDvTZ7BOEAk2e43kBlj5A8MJAFIeEXSY2bxngFZYlh0i	MARIA ISABEL DE ALVARENGA MADUREIRA	MEMBRO	2026-01-05 14:27:57.383	2026-01-05 14:27:57.383	\N	1	f	\N	\N	\N	\N	f
cmk199e3k007r2mi0bf2eaqtt	mari_viana1@hotmail.com	$2b$12$wcyl8dDiQhg5j/jfSeif.Oj2bCDev3QL.fE0h5o92t.m4NaQnFp82	MARIANA VIANA VIEIRA	MEMBRO	2026-01-05 14:27:57.729	2026-01-05 14:27:57.729	\N	1	f	\N	\N	\N	\N	f
cmk199ed6007u2mi0dkp0a0mv	manuelysantosluzia2009@gmail.com	$2b$12$n9cOrLCV4oXiNfF4Oci0Kuo6ITNJz.GtuiiPHQOf10IZVwtLzaY7y	Manuély dos Santos Luzia	MEMBRO	2026-01-05 14:27:58.074	2026-01-05 14:27:58.074	\N	1	f	\N	\N	\N	\N	f
cmk199emy007x2mi0xrrlzdtv	Marcelaregina_6@hotmail.com	$2b$12$8RQoHTHBBZVmliSFgdryIebJaMe7rQLZPXTPtS..QHOa7ak7hcO5y	Marcela Regina de Oliveira Carvalho Duarte	MEMBRO	2026-01-05 14:27:58.427	2026-01-05 14:27:58.427	\N	1	f	\N	\N	\N	\N	f
cmk199ewp00802mi0r2xau24f	maria_thida@hotmail.com	$2b$12$ii3QTPISTdvlEkga.tGc9uk5LBUIbF5FZ/8IH.oDe/Govc6nt5Y4q	Maria Aparecida dos Santos	MEMBRO	2026-01-05 14:27:58.777	2026-01-05 14:27:58.777	\N	1	f	\N	\N	\N	\N	f
cmk199f6b00832mi0f5zgjn8p	adv.mariaisabelalima@gmail.com	$2b$12$PNN.3mJK/uxutbtTIWqtoOpjZgGS03G5W0p0pe3BNejCYm5dCg3dW	Maria Isabela de Lima Rodrigues	MEMBRO	2026-01-05 14:27:59.123	2026-01-05 14:27:59.123	\N	1	f	\N	\N	\N	\N	f
cmk199ffu00862mi0nunhp0km	ma_bbisognin@hotmail.com	$2b$12$1nwyV3k0RS2m7tnKBKvPceeBLCyNQMuMnAm7y/0.vQvs0VrpTUihy	Mariana Borges Bisognin	MEMBRO	2026-01-05 14:27:59.466	2026-01-05 14:27:59.466	\N	1	f	\N	\N	\N	\N	f
cmk199fpe00892mi0yxndcdik	marilcsilva@hotmail.com	$2b$12$iIt5iQ68e9DrBnXnyUJjmOMTrSAwlw/9xxTdiuVnK7ZSY5LKfD0py	Marili Correia da Silva	MEMBRO	2026-01-05 14:27:59.81	2026-01-05 14:27:59.81	\N	1	f	\N	\N	\N	\N	f
cmk199fyv008c2mi0ju8vdrfv	Mah.sanches@hotmail.com	$2b$12$ODBvSN4xoRqlfLVfmkF0W.vaQ7bNDk1XaNGFm2EIlRJTD.Jfjyqse	Marina Ribeiro Sanches	MEMBRO	2026-01-05 14:28:00.151	2026-01-05 14:28:00.151	\N	1	f	\N	\N	\N	\N	f
cmk199g8j008f2mi0imwh7vif	marlenemeazza@gmail.com	$2b$12$OoAm7qzm6.xgxi3yYjY6yuE1Q6cH51NvultFBH/AU.J9lym1bD5Ia	Marlene de Araujo Oliveira Meazza	MEMBRO	2026-01-05 14:28:00.499	2026-01-05 14:28:00.499	\N	1	f	\N	\N	\N	\N	f
cmk199grj008l2mi0wkdnkwvc	natalia_biazoto@hotmail.com	$2b$12$Nzdk3Yf99dAO/dYIuT5jgujC5VIIpYImdq55dljFODExCnAoUMHxG	Natália Biazoto de Paiva	MEMBRO	2026-01-05 14:28:01.184	2026-01-05 14:28:01.184	\N	1	f	\N	\N	\N	\N	f
cmk199h13008o2mi00ehoc3u7	Nay.castro2023@gmail.com	$2b$12$q2cZx1vQlRIonIaK1ChwQ.1SoFrfvmOWfCITYkqTOfGqZJHYoYiFa	Nayane Laís de Melo Castro	MEMBRO	2026-01-05 14:28:01.528	2026-01-05 14:28:01.528	\N	1	f	\N	\N	\N	\N	f
cmk199ham008r2mi0yxh3g1lj	njpaiva87@gmail.com	$2b$12$aHi6ta6pwAcgtoctirl/Q.n/rQDgjpJe5pGYtwU.8CN3vSNxyQVMm	Nivaldo José de Paiva Filho	MEMBRO	2026-01-05 14:28:01.87	2026-01-05 14:28:01.87	\N	1	f	\N	\N	\N	\N	f
cmk199hk6008u2mi0348ojpj4	noediralves396@gmail.com	$2b$12$YkPPkhqC6n/YzVDJx/Kx2O2cT/fN4NV6yXmKN1hkQKmhwk4bQzEAi	Noedir Alves dos Santos Disperati	MEMBRO	2026-01-05 14:28:02.215	2026-01-05 14:28:02.215	\N	1	f	\N	\N	\N	\N	f
cmk199htr008x2mi0igi7971b	nadiazanrocha@gmail.com	$2b$12$baz6S46O784V/YeCofYhRO7kTWVFV.bJKVOx76PpKBe8fW4Bbd7SK	Nádia A Z Rocha	MEMBRO	2026-01-05 14:28:02.559	2026-01-05 14:28:02.559	\N	1	f	\N	\N	\N	\N	f
cmk199i3900902mi0e844g6pu	paulo.yule@hotmail.com	$2b$12$ZJJ2ny632pbpTGHEifo5Quk7Z/p2v8hVyqXr3xHDgk1mCshpyhisK	PAULO CESAR MACIEL YULE	MEMBRO	2026-01-05 14:28:02.901	2026-01-05 14:28:02.901	\N	1	f	\N	\N	\N	\N	f
cmk199icv00932mi0qki96l3s	belonepatricia@gmail.com	$2b$12$3.pT.dyky0y8PVjMwtjwTOVz0VhSEnlaiYkcytZyAH9MqfBgR3Q3G	Patrícia Cristiane Chagas Alves Belone	MEMBRO	2026-01-05 14:28:03.247	2026-01-05 14:28:03.247	\N	1	f	\N	\N	\N	\N	f
cmk199ivy00992mi0hci37p99	pauloscurti@hotmail.com	$2b$12$RsAVvBmBGco784YpwR4PUeYPL.Wt6fQ0UXvgcVUpSbxese/x.ku0.	Paulo Marcelo Schroeder Curti	MEMBRO	2026-01-05 14:28:03.935	2026-01-05 14:28:03.935	\N	1	f	\N	\N	\N	\N	f
cmk199j5i009c2mi0yrb1dnkr	regis@cultivarms.com.br	$2b$12$0FZvxiZJHT1Og2l/bD0Ne.Zis6OirOSPzStuUkqeCjGxGwAnd9S4i	REGIS AUGUSTO KOSTER CANOVA	MEMBRO	2026-01-05 14:28:04.278	2026-01-05 14:28:04.278	\N	1	f	\N	\N	\N	\N	f
cmk199jf5009f2mi0jo23su1s	arq.ronovais@hotmail.com	$2b$12$WQC4B4lhsE4Mp3wMTRUOFOLKGinMRpVYCeX6qguiZP1gu0BQBsnXe	ROSANGELA NOVAIS	MEMBRO	2026-01-05 14:28:04.626	2026-01-05 14:28:04.626	\N	1	f	\N	\N	\N	\N	f
cmk199jos009i2mi0qqpemvu8	rafaela.rego2021@gmail.com	$2b$12$QGoWAxyeqZanVs7JgFKUjeuZdDih/mnQh5WDRmqJi6U08eRB5dPtW	Rafaela Rêgo	MEMBRO	2026-01-05 14:28:04.973	2026-01-05 14:28:04.973	\N	1	f	\N	\N	\N	\N	f
cmk199jyc009l2mi0ti5dhfve	renatapaiva_6@hotmail.com	$2b$12$0CamntS1KdjBZYoTrO5v2uxtfeReXykeEVlsLV52.n9tINpKg.IsK	Renata Barbosa de Paiva Facco	MEMBRO	2026-01-05 14:28:05.317	2026-01-05 14:28:05.317	\N	1	f	\N	\N	\N	\N	f
cmk199khh009r2mi0j09cqdx4	rs6303217@gmail.com.br	$2b$12$1Vvfa7.nsofXQhRaPco8O.Ado.kHRVMMojY08muF9ULhapoWUBfbW	Rita de Cássia Gomes da Silva	MEMBRO	2026-01-05 14:28:06.006	2026-01-05 14:28:06.006	\N	1	f	\N	\N	\N	\N	f
cmk199l0k009x2mi0crhfczfx	rosineidesilvano@yahoo.com	$2b$12$XWHQOAiY7oTmsCP7RYeVzeIeEh/vp0JCuAN.Ou012jB5qjDgrpv.y	Rosineide Silvano dos Santos Muniz	MEMBRO	2026-01-05 14:28:06.692	2026-01-05 14:28:06.692	\N	1	f	\N	\N	\N	\N	f
cmk199la600a02mi0hejehbiw	sandragasparelli@gmail.com.br	$2b$12$gue9gAq.M0f78hfzMYoPLO4AsvFCk1hw..E5GSv774fDfV4mB51q2	SANDRA JANETE SMANIOTTO GASPARELLI	MEMBRO	2026-01-05 14:28:07.038	2026-01-05 14:28:07.038	\N	1	f	\N	\N	\N	\N	f
cmk199lju00a32mi0g07ichyc	sheila@hotmail.com	$2b$12$.7HEn4T6qSFBH3ouMlHQpuAg0tQiE.mY4nYefU9jQ7Tg1eccyagdS	SHEILA FERNANDES ALMEIDA	MEMBRO	2026-01-05 14:28:07.386	2026-01-05 14:28:07.386	\N	1	f	\N	\N	\N	\N	f
cmk199ltk00a62mi0dqt53n1y	silvanapael@hotmail.com	$2b$12$paYyCjvIY8Lqdsg0/d/VG.dmQh8DwI/tIChP4GJJZMLa.ALn.Cuuu	SILVANA PAEL MARECO	MEMBRO	2026-01-05 14:28:07.736	2026-01-05 14:28:07.736	\N	1	f	\N	\N	\N	\N	f
cmk199m3400a92mi0pzp0kc3q	zeliaaraujosobreira@hotmail.com	$2b$12$JERVO2SwRYJcbvs/2Frxm.YgpstspITTkmdUiYjPQPzq5A.mXcIXG	SIMONE SOBREIRA BARBOSA	MEMBRO	2026-01-05 14:28:08.08	2026-01-05 14:28:08.08	\N	1	f	\N	\N	\N	\N	f
cmk199mcq00ac2mi0pkmz4xhd	skbarbieri@hotmail.com	$2b$12$.KbdyjMmMxhUYk1.iispX.JbEDYs.Vj/Ifsfx03xi0eH2s.SOx1uu	Sandra Katia Barbieri	MEMBRO	2026-01-05 14:28:08.426	2026-01-05 14:28:08.426	\N	1	f	\N	\N	\N	\N	f
cmk199mma00af2mi0ww8zv7d9	sandra_rbr@hotmail.com	$2b$12$wxN67/42yjk24cW30RcOkOivHKGg8n/3PHoyRynsEWTRITpihD7Ze	Sandra Regina donha	MEMBRO	2026-01-05 14:28:08.771	2026-01-05 14:28:08.771	\N	1	f	\N	\N	\N	\N	f
cmk199mvy00ai2mi03u3gv6p0	silespirandeli10@gmail.com	$2b$12$dFKA7g2RcGS3Ds.hhYjKxemr8IzPqGG6HYhg1nooKJ/.uL9iDZiEm	Silvana Espirandeli	MEMBRO	2026-01-05 14:28:09.118	2026-01-05 14:28:09.118	\N	1	f	\N	\N	\N	\N	f
cmkv84bn30000l404uiq2qoun	reedy-trio9n@icloud.com	$2b$12$gOK1lnhO/f0quBj..5erk.lVJ32VeQcPNdvlbjTtHO4v1X8GKM43y	\N	MEMBRO	2026-01-26 13:49:06.927	2026-01-26 13:49:25.953	2026-01-26 13:49:25.952	2	f	9bc0759b99d54652d256db340c2d52789051b84e2bfed087ab8de2fe762f15f8	2026-01-26 14:49:25.952	\N	\N	t
cmkwo4i7x0000la04btmvx6wc	temp_1769606669808_dlg0ylfe@placeholder.local	$2b$12$H/whTRxG.N1O6Q5fvFEljuXZm9Ny.WM4azkW/rUbDr7ZKT7HOE17W	Rosemarie Nimer	MEMBRO	2026-01-27 14:04:55.485	2026-01-28 13:24:29.874	\N	4	t	\N	\N	\N	\N	f
cmk199n5r00al2mi09zzoqgs0	assmann2007@yahoo.com.br	$2b$12$sDiHK24zGlSNFvaBaMVyD.mTj/tKg0XXA9Ut.R.AmyY9kFI8Nj6VO	Simone Assmann Santos Topper	MEMBRO	2026-01-05 14:28:09.472	2026-01-05 14:28:09.472	\N	1	f	\N	\N	\N	\N	f
cmk199nfd00ao2mi0sdv9xkwk	Monykler3@gmail.com	$2b$12$RJAoFG/Pu2/OJ50WlRqsMOtEC/l8l9PVdpKaCggQ/HHr5b50RBEvy	Simone Kler Chiminacio Braz garcia	MEMBRO	2026-01-05 14:28:09.817	2026-01-05 14:28:09.817	\N	1	f	\N	\N	\N	\N	f
cmk199noy00ar2mi0ge6nntiw	soniamigotto@hotmail.com	$2b$12$ROdQyAxBx7SfuwKGAYBU0.vPEtCwOkt619LaSfXhh4i0OT5vEwKi.	Sonia Regane Zemolin Migotto	MEMBRO	2026-01-05 14:28:10.163	2026-01-05 14:28:10.163	\N	1	f	\N	\N	\N	\N	f
cmk199nyl00au2mi0o45ydmcg	suhcardoso2022@gmail.com	$2b$12$eqN6Q8HTPz/8/ARIUcr8..Alo7ymxXpsbsEkOT.SktrtoT0T02.XS	Suelen Centurião Cardoso	MEMBRO	2026-01-05 14:28:10.51	2026-01-05 14:28:10.51	\N	1	f	\N	\N	\N	\N	f
cmk199o8c00ax2mi0mrrt6s7x	radtkesuelen@gmail.com	$2b$12$NuL7155/y4WqH1AGvbDo9.YrZTwQ/0WUsOMxwrEx2SWIndHhNYCU6	Suelen Ródio Baumgartt	MEMBRO	2026-01-05 14:28:10.861	2026-01-05 14:28:10.861	\N	1	f	\N	\N	\N	\N	f
cmk199oj300b02mi0wv32kfgj	sumaia.lemess@gmail.com	$2b$12$s4IsHntu3ATqJ5GHh9Itxe7f8ckYxecE7v95iDzfgQ88N6UwgUKWG	Sumaia Dorazi Lemes	MEMBRO	2026-01-05 14:28:11.248	2026-01-05 14:28:11.248	\N	1	f	\N	\N	\N	\N	f
cmk199osn00b32mi0rx0s7i2m	suzaneleme@icloud.com	$2b$12$Kk320l/Gyx3gieUqXjhpjuZOVYLcMt5fHO6X9N7fUaR2rWPjAXIaq	Suzane Leme de Lima	MEMBRO	2026-01-05 14:28:11.592	2026-01-05 14:28:11.592	\N	1	f	\N	\N	\N	\N	f
cmk199p2800b62mi07u72n8bb	ferreiramarquessamela@gmail.com	$2b$12$2b.XPL8RR5QS0rmNLn4MVOiM1dJEnYenOIiS4uW9lIEB7vT4qkqMm	Sâmela Ferreira Marques	MEMBRO	2026-01-05 14:28:11.937	2026-01-05 14:28:11.937	\N	1	f	\N	\N	\N	\N	f
cmk199pbv00b92mi0jrc2svqq	thayladaviflamel@gmail.com	$2b$12$pG0yl30vlwGoxRn5c1mTEOrpTbdxRz4GPgONmjPTwtSKecTO.p5YG	THAYLA POLIANA RAMOS DOS SANTOS	MEMBRO	2026-01-05 14:28:12.283	2026-01-05 14:28:12.283	\N	1	f	\N	\N	\N	\N	f
cmk199pln00bc2mi0jypj7dmb	vincensitiago@hotmail.com	$2b$12$FZFMeJgCZ97wQdQ8c4kZP.FBgJAD2z36nz.u3lxwCAzGTMexdMlR.	TIAGO VINCENSI	MEMBRO	2026-01-05 14:28:12.635	2026-01-05 14:28:12.635	\N	1	f	\N	\N	\N	\N	f
cmk199pv900bf2mi0file4krc	tatilismo@gmail.com	$2b$12$qxMrqPlFelne.mNS0sn61ekIILg2grL9lzUD/vOAOswzVz4Je78a2	Tatiana Moraes de Oliveira	MEMBRO	2026-01-05 14:28:12.981	2026-01-05 14:28:12.981	\N	1	f	\N	\N	\N	\N	f
cmk199q4t00bi2mi0aq3roc1z	trsr88@gmail.com	$2b$12$4swI6JxMIeFCz9LaHGemDuXTnmfDI6Eh32h1uXBfhdrYUEdMfJn7m	Tatiane Regina dos Santos Rocha	MEMBRO	2026-01-05 14:28:13.325	2026-01-05 14:28:13.325	\N	1	f	\N	\N	\N	\N	f
cmk199qei00bl2mi0d8pm6b31	taina_toscan@hotmail.com	$2b$12$AMFogsQB3V8OSIIIJYdGPeZ2xbQsDpQdbagLuoiRX31CpDkPI2X7y	Taína Rodrigues Toscan	MEMBRO	2026-01-05 14:28:13.674	2026-01-05 14:28:13.674	\N	1	f	\N	\N	\N	\N	f
cmk199qo500bo2mi0lupz4g7g	telmayule7@gmail.com	$2b$12$poPcNpqtFdux2ZE.7TQwQ.nnAVjab0I5/CjDdanZ2jje/WyGCJlMO	Telma Márcia Maciel yule	MEMBRO	2026-01-05 14:28:14.021	2026-01-05 14:28:14.021	\N	1	f	\N	\N	\N	\N	f
cmk199qxr00br2mi0zonpfm9g	tfagundesmarques@gmail.com	$2b$12$H9dSbuAv1ap3uUKWEJb94OiY/TLmc8Bqr.UUjaTo2aQK3GwY1kswC	Thamara Fagundes Marques	MEMBRO	2026-01-05 14:28:14.368	2026-01-05 14:28:14.368	\N	1	f	\N	\N	\N	\N	f
cmk199rgs00bx2mi0bbqak6jc	Thaísanicetos@gmail.com	$2b$12$NkQVBG/E2XRtjclldJ7xZeWAIbmx73AZiiTBepJyjOBmaeVnCSWIW	Thaís anicetos dos Santos	MEMBRO	2026-01-05 14:28:15.052	2026-01-05 14:28:15.052	\N	1	f	\N	\N	\N	\N	f
cmk199rqd00c02mi0fb7pgxpb	vitoriameazza@gmail.com	$2b$12$Pb.sqaN264/v3a7EyQsiGe4ASSn1EUxjhn0mxp4fcNsU3MzDHYYVW	VITÓRIA OLIVEIRA MEAZZA	MEMBRO	2026-01-05 14:28:15.398	2026-01-05 14:28:15.398	\N	1	f	\N	\N	\N	\N	f
cmk199s0c00c32mi0x591appl	victoriaemanoelli@gmail.com	$2b$12$a68QaRCXQZlsIDOzvq04TeqjvYoBHrP7PJD2G01W.N7N18MTueVu6	Victoria Emanuelle Anderson Baptistella	MEMBRO	2026-01-05 14:28:15.757	2026-01-05 14:28:15.757	\N	1	f	\N	\N	\N	\N	f
cmk199sb500c62mi0prqzsc5y	Vitooriagomes08@gmail.com	$2b$12$xkHseXMp.8BaIkxAikiS6OA6mja377f48jvtqevboSq2DEMWelLpW	Vitória da Silva Gomes	MEMBRO	2026-01-05 14:28:16.146	2026-01-05 14:28:16.146	\N	1	f	\N	\N	\N	\N	f
cmk199skp00c92mi0zz3ua5b4	garcia.vivi0882@gmail.com	$2b$12$0u2aNUWLis190n49q3t5AefMYVSiCBOe/5lZ5jn03dxRKZMrwltuq	Viviane Garcia Pereira	MEMBRO	2026-01-05 14:28:16.49	2026-01-05 14:28:16.49	\N	1	f	\N	\N	\N	\N	f
cmk199sua00cc2mi0s3shckxl	limavivianesilva@hotmail.com	$2b$12$ee5nBqJzKRlT1qKUpiOxJuOEuvE9uVXyul/47Sqp1qG.42BBqKYSa	Viviane Lima Silva	MEMBRO	2026-01-05 14:28:16.834	2026-01-05 14:28:16.834	\N	1	f	\N	\N	\N	\N	f
cmk199t3t00cf2mi0rt9nhqp9	viviane_cabelo@hotmail.com	$2b$12$dNmi00safgB.l7wJjO99X.1PFapvFAKWcfgy0jB2fZS.Ioc15.Z0W	Viviane Soares Cabelo	MEMBRO	2026-01-05 14:28:17.177	2026-01-05 14:28:17.177	\N	1	f	\N	\N	\N	\N	f
cmk199tdc00ci2mi03ewvrczh	walnewlife@hotmail.com	$2b$12$gHTCKkPTY2JLGNTWpCK4BO5p70vQ6/cq85PRwdmL25pInwHM1yMZC	Walkiria Simony Corrêa	MEMBRO	2026-01-05 14:28:17.52	2026-01-05 14:28:17.52	\N	1	f	\N	\N	\N	\N	f
cmk199tmw00cl2mi011x6cccu	willian_wwss@hotmail.com	$2b$12$KmLDNyf3krxxY3Kr87k1tuUpAamT1r32L7vH5pz/QLTTGzX5hb7dC	Wanderson Willian Santiago Santos	MEMBRO	2026-01-05 14:28:17.864	2026-01-05 14:28:17.864	\N	1	f	\N	\N	\N	\N	f
cmk199twd00co2mi01df4al9d	yasmincabelo@gmail.com	$2b$12$BWNz5fJAMHCPKQT1QfFEjuKQswFr2/Ayx7zifd6F3jRmjVz74oHbi	YASMIN CABELO BORGES	MEMBRO	2026-01-05 14:28:18.205	2026-01-05 14:28:18.205	\N	1	f	\N	\N	\N	\N	f
cmk199u5v00cr2mi07t2ys1rq	Erika_novais@outlook.com	$2b$12$pEfEHvUz2yZyVBNxiYyyP.jt6KY4yCpFTue0vyMPuZR8gpqJ1Vq66	Érica Novais Oku	MEMBRO	2026-01-05 14:28:18.547	2026-01-05 14:28:18.547	\N	1	f	\N	\N	\N	\N	f
cmk1ezvuq00cu2mi0tfpmdvd7	baca1983@hotmail.com	$2b$12$h4g4ZFBxY4HWvJXDgD1.UumUbT0wbeA050xOEu2LO1sBucnLyElmG	Bruno Almeida Carvalho de Aguiar	MEMBRO	2026-01-05 17:08:31.875	2026-01-05 17:08:31.875	\N	1	f	\N	\N	\N	\N	f
cmk1ezw2z00cx2mi0zppyx9sg	Camila_gabbi95@hotmail.com	$2b$12$cgPJTc/N1Y4SwSdrF2fKP.MUVPwmpekEdnoz7YeTBgVKD3ElWYe9K	Camila Alves Gabbi Gomes	MEMBRO	2026-01-05 17:08:32.171	2026-01-05 17:08:32.171	\N	1	f	\N	\N	\N	\N	f
cmkv8lmos0000jr04fdeiz8xx	ocher-unique.4c@icloud.com	$2b$12$guCWCfjIsrtzB4vmyVP3peNHBR5wm7n8qLSIMQ5KAX4A.eZXUaDsq	\N	MEMBRO	2026-01-26 14:02:34.396	2026-01-26 14:02:34.396	\N	1	f	\N	\N	f5c1f74ec68d3af41ac48dff30598acd38cf26e54a0e0fc92c595b56b15805f0	2026-01-27 14:02:34.003	t
cmk2kqang00cm2msaireep1aa	victor@placeholder.local	$2b$12$yvuv4D/XyFVsv0F6tGNv8edSzQZsNKmRb2dXmAc4tSHK1xW1fZUJC	Victor	MEMBRO	2026-01-06 12:36:48.365	2026-01-06 12:36:48.365	\N	1	f	\N	\N	\N	\N	f
cmk2kqawt00dx2msanqd5vcer	rozimeire@placeholder.local	$2b$12$3lrYHt/HmwAxSy9KIHKazOgVEdvq6gBSN/Obau3QSprWaARiuQsXC	Rozimeire	MEMBRO	2026-01-06 12:36:48.702	2026-01-06 12:36:48.702	\N	1	f	\N	\N	\N	\N	f
cmkxxtlk60000ju04pr6q8g3u	augusto20060309@icloud.com	$2b$12$TAHuYDUGgj1HBKnvaQEI0e8oE2hFE.zNcf.UCd4GzUQmwc1DISFJ.	Augusto do Rêgo Franke	MEMBRO	2026-01-28 11:24:08.934	2026-01-28 11:26:05.709	2026-01-28 11:24:51.705	4	t	\N	\N	\N	\N	t
cmkv47k260000kz04dkkjowp9	nzfbhtkwfc@privaterelay.appleid.com	$2b$12$.9oBT7vcbrccBbFWZnUPpOeQPQiwM1/64ULm/I6432wbVq4pF0gOa	\N	MEMBRO	2026-01-26 11:59:39.343	2026-01-26 12:17:22.604	\N	1	f	\N	\N	1d45da1bcc9dc2ddd1bcb24159e65f8e97b13687bdc0eef395d402f103f126c5	2026-01-27 12:17:22.602	t
cmk2kqea800ot2msa5z3ni3jo	patrícia.raggagnin@placeholder.local	$2b$12$RYi8nJ.bGZdxKwZmZXvCaeJE9V.A4Jkk6m6UZbTgO9Bj9f65ZkkEy	Patrícia Raggagnin	MEMBRO	2026-01-06 12:36:53.072	2026-01-06 12:36:53.072	\N	1	f	\N	\N	\N	\N	f
cmk2kqeic00p42msapxjlza7y	alice@placeholder.local	$2b$12$NFk87.o0xmYZsjUIYaOM1eAXnOZ7JYdAh/oiPYGt5KkYZ2nehsY7.	Alice	MEMBRO	2026-01-06 12:36:53.364	2026-01-06 12:36:53.364	\N	1	f	\N	\N	\N	\N	f
cmk2kqfpj00t02msacqmwb9oh	miguél.pedo@placeholder.local	$2b$12$Vwup0otMJjnR.9sIkR5sG.cBpb8ZqRctE5O0R2y6Qb/m0TVX2Mlua	Miguél Pedo	MEMBRO	2026-01-06 12:36:54.92	2026-01-06 12:36:54.92	\N	1	f	\N	\N	\N	\N	f
cmk2kqfxt00td2msa7i4d98lf	onice.pedó@placeholder.local	$2b$12$tS61Qu8ip357CQvg3Dq8xOV7NGqM06qV5VTYcf7aU.CvfwL4.8uzq	Onice Pedó	MEMBRO	2026-01-06 12:36:55.217	2026-01-06 12:36:55.217	\N	1	f	\N	\N	\N	\N	f
cmk2kqh2q00v82msawoblalod	chirlei.beck@placeholder.local	$2b$12$yWUK6Fwu6XmE.RVUoR.Uz.8j1RqaoS9QOOek3CEqw4to9BWCE7tCe	Chirlei Beck	MEMBRO	2026-01-06 12:36:56.691	2026-01-06 12:36:56.691	\N	1	f	\N	\N	\N	\N	f
cmk2kql14014d2msaukami2ty	tânia.biazoto@placeholder.local	$2b$12$4tUQLtqcyuTF9v5qI22URe2EMVSEHRy4bncbU7EP9SUJzNscP2PR.	Tânia Biazoto	MEMBRO	2026-01-06 12:37:01.816	2026-01-06 12:37:01.816	\N	1	f	\N	\N	\N	\N	f
cmk2kql99014q2msa8a0l3e7a	joão.miguel@placeholder.local	$2b$12$eibpKgbFEVJ6qj6JztXEfONCPn9CRYa8uvVIh52LNytTht/e.qImS	João Miguel	MEMBRO	2026-01-06 12:37:02.11	2026-01-06 12:37:02.11	\N	1	f	\N	\N	\N	\N	f
cmk2kqlps01562msa9dsy8xnz	dr..julio@placeholder.local	$2b$12$icCFDp8.qgqSgQAii01kZ.ZHQ4j24O9Q0eVyPjoMoNNvoK9HtiDtu	Dr. Julio	MEMBRO	2026-01-06 12:37:02.704	2026-01-06 12:37:02.704	\N	1	f	\N	\N	\N	\N	f
cmkb7hph101qm2mrmye0ron1k	dora@placeholder.local	$2b$12$e/Cfk9NKaKN2ggYOfHo1OOTuZtizvTuOz8oesGfKNCwA8i2GFAJI.	Dora Selma Ferreira do Rêgo	MEMBRO	2026-01-12 13:36:08.246	2026-01-21 20:44:14.95	\N	1	f	\N	\N	\N	\N	f
cmk2kqndy01ac2msaixkmci1q	lillyan@placeholder.local	$2b$12$L/OADkGKwYJ06utnpyjfCedsw4K55Ko1P4rVhLBioHgWheEc.YI.y	Lillyan	MEMBRO	2026-01-06 12:37:04.871	2026-01-06 12:37:04.871	\N	1	f	\N	\N	\N	\N	f
cmk2kqnn801bn2msanuwlkbhk	daniela.ruch@placeholder.local	$2b$12$uxghH3LuLaTvHwYNqULk8.ytkSDUkKFToYZwHPJW5fKPKL5XKdzGm	Daniela Ruch	MEMBRO	2026-01-06 12:37:05.205	2026-01-06 12:37:05.205	\N	1	f	\N	\N	\N	\N	f
cmk2kqnvg01by2msa39sa18u6	cyntia.rocha@placeholder.local	$2b$12$UtAyIHfj9tCRkGXcC6Fn2.zAoJ37Nj0GYopQyaBNv8WdHXd.EyGia	Cyntia Rocha	MEMBRO	2026-01-06 12:37:05.5	2026-01-06 12:37:05.5	\N	1	f	\N	\N	\N	\N	f
cmkvrmdej0000kv04qkmd6w40	saferreira0709@gmail.com	$2b$12$jz2yFKMZ78XAT5GnPlcNEuDTFJxfUchkY8Pr2apyP7OtCkUVpSrRO	Sabrina Martins	MEMBRO	2026-01-26 22:55:01.723	2026-01-26 22:55:01.723	\N	4	t	\N	\N	\N	\N	f
cmkb78nlf00lc2mrmhzywhgk2	zila@placeholder.local	$2b$12$AfpptpdDz6m7rxw0HIPp8uhNfif5gtaqEXJz7ueLTlm3uJO3eg.pC	Zila	MEMBRO	2026-01-12 13:29:05.908	2026-01-12 13:29:05.908	\N	1	f	\N	\N	\N	\N	f
cmkb7amol00sv2mrmghelaxfq	victoria.meaz.@placeholder.local	$2b$12$h6ONhlt5WxhhaWTqLCMy5e7NjBvuRD1HmrNdbu3GVu/JNQ.Ad4Ehe	Victoria Meaz.	MEMBRO	2026-01-12 13:30:38.038	2026-01-12 13:30:38.038	\N	1	f	\N	\N	\N	\N	f
cmkb7cm7z012b2mrmtqlfww6b	devair@placeholder.local	$2b$12$8ZjhxivU.cGlm1/a/t.imeTJUTBQ0FMhUdkhZXU1SHTsQ1Z7VCWT6	Devair	MEMBRO	2026-01-12 13:32:10.751	2026-01-12 13:32:10.751	\N	1	f	\N	\N	\N	\N	f
cmkb7cw3w013m2mrmfju4virw	edileuza@placeholder.local	$2b$12$wbWmFrS9b5m0Y7mlVt8e1.algKWE3Kk55GOOka2YlC0Y6WDP2nX96	Edileuza	MEMBRO	2026-01-12 13:32:23.564	2026-01-12 13:32:23.564	\N	1	f	\N	\N	\N	\N	f
cmkb7f6u101eo2mrmyto8ekce	paulo.suzy@placeholder.local	$2b$12$efKiHg4dsDKPDh0/Mcu5PepVmWnyd4GcuDYWk4Yanq6bNUlv3q59i	Paulo Suzy	MEMBRO	2026-01-12 13:34:10.777	2026-01-12 13:34:10.777	\N	1	f	\N	\N	\N	\N	f
cmkb7hfqi01pb2mrms6v08ewt	lilyan@placeholder.local	$2b$12$lcKI.tlV53MYYlxcQmThduTmk13DcvppOzRjxHwk8U9FZS0mMKEtq	Lilyan	MEMBRO	2026-01-12 13:35:55.627	2026-01-12 13:35:55.627	\N	1	f	\N	\N	\N	\N	f
cmkb7ih0z01u82mrmnvf5u1ki	charlene@placeholder.local	$2b$12$S7L/1RD8Kd3Xapt446FXeeqa7SkTBq1K1KGAW9.wQYTl99xph2tUK	Charlene	MEMBRO	2026-01-12 13:36:43.955	2026-01-12 13:36:43.955	\N	1	f	\N	\N	\N	\N	f
cmkvtqfs40000lb04kdoyam1v	jairinho.rodrigues01@gmail.com	$2b$12$iHKN8CiDywsjHUKT27ykL.iik/uSG9fk4Aw5r1L0/asebF/T9gtDS	Jairo Rodrigues Alvel	MEMBRO	2026-01-26 23:54:10.66	2026-01-26 23:54:10.66	\N	4	t	\N	\N	\N	\N	f
cmkb7kpoa024l2mrmf4825hot	lu.braga@placeholder.local	$2b$12$tBKBy6PoWh53W7DGINRSi.tnO2Ks2sCpbXB.QwUDDinKcJwsctA46	Lu Braga	MEMBRO	2026-01-12 13:38:28.475	2026-01-12 13:38:28.475	\N	1	f	\N	\N	\N	\N	f
cmk199k7x009o2mi0v9lxzo2b	rcfacco@gmail.com	$2b$12$UI3JpbjJpOYhsr3kD/0jOuBlzh1IAsXBY7evdM.BNhTXcX8zOKgg2	Renato Ceruti Facco	MEMBRO	2026-01-05 14:28:05.661	2026-01-12 13:51:30.153	\N	1	f	\N	\N	\N	\N	f
cmk19999600692mi0kb9tqs77	babykidsns@outlook.com	$2b$12$nSRBcTfFptrWChepVXviTecAB5zEleUGWJc785oVzyNkBJ73DGA/m	LUANA LOPES VIDAL	MEMBRO	2026-01-05 14:27:51.451	2026-01-12 15:12:41.53	\N	1	f	\N	\N	\N	\N	f
cmkfhsds00000jo0470uve2gz	augusto20060309@gmail.com	$2b$12$mVvXYW9J57qSM.Pqsisf7uYLKxDVZU0ULKh/qM18v93l/KNPOS54G	\N	MEMBRO	2026-01-15 13:35:27.169	2026-01-26 11:52:12.537	\N	1	f	\N	\N	5cbd673811a9f141fa9b5c3da9759df75cd53414354c390c591a3d6806cbd519	2026-01-23 13:24:26.967	t
cmkfk11fv0000l7043vjxvxeg	dryness.fidgety_7r@icloud.com	$2b$12$2AbDcdy5RCHRPzN5Bxpc/eR9qhxFph/yN8hCxuunNLXiLfcqJ6qEu	\N	MEMBRO	2026-01-15 14:38:10.316	2026-01-15 14:51:37.335	\N	1	f	\N	\N	6e66994eb8480e01f6a9d63a7191bac7565f594a904bebff9be975da5b36beec	2026-01-16 14:51:37.334	f
cmklrzdzy0000js047yuavgu9	ecmesojedovas@gmail.com	$2b$12$spo69z5o4.Kcqlu0sNQ9beuDU7A6gGfBEUDQObCygZwFWAX6BDlS.	Estelita Oliveira Lima Mesojedovas	MEMBRO	2026-01-19 23:07:27.262	2026-01-19 23:07:27.262	\N	1	f	\N	\N	\N	\N	f
cmkls2mh80003js04fie2j724	tatty025@hotmail.com	$2b$12$WItS2CmjzVw2nHCNQvxCU.RN8z8ZKpWcy2xVd8OWtFodVY6NW4372	Tatiane José dos Santos	MEMBRO	2026-01-19 23:09:58.221	2026-01-19 23:09:58.221	\N	1	f	\N	\N	\N	\N	f
cmkn4za550000lb0452pom903	andreialeitebarbosa58@gmail.com	$2b$12$eaSQbhxsdjr27Cl38MT0AORPhy7AwLVO/WZWVlJhzlRMdfKRdTrVm	Andreia Leite Barbosa 	MEMBRO	2026-01-20 21:59:03.449	2026-01-20 21:59:03.449	\N	1	f	\N	\N	\N	\N	f
cmko19dlk0000l404s4po7s6p	sandra_giuliani@hotmail.com	$2b$12$ylaEYnLg9VJgfl2KxqeNMu5xaSTwRgB.nTfrqIMa8pvCIH5W45ZOu	Sandra Giuliani Bortolotto	MEMBRO	2026-01-21 13:02:42.2	2026-01-21 13:20:02.244	\N	1	f	\N	\N	\N	\N	f
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: agendamentos agendamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agendamentos
    ADD CONSTRAINT agendamentos_pkey PRIMARY KEY (id);


--
-- Name: anamneses anamneses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anamneses
    ADD CONSTRAINT anamneses_pkey PRIMARY KEY (id);


--
-- Name: configuracoes configuracoes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.configuracoes
    ADD CONSTRAINT configuracoes_pkey PRIMARY KEY (id);


--
-- Name: exercicios exercicios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercicios
    ADD CONSTRAINT exercicios_pkey PRIMARY KEY (id);


--
-- Name: fichas_treino fichas_treino_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fichas_treino
    ADD CONSTRAINT fichas_treino_pkey PRIMARY KEY (id);


--
-- Name: horarios_disponiveis horarios_disponiveis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios_disponiveis
    ADD CONSTRAINT horarios_disponiveis_pkey PRIMARY KEY (id);


--
-- Name: horarios_fixos horarios_fixos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios_fixos
    ADD CONSTRAINT horarios_fixos_pkey PRIMARY KEY (id);


--
-- Name: membros membros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_pkey PRIMARY KEY (id);


--
-- Name: notificacoes notificacoes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacoes
    ADD CONSTRAINT notificacoes_pkey PRIMARY KEY (id);


--
-- Name: pagamentos pagamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagamentos
    ADD CONSTRAINT pagamentos_pkey PRIMARY KEY (id);


--
-- Name: planos planos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planos
    ADD CONSTRAINT planos_pkey PRIMARY KEY (id);


--
-- Name: treinos_template_exercicios treinos_template_exercicios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treinos_template_exercicios
    ADD CONSTRAINT treinos_template_exercicios_pkey PRIMARY KEY (id);


--
-- Name: treinos_template treinos_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treinos_template
    ADD CONSTRAINT treinos_template_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: agendamentos_membro_id_horario_id_data_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX agendamentos_membro_id_horario_id_data_key ON public.agendamentos USING btree (membro_id, horario_id, data);


--
-- Name: anamneses_membro_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX anamneses_membro_id_key ON public.anamneses USING btree (membro_id);


--
-- Name: configuracoes_chave_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX configuracoes_chave_key ON public.configuracoes USING btree (chave);


--
-- Name: horarios_fixos_membro_id_dia_semana_hora_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX horarios_fixos_membro_id_dia_semana_hora_key ON public.horarios_fixos USING btree (membro_id, dia_semana, hora);


--
-- Name: membros_anamnese_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX membros_anamnese_token_key ON public.membros USING btree (anamnese_token);


--
-- Name: membros_cpf_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX membros_cpf_key ON public.membros USING btree (cpf);


--
-- Name: membros_usuario_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX membros_usuario_id_key ON public.membros USING btree (usuario_id);


--
-- Name: usuarios_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usuarios_email_key ON public.usuarios USING btree (email);


--
-- Name: usuarios_token_reset_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usuarios_token_reset_key ON public.usuarios USING btree (token_reset);


--
-- Name: usuarios_token_verificacao_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX usuarios_token_verificacao_key ON public.usuarios USING btree (token_verificacao);


--
-- Name: agendamentos agendamentos_horario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agendamentos
    ADD CONSTRAINT agendamentos_horario_id_fkey FOREIGN KEY (horario_id) REFERENCES public.horarios_disponiveis(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: agendamentos agendamentos_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agendamentos
    ADD CONSTRAINT agendamentos_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: anamneses anamneses_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.anamneses
    ADD CONSTRAINT anamneses_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exercicios exercicios_ficha_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exercicios
    ADD CONSTRAINT exercicios_ficha_id_fkey FOREIGN KEY (ficha_id) REFERENCES public.fichas_treino(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fichas_treino fichas_treino_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fichas_treino
    ADD CONSTRAINT fichas_treino_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: horarios_fixos horarios_fixos_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.horarios_fixos
    ADD CONSTRAINT horarios_fixos_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: membros membros_plano_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_plano_id_fkey FOREIGN KEY (plano_id) REFERENCES public.planos(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: membros membros_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.membros
    ADD CONSTRAINT membros_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notificacoes notificacoes_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacoes
    ADD CONSTRAINT notificacoes_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pagamentos pagamentos_membro_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagamentos
    ADD CONSTRAINT pagamentos_membro_id_fkey FOREIGN KEY (membro_id) REFERENCES public.membros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: pagamentos pagamentos_plano_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pagamentos
    ADD CONSTRAINT pagamentos_plano_id_fkey FOREIGN KEY (plano_id) REFERENCES public.planos(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: treinos_template_exercicios treinos_template_exercicios_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.treinos_template_exercicios
    ADD CONSTRAINT treinos_template_exercicios_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.treinos_template(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: _prisma_migrations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public._prisma_migrations ENABLE ROW LEVEL SECURITY;

--
-- Name: agendamentos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agendamentos ENABLE ROW LEVEL SECURITY;

--
-- Name: anamneses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.anamneses ENABLE ROW LEVEL SECURITY;

--
-- Name: configuracoes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.configuracoes ENABLE ROW LEVEL SECURITY;

--
-- Name: exercicios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.exercicios ENABLE ROW LEVEL SECURITY;

--
-- Name: fichas_treino; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fichas_treino ENABLE ROW LEVEL SECURITY;

--
-- Name: horarios_disponiveis; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.horarios_disponiveis ENABLE ROW LEVEL SECURITY;

--
-- Name: membros; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.membros ENABLE ROW LEVEL SECURITY;

--
-- Name: notificacoes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notificacoes ENABLE ROW LEVEL SECURITY;

--
-- Name: _prisma_migrations p_full_access__prisma_migrations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access__prisma_migrations ON public._prisma_migrations TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: agendamentos p_full_access_agendamentos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_agendamentos ON public.agendamentos TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: anamneses p_full_access_anamneses; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_anamneses ON public.anamneses TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: configuracoes p_full_access_configuracoes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_configuracoes ON public.configuracoes TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: exercicios p_full_access_exercicios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_exercicios ON public.exercicios TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: fichas_treino p_full_access_fichas_treino; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_fichas_treino ON public.fichas_treino TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: horarios_disponiveis p_full_access_horarios_disponiveis; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_horarios_disponiveis ON public.horarios_disponiveis TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: membros p_full_access_membros; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_membros ON public.membros TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: notificacoes p_full_access_notificacoes; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_notificacoes ON public.notificacoes TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: pagamentos p_full_access_pagamentos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_pagamentos ON public.pagamentos TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: planos p_full_access_planos; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_planos ON public.planos TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: treinos_template p_full_access_treinos_template; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_treinos_template ON public.treinos_template TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: treinos_template_exercicios p_full_access_treinos_template_exercicios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_treinos_template_exercicios ON public.treinos_template_exercicios TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: usuarios p_full_access_usuarios; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY p_full_access_usuarios ON public.usuarios TO service_role, postgres USING (true) WITH CHECK (true);


--
-- Name: pagamentos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pagamentos ENABLE ROW LEVEL SECURITY;

--
-- Name: planos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.planos ENABLE ROW LEVEL SECURITY;

--
-- Name: treinos_template; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treinos_template ENABLE ROW LEVEL SECURITY;

--
-- Name: treinos_template_exercicios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.treinos_template_exercicios ENABLE ROW LEVEL SECURITY;

--
-- Name: usuarios; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


--
-- PostgreSQL database dump complete
--

\unrestrict EoLEopjuAcvQeXLdJRreNCiM8H4DacTZFMMSQ1408JIZiSYq7mAAsL5kQnVeVYg

